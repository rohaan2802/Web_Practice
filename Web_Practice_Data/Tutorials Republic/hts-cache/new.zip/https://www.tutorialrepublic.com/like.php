<!DOCTYPE html>
<html>
<head>
    <title>Like Tutorial Republic on Facebook</title>
    <style type="text/css">
        body{
            color: #4d4d4d;
            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
            font-size: 15.4px;
            line-height: 1.5;
            margin: 19px;
        }
        h5{
            font-size: 32px;
            margin: 0 0 20px;
        }
        p{
            font-size: 16px;
			margin-bottom: 20px;
            color: #666;
        }
        img{
			width: 100px;
            border-radius: 50%;
        }
		table td{
			vertical-align: top;
		}
		table td:first-child{
			padding-right: 20px;
		}
        .fb-like-wrapper{
            background: url("/lib/images/loading.gif") no-repeat left center #fff;
            background-size: 25px auto;
        }
    </style>
</head>
<body>
    <table>
        <tr>
            <td>
                <img src="/lib/images/signature.png" alt="" />
            </td>
            <td>
                <h5>Like Us On Facebook</h5>
    			<p>Please like our official facebook page to receive the updates <br />on new tutorial launches, enhancement and freebies.</p>
    			<div class="fb-like-wrapper">
                    <div class="fb-like" data-href="https://www.facebook.com/tutorialrepublic" data-layout="standard" data-action="like" data-size="small" data-show-faces="false" data-share="false"></div>
                </div>
		    </td>
        </tr>
    </table>
    
    
    <div id="fb-root"></div>
    <script>(function(d, s, id) {
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) return;
      js = d.createElement(s); js.id = id;
      js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.9&appId=1404574483159557";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));</script>
</body>
</html>
