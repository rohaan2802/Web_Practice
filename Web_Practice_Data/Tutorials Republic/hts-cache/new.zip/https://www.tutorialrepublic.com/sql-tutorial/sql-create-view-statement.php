<!DOCTYPE html>
<html lang="en"><!-- InstanceBegin template="/Templates/sql.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
	<!-- InstanceBeginEditable name="doctitle" -->
    <title>SQL CREATE VIEW Statement - Tutorial Republic</title>
    <!-- InstanceEndEditable -->
    	<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta property="fb:admins" content="100001054961582" />
<meta property="fb:app_id" content="1404574483159557" />
<meta property="og:image" content="/lib/images/signature.png" />
<link type="image/x-icon" href="/favicon.ico" rel="shortcut icon" />
<style>
html,body,h1,h2,h3,h4,h5,h6,p,blockquote,pre,img{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}
html,body{min-height:100%}
p{margin:0 0 12px}
ol,ul{margin:0 0 12px}
a,a:active,a:visited{outline:none;color:#1db79f;text-decoration:none}
a code{color:inherit}
a img{border:none;outline:none}
code{color:#000}
table{border-collapse:collapse;border-spacing:0}
table td{vertical-align:top}
body{min-width:1300px;color:#414141;background:#fafafa;font-family:"Segoe UI","Helvetica Neue",Arial,sans-serif;font-size:17px;line-height:1.7}
input,select,textarea,button,div,span,a{box-sizing:border-box}
h1,h2,h3,h4{color:#262626;font-weight:500;margin:20px 0 10px;line-height:1.5;font-weight:600}
h1{font-size:34px;margin-top:17px}
h2{font-size:28px}
h3{font-size:22px}
.space{margin-bottom:25px!important}
.break{margin-bottom:15px!important}
.text-center{text-align:center!important}
.scroll{height:195px;overflow-y:scroll}
.scroll.large{height:245px}
.scroll.xlarge{height:290px}
.scroll.xxlarge{height:340px}
sup{font-size:13px}
pre{background:none;border-radius:0}
.leaderboard{padding-top:8px;position:relative}
.ad-container{height:90px;overflow:hidden}
.intro-image img{display:block;padding:10px 0 25px;max-width:100%}
.clearfix::after{content:".";display:block;height:0;clear:both;visibility:hidden}
code,.code,.syntax,.green-box,.sky-box,.gray-box,.pink-box,.red-box,.at-rule,.codebox ul,.console-output{font-size:16px;font-family:Consolas,Monaco,Courier,monospace}
p code,table.data td:last-child code,.content ul li code,code.mark{padding:2px 4px;color:#333;background-color:#f1f1f1;border-radius:4px}
p code a,table.data td:last-child code a, .content ul li code a{padding:2px 0;background:#fff;margin:0 -4px;font-size:16px}
.console-output{margin:15px 0}
hr{border:none;border-bottom:1px solid #e7e9ed;height:1px;margin:30px 0}
.summary,.topic{border:1px solid #eaeaea;border-width:1px 0;margin:20px 0;padding:10px 0;color:#8e9aa6;line-height:1.5}
h2.section-title span{display:inline-block;border-bottom:4px solid #c9d7e0;padding:0 50px 12px 0}
.wrapper{width:1300px;padding:0 15px;margin:0 auto}
.header{background:#23384e;padding:16px 0}
input.search{background:#fff;border:0 none;color:#807E7E;float:left;height:38px;line-height:26px;font-size:14px;margin:0 0 0 12px;outline:medium none;padding:6px 14px;width:500px;border-radius:2px;box-shadow:0 0 1px rgba(0,0,0,0.6);font-family:inherit}
.search-btn{color:rgba(0,0,0,.6);background:#ebebeb;border:none;outline:none;cursor:pointer;float:left;height:38px;line-height:46px;width:44px;display:block;margin-left:-2px;border-radius:0 2px 2px 0;box-shadow:0 0 1px rgba(0,0,0,0.7)}
.logo{width:304px}
.logo img{height:44px;margin:-3px 0;display:block}
.site-search{float:left;margin-left:100px}
.menu{background-color:#f5f5f5;box-shadow:0 1px 1px rgba(0,0,0,.15);position:relative;z-index:9}
.menu a{color:#666;display:inline-block;padding:0 10px;text-decoration:none;font-size:14px;font-weight:600;height:48px;line-height:48px}
.menu a:first-child{margin-left:-10px}
.menu a.tool-link{float:right;display:inline-block;border-radius:30px;line-height:28px;position:relative;height:auto;top:9px;padding:0 12px;color:#1ebba3;border:1px double #1ebba3}
.fl,.logo{float:left}
.leftcolumn{width:240px;float:left;font-size:16px;color:#4f4f4f}
.centercolumn{width:850px;float:left}
.content{background:#fff;padding:20px 40px;border:1px solid #dedede;border-top:none;border-radius:1px}
.sidebar{float:left;padding-top:28px;width:160px;margin-left:20px;position:relative}
.leftcolumn .segment{margin:16px 0 12px;position:relative;font-size:18px;font-weight:600;display:inline-block;line-height:normal}
.leftcolumn a{color:#4f4f4f;font-size:16px;line-height:26px;display:block;border-bottom:1px solid transparent}
.leftcolumn ul{list-style:none;padding:0}
.segment,.chapters,.chapters a,.toggle-tree-menu{float:left;clear:both}
ul.tree-menu li.tree{margin-left:-12px;float:left;width:100%}
ul.tree-menu li a,ul.tree-menu li code{color:#4f4f4f;font-size:15.4px}
ul.chapters.tree-menu li a{font-size:16px}
h1 code,h2 code,h3 code{font:inherit}
.color-box{margin:15px 0;padding-left:20px}
.note-box,.warning-box,.tip-box{padding:8px 8px 3px 26px}
.info-tab{float:left;margin-left:-23px}
.content ul li{margin-top:7px}
.extra{padding-top:5px}
.green-box,.sky-box,.gray-box,.red-box,.pink-box{color:#000;margin-top:15px;padding:10px;background-color:#f6f8fa;border:1px solid #d7e2ec}
.example{background:#f4f5f6;padding:3px;margin:15px 0}
.codebox{background:#fff;border:1px solid #ddd}
.codebox-title{height:41px;padding-left:12px;border-bottom:1px solid #ddd;background:#f5f5f5}
.codebox-title h4{margin:0;font-size:18px;line-height:38px;float:left;display:inline;font-weight:500}
a.try-btn,a.download-btn{width:140px;height:40px;color:#333;font-size:15px;line-height:41px;font-weight:600;text-align:center;text-decoration:none;float:right;display:block;border-left:1px solid #ddd;background:rgba(27,31,35,0.08);box-sizing:border-box;font-family:Arial,sans-serif}
a.try-btn span{font-size:18px;line-height:normal}
.hide,.code-style,.box-size,.bottom-link,.footer,.code-style,.snippets,.report-error,.badge,.social,.ad-label,.mobile-only{display:none}
.skyscraper{width:160px;height:600px;overflow:hidden;margin-bottom:20px;background:#ebecf0}
.bottom-ad{margin-top:46px;padding:24px;position:relative;background:url(/lib/images/smooth-line.png) no-repeat center #f9f9f9}
.rectangle-left,.rectangle-right{min-width:336px;min-height:280px;overflow:hidden}
.fr,a.previous-page,a.next-page,.topic-nav{float:right}
a.previous-page,a.next-page{width:32px;height:32px;line-height:30px}
.shadow{background:#F7F8F9;padding:3px;margin:10px 0}
.syntax{color:#2f4959;padding:13px 18px;background:#F9F9FA;border:1px solid #ddd;font-size:15px}
.codebox ul{font-size:14px;padding:7px;list-style:decimal inside none}
.codebox ul.lead-zero,.codebox ul.lead-double-zero{list-style-type:decimal-leading-zero}
.codebox ul li{padding:0 9px;color:#AFAFAF;background-image:none;margin:0}
.codebox ul pre,.codebox ul li,.codebox ul li code{line-height:1.6;vertical-align:top}
.codebox ul pre,.codebox ul code{width:90%;font-size:16px;color:#222;display:inline-block;padding-left:10px;border-left:3px solid #6CE26C;white-space:pre-wrap;word-break:normal}
.codebox ul.lead-double-zero li{text-align:right}
.codebox ul.lead-double-zero li pre{text-align:left}
.codebox ul.sql.single-line pre{line-height:26px}
.content .codebox ul li code{color:#222;padding:0 0 0 10px}
.preview-box{padding:15px;text-align:center;cursor:pointer;overflow:hidden;background:#FFF;border:1px solid #e6e6e6}
.preview-box a,.preview-box img{display:block;margin:0 auto}
.topic a:first-of-type{margin-left:2px}
.topic-nav{padding-right:5px;color:#d0d0d0}
.topic-nav a{padding:0 15px;margin:0 0 0 5px;position:relative;display:inline-block}
.topic-nav a::after{font-size:24px;position:absolute;line-height:normal;top:-6px}
.topic-nav a:first-child{margin:0 5px 0 0}
.topic-nav a:first-child::after{content:'\00AB';left:-5px}
.topic-nav a:last-child::after{content:'\00BB';right:-5px}
.download-box{text-align:center;padding:20px 0;margin:20px 0 10px}
.output-box{border-color:#d4d4d4;border-style:solid;border-width:1px 0;padding:5px 15px;overflow:hidden;background:#fff;margin:10px 0}
.demo-box{margin-top:15px}
.subhead{border-bottom:3px solid #DCE3EB;margin-bottom:15px;padding-bottom:10px}
table.data,table.description{width:100%;font-size:92%}
table.data th{color:#000;padding:8px 7px;text-align:left;font-size:15px;background:#F8F8F8}
table.data td{color:#484848;padding:5px 7px;background:#fff}
table.data th,table.data td{vertical-align:top;border:1px solid #DCE3EB}
table.data tr.section th,table.data td.section{font-size:15px;background:#f0f4f7}
table.description th{width:150px;padding:7px;vertical-align: middle}
table.no-wrap tr td:first-child{white-space:nowrap}
.overview{padding-right:202px}
.overview .intro-image{float:right;margin-right:-202px;text-align:right}
.overview .intro-image + p{padding-top:0}
.support{background:#F8F8F8;border:1px solid #ccc;color:#2F4959;padding:15px}
.support table td:first-child{width:200px;padding:0 25px 0 10px;border-right:1px dashed #D0D0D0}
.support h2{color:#2F4959;font-size:16px;padding:0 0 0 30px;margin-top:0}
.support ul{margin-left:10px}
.support ul li{margin-top:4px}
h1 sup{background:#ec0000;border-radius:3px;padding:5px 10px;font-size:15px;color:#fff;position:relative;top:5px}
@media screen and (max-width: 1280px) {
body{min-width:1260px}
.wrapper{width:1260px}
.leftcolumn{width:230px}
.centercolumn{width:820px}
}
@media screen and (max-width: 800px) {
body{min-width:100%;max-width:100%;padding-top:46px}
.wrapper{width:100%;padding:0}
.header{height:46px;padding:5px 0;position:fixed;top:0;left:0;right:0;width:100%;z-index:99}
.logo{width:auto;display:block;padding:6px 0 0 60px;position:absolute;left:0;z-index:100}
.logo img{height:30px}
.menu{width:100%;padding-left:12px;padding-right:12px;overflow-x:auto;white-space:nowrap}
.centercolumn{width:100%;float:none}
.content{padding:10px;border-width:0 0 1px 0}
.sidebar{margin: 25px auto 0}
.skyscraper{display:inline-block}
.shadow,.example{max-width:100%;overflow-x:auto}
.codebox-title{position:relative}
.codebox.multi-style-mode ul{padding-top:7px;margin-top:36px;border-top:1px solid #ddd}
.codebox ul,.codebox ul.scroll{overflow-x:auto}
.rectangle-left,.rectangle-right{float:none;display:inline-block;margin:10px auto;background:#EDEEF2}
.leftcolumn,.footer,.header .social,.header .site-search,.overview .intro-image,.toggle-tree-menu,.code-style,.support table td:first-child,ul.tree-menu code.shorthand,.menu a.tool-link,.backdrop{display:none}
.summary,.topic{padding:5px 0;margin:10px 0}
.leftcolumn,.centercolumn,.sidebar{float:none}
.header,.menu,.container,.footer,.appeal-text{width:100%;box-sizing:border-box}
.centercolumn{width:100%}
.content img{max-width:100%;height:auto}
.codebox ul li{width:614px}
.codebox ul.scroll li{width:597px}
.codebox ul,.codebox ul.scroll{overflow-x:auto}
a.try-btn,a.download-btn{width:130px}
.bottom-ad{height:auto;background:none;padding:30px 0 0;margin:40px 0 0;text-align:center;position:relative}
.native-unit{margin-bottom:30px}
.overview{padding-right:0}
.scroll-pane{overflow-x:auto}
table.data{min-width:480px}
table.data pre{display:inline;white-space:normal}
table tr th,table tr td{width:auto!important}
.support h2,.support ul{padding-left:0}
p.topic{vertical-align:top}
p.topic > a{word-wrap:break-word;display:inline-block}
.example-list ul li,ul.faq-list li{padding-bottom:3px}
.preview-box{padding:6px}
.topic-nav{float:none;display:block;padding:6px 0 0 5px}
.codebox.multi-style-mode ul{padding-top:7px;margin-top:34px;border-top:1px solid #ccc}
.content pre{max-width:100%;overflow:hidden}
.shadow,.content pre.console-output{max-width:100%;overflow-x:auto}
ul.tree-menu li.tree{margin-left:0}
.support ul{margin-left:20px}
.leaderboard{margin:20px 0}
h1{font-size:28px}
h2{font-size:24px}
h3{font-size:20px}
}
@media screen and (min-width: 801px) {
.site-search,.leftcolumn,.social{display:block!important}
.backdrop{display:none!important}
}</style>    
    <!-- InstanceBeginEditable name="head" -->
    <!-- InstanceEndEditable -->
    
    <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-40117907-1', 'auto');
  ga('send', 'pageview');
</script></head>
<body>
    <!--Header-->
    
<div class="header">
    <div class="wrapper clearfix">
        <button type="button" class="open-menu mobile-only"><i class="icon-menu"></i></button>
        <div class="logo">
            <a href="https://www.tutorialrepublic.com/"><img src="/lib/images/logo.svg" alt="TutorialRepublic" /></a>
        </div>
        <div class="site-search">
            <form action="https://www.google.com/search" method="get" target="_blank" class="clearfix">
                <input type="hidden" value="www.tutorialrepublic.com" name="sitesearch" />
                <input type="text" name="q" placeholder="Search topics, tutorials, questions and answers..." id="searchInput" class="search" />
                <button type="submit" class="search-btn"><span class="icon-search"></span></button>
            </form>
        </div>
        <div class="social">                
            <a href="https://www.facebook.com/tutorialrepublic" target="_blank" title="Join us on Facebook"><i class="icon-facebook"></i></a>
            <a href="https://twitter.com/tutrepublic" target="_blank" title="Follow us on Twitter"><i class="icon-twitter"></i></a>
            <a href="/contact-us.php" target="_blank" title="Send us an Email"><i class="icon-mail"></i></a>
        </div>
        <button type="button" class="open-search mobile-only">
            <i class="icon-search"></i>
        </button>
    </div>    
</div>
<div class="menu">
    <div class="wrapper">
        <a href="//www.tutorialrepublic.com" title="Home Page">HOME</a>
        <a href="/html-tutorial/" title="HTML Tutorial">HTML5</a>            
        <a href="/css-tutorial/" title="CSS Tutorial">CSS3</a>
        <a href="/javascript-tutorial/" title="JavaScript Tutorial">JAVASCRIPT</a>
        <a href="/jquery-tutorial/" title="jQuery Tutorial">JQUERY</a>
        <a href="/twitter-bootstrap-tutorial/" title="Bootstrap Tutorial">BOOTSTRAP4</a>
        <a href="/php-tutorial/" title="PHP Tutorial">PHP7</a> 
        <a href="/sql-tutorial/" title="SQL Tutorial">SQL</a>
        <a href="/references.php" title="Web References">REFERENCES</a>
        <a href="/practice-examples.php" title="Practice Examples and Demos">EXAMPLES</a>
        <a href="/faq.php" title="Frequently Asked Questions and Answers">FAQ</a>
        <a href="/snippets/gallery.php" title="Bootstrap Code Snippets" target="_blank">SNIPPETS</a>
        <a href="/codelab.php" class="tool-link" target="_blank">Online HTML Editor</a>
    </div>        
</div>    <!--End:Header-->
    <div class="wrapper clearfix">
        <div class="leftcolumn" id="myNav">
		
        <div class="segment"><span>SQL</span> BASIC</div>
<div class="chapters">
    <a href="/sql-tutorial/">SQL Introduction</a>
	<a href="/sql-tutorial/sql-get-started.php">SQL Getting Started</a>
    <a href="/sql-tutorial/sql-syntax.php">SQL Syntax</a>
    <a href="/sql-tutorial/sql-create-database-statement.php">SQL Create Database</a>
    <a href="/sql-tutorial/sql-create-table-statement.php">SQL Create Table</a>
	<a href="/sql-tutorial/sql-constraints.php">SQL Constraints</a>
	<a href="/sql-tutorial/sql-insert-statement.php">SQL Insert</a>
	<a href="/sql-tutorial/sql-select-statement.php">SQL Select</a>
	<a href="/sql-tutorial/sql-where-clause.php">SQL Where</a>
	<a href="/sql-tutorial/sql-and-or-operators.php">SQL AND &amp; OR</a>
	<a href="/sql-tutorial/sql-in-between-operators.php">SQL IN &amp; Between</a>
	<a href="/sql-tutorial/sql-order-by-clause.php">SQL Order By</a>
	<a href="/sql-tutorial/sql-top-clause.php">SQL Top/Limit</a>
	<a href="/sql-tutorial/sql-distinct-clause.php">SQL Distinct</a>
	<a href="/sql-tutorial/sql-update-statement.php">SQL Update</a>
	<a href="/sql-tutorial/sql-delete-statement.php">SQL Delete</a>
	<a href="/sql-tutorial/sql-truncate-table-statement.php">SQL Truncate Table</a>	
	<a href="/sql-tutorial/sql-drop-statement.php">SQL Drop</a>
</div>
<div class="segment"><span>SQL</span> JOINS</div>
<div class="chapters">
	<a href="/sql-tutorial/sql-joining-tables.php">SQL Joining Tables</a>
    <a href="/sql-tutorial/sql-inner-join-operation.php">SQL Inner Join</a>
	<a href="/sql-tutorial/sql-left-join-operation.php">SQL Left Join</a>
	<a href="/sql-tutorial/sql-right-join-operation.php">SQL Right Join</a>
	<a href="/sql-tutorial/sql-full-join-operation.php">SQL Full Join</a>
	<a href="/sql-tutorial/sql-cross-join-operation.php">SQL Cross Join</a>
</div>
<div class="segment"><span>SQL</span> ADVANCED</div>
<div class="chapters">
	<a href="/sql-tutorial/sql-union-operation.php">SQL Union</a>
	<a href="/sql-tutorial/sql-like-operator.php">SQL Like</a>    
	<a href="/sql-tutorial/sql-alter-table-statement.php">SQL Alter Table</a>
	<a href="/sql-tutorial/sql-aliases.php">SQL Aliases</a>	
	<a href="/sql-tutorial/sql-group-by-clause.php">SQL Group By</a>
	<a href="/sql-tutorial/sql-having-clause.php">SQL Having</a>	
	<a href="/sql-tutorial/sql-create-view-statement.php">SQL Create View</a>
	<a href="/sql-tutorial/sql-create-index-statement.php">SQL Create Index</a>
	<a href="/sql-tutorial/sql-dates-and-times.php">SQL Dates and Times</a>
	<a href="/sql-tutorial/sql-cloning-tables.php">SQL Cloning Tables</a>
	<a href="/sql-tutorial/sql-temporary-tables.php">SQL Temporary Tables</a>
	<a href="/sql-tutorial/sql-subqueries.php">SQL Subqueries</a>
	<a href="/sql-tutorial/sql-injection.php">SQL Injection</a>
</div>
<div class="segment"><span>SQL</span> REFERENCE</div>
<ul class="chapters tree-menu">
    <li class="tree"><span class="shorthand">SQL&nbsp;Data&nbsp;Types</span>
        <ul>
            <li><a href="/sql-reference/mysql-data-types.php">MySQL Data Types</a></li> 
			<li><a href="/sql-reference/sql-server-data-types.php">SQL Server Data Types</a></li>          
        </ul>    
	<li><a href="/sql-reference/sql-functions.php">SQL Functions</a></li>
</ul>        
                </div>
        <div class="centercolumn">
            <!--Text Content-->
            <div class="content">
                <div class="leaderboard">
                    
<div class="ad-label">Advertisements</div>
<div class="ad-container">
    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <!-- Responsive Leaderboard -->
    <ins class="adsbygoogle"
            style="display:inline-block;max-width:728px;width:100%;height:90px"
            data-ad-client="ca-pub-9107540490929984"
            data-ad-slot="4302666817"></ins>
    <script>
    (adsbygoogle = window.adsbygoogle || []).push({});
    </script>
</div>                </div>
                <!-- InstanceBeginEditable name="main_content" -->
                <a href="sql-having-clause.php" class="previous-page" title="Go to Previous Page"></a>
                <a href="sql-create-index-statement.php" class="next-page" title="Go to Next Page"></a>
                <h1>SQL <span>CREATE VIEW</span> Statement</h1>
                <p class="summary">In this tutorial you will learn how to create, update, and delete a view using SQL.</p>
                <h2>Creating Views to Simplify Table Access</h2>
				<p>A view is a virtual table whose definition is stored in the database. But, unlike tables, views do not actually contain any data. Instead, it provides a way to store commonly used complex queries in the database. However, you can use the view in a <a href="sql-select-statement.php">SQL SELECT statement</a> to access the data just as you would use a normal or base table.</p>
				<p class="space">Views can also be used as a security mechanism by allowing users to access data through the view, rather than giving them direct access to the entire base tables.</p>
				<h2>Syntax</h2>
				<p>Views are created using the <code>CREATE VIEW</code> statement.</p>
				<div class="shadow">
                    <div class="syntax sql"><span class="keyword">CREATE VIEW</span> <em title="Replaceable"><code>view_name</code></em> <span class="keyword">AS</span> <em title="Replaceable"><code>select_statement</code></em>;</div>
                </div>
				<p>To understand this clearly, let's look at the following <em>employees</em> and <em>departments</em> tables.</p>
				<table class="break">
					<tr>
						<td>
<pre class="console-output break">
+--------+--------------+--------+---------+
| emp_id | emp_name     | salary | dept_id |
+--------+--------------+--------+---------+
|      1 | Ethan Hunt   |   5000 |       4 |
|      2 | Tony Montana |   6500 |       1 |
|      3 | Sarah Connor |   8000 |       5 |
|      4 | Rick Deckard |   7200 |       3 |
|      5 | Martin Blank |   5600 |    NULL |
+--------+--------------+--------+---------+
</pre>
						</td>
						<td style="width: 40px;"></td>
						<td>
<pre class="console-output break">
+---------+------------------+
| dept_id | dept_name        |
+---------+------------------+
|       1 | Administration   |
|       2 | Customer Service |
|       3 | Finance          |
|       4 | Human Resources  |
|       5 | Sales            |
+---------+------------------+
</pre>
						</td>
					</tr>
					<tr>
						<td class="text-center">Table: <strong><code>employees</code></strong></td>
						<td></td>
						<td class="text-center">Table: <strong><code>departments</code></strong></td>
					</tr>
				</table>
				<p>Suppose that you want retrieve the id and name of the employees along with their department name then you need to perform the <a href="sql-left-join-operation.php">left join</a> operation, as follow:</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=sql&amp;file=join-query" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <ul class="syntax-highlighter sql">
                            <li><pre><span class="cm-keyword">SELECT</span> <span class="cm-variable">t1</span>.<span class="cm-variable">emp_id</span>, <span class="cm-variable">t1</span>.<span class="cm-variable">emp_name</span>, <span class="cm-variable">t2</span>.<span class="cm-variable">dept_name</span></pre></li>
							<li><pre><span class="cm-keyword">FROM</span> <span class="cm-variable">employees</span> <span class="cm-keyword">AS</span> <span class="cm-variable">t1</span> <span class="cm-keyword">LEFT</span> <span class="cm-keyword">JOIN</span> <span class="cm-variable">departments</span> <span class="cm-keyword">AS</span> <span class="cm-variable">t2</span></pre></li>
                            <li><pre><span class="cm-keyword">ON</span> <span class="cm-variable">t1</span>.<span class="cm-variable">dept_id</span> = <span class="cm-variable">t2</span>.<span class="cm-variable">dept_id</span>;</pre></li>
                        </ul>
                    </div>
                </div>
                <!--End:Code box-->
				<p>Once you execute the above query, you'll get the output something like this:</p>
<pre class="console-output break">
+--------+--------------+-----------------+
| emp_id | emp_name     | dept_name       |
+--------+--------------+-----------------+
|      1 | Ethan Hunt   | Human Resources |
|      2 | Tony Montana | Administration  |
|      3 | Sarah Connor | Sales           |
|      4 | Rick Deckard | Finance         |
|      5 | Martin Blank | NULL            |
+--------+--------------+-----------------+
</pre>
				<p>But, whenever you want to access this record you need to type the whole query again. If you perform such operations quite often, it becomes really inconvenient and annoying.</p>
				<p>In such situation you can create a view to make the query results easier to access, as follow:</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=sql&amp;file=create-a-view" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <ul class="syntax-highlighter sql">
                            <li><pre><span class="cm-keyword">CREATE</span> <span class="cm-keyword">VIEW</span> <span class="cm-variable">emp_dept_view</span> <span class="cm-keyword">AS</span></pre></li>
							<li><pre><span class="cm-keyword">SELECT</span> <span class="cm-variable">t1</span>.<span class="cm-variable">emp_id</span>, <span class="cm-variable">t1</span>.<span class="cm-variable">emp_name</span>, <span class="cm-variable">t2</span>.<span class="cm-variable">dept_name</span></pre></li>
							<li><pre><span class="cm-keyword">FROM</span> <span class="cm-variable">employees</span> <span class="cm-keyword">AS</span> <span class="cm-variable">t1</span> <span class="cm-keyword">LEFT</span> <span class="cm-keyword">JOIN</span> <span class="cm-variable">departments</span> <span class="cm-keyword">AS</span> <span class="cm-variable">t2</span></pre></li>
							<li><pre><span class="cm-keyword">ON</span> <span class="cm-variable">t1</span>.<span class="cm-variable">dept_id</span> = <span class="cm-variable">t2</span>.<span class="cm-variable">dept_id</span>;</pre></li>
                        </ul>
                    </div>
                </div>
                <!--End:Code box-->
				<p>Now you can access the same records using the view <i>emp_dept_view</i>, like this:</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=sql&amp;file=retrieve-data-through-a-view" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <ul class="syntax-highlighter sql">
                            <li><pre><span class="cm-keyword">SELECT</span> * <span class="cm-keyword">FROM</span> <span class="cm-variable">emp_dept_view</span>;</pre></li>
                        </ul>
                    </div>
                </div>
                <!--End:Code box-->
				<p>As you can see how much time and effort you can save with the views.</p>
				<!--Tip Box-->
				<div class="color-box">
					<div class="shadow">
						<div class="info-tab tip-icon" title="Useful Tips"><i></i></div>
						<div class="tip-box">
							<p><strong>Tip:</strong> A view always shows up-to-date data! The database engine executes the SQL query associated with the view and recreates the data, every time a view is queried.</p>
						</div>
					</div>
				</div>
				<!--End:Tip Box-->
				<!--Note box-->
				<div class="color-box">
					<div class="shadow">
						<div class="info-tab note-icon" title="Important Notes"><i></i></div>
						<div class="note-box">
							<p><strong>Note:</strong> In MySQL you can also specify the <code><a href="sql-order-by-clause.php">ORDER BY</a></code> clause in a view definition. But, in SQL Sever a view definition cannot contain an <code>ORDER BY</code> clause, unless there is also a <code><a href="sql-top-clause.php">TOP</a></code> clause in the select list of the <code><a href="sql-select-statement.php">SELECT</a></code> statement.</p>
						</div>
					</div>
				</div>
				<!--End:Note box-->
				<hr />				
				<h2>Replacing an Existing View</h2>
				<p>In MySQL, if you want to update or replace an existing view, you can either drop that view and create a new one or just use the <code>OR REPLACE</code> clause in <code>CREATE VIEW</code> statement, as follow:</p>
				<div class="shadow">
                    <div class="syntax sql"><span class="keyword">CREATE OR REPLACE VIEW</span> <em title="Replaceable"><code>view_name</code></em> <span class="keyword">AS</span> <em title="Replaceable"><code>select_statement</code></em>;</div>
                </div>
				<!--Note box-->
				<div class="color-box break">
					<div class="shadow">
						<div class="info-tab note-icon" title="Important Notes"><i></i></div>
						<div class="note-box">
							<p><strong>Note:</strong> When the <code>OR REPLACE</code> clause is used in <code>CREATE VIEW</code> statement, it will create a new view if the view does not exist, otherwise replaces an existing view.</p>
						</div>
					</div>
				</div>
				<!--End:Note box-->
				<p>The following SQL statement will replace or change the definition of the existing view <i>emp_dept_view</i> by adding a new column <i>salary</i> to it.</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="javascript:void(0);" target="_blank" class="try-btn disabled" title="Not Supported in Web SQL">Try this code <span>&raquo;</span></a></div>
                        <ul class="syntax-highlighter sql">
							<li><pre><span class="cm-comment">-- Syntax for MySQL Database </span></pre></li>
                            <li><pre><span class="cm-keyword">CREATE</span> <span class="cm-keyword">OR</span> <span class="cm-keyword">REPLACE</span> <span class="cm-keyword">VIEW</span> <span class="cm-variable">emp_dept_view</span> <span class="cm-keyword">AS</span></pre></li>
							<li><pre><span class="cm-keyword">SELECT</span> <span class="cm-variable">t1</span>.<span class="cm-variable">emp_id</span>, <span class="cm-variable">t1</span>.<span class="cm-variable">emp_name</span>, <span class="cm-variable">t1</span>.<span class="cm-variable">salary</span>, <span class="cm-variable">t2</span>.<span class="cm-variable">dept_name</span></pre></li>
							<li><pre><span class="cm-keyword">FROM</span> <span class="cm-variable">employees</span> <span class="cm-keyword">AS</span> <span class="cm-variable">t1</span> <span class="cm-keyword">LEFT</span> <span class="cm-keyword">JOIN</span> <span class="cm-variable">departments</span> <span class="cm-keyword">AS</span> <span class="cm-variable">t2</span></pre></li>
							<li><pre><span class="cm-keyword">ON</span> <span class="cm-variable">t1</span>.<span class="cm-variable">dept_id</span> = <span class="cm-variable">t2</span>.<span class="cm-variable">dept_id</span>;</pre></li>
                        </ul>
                    </div>
                </div>
                <!--End:Code box-->
				<p>After updating the view, if you execute the following statement:</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=sql&amp;file=querying-a-view" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <ul class="syntax-highlighter sql">
                            <li><pre><span class="cm-keyword">SELECT</span> * <span class="cm-keyword">FROM</span> <span class="cm-variable">emp_dept_view</span> <span class="cm-keyword">ORDER</span> <span class="cm-keyword">BY</span> <span class="cm-variable">emp_id</span>;</pre></li>
                        </ul>
                    </div>
                </div>
                <!--End:Code box-->
				<p>You will see one more column <i>salary</i> in the resulting output, as follow:</p>
<pre class="console-output break">
+--------+--------------+--------+-----------------+
| emp_id | emp_name     | salary | dept_name       |
+--------+--------------+--------+-----------------+
|      1 | Ethan Hunt   |   5000 | Human Resources |
|      2 | Tony Montana |   6500 | Administration  |
|      3 | Sarah Connor |   8000 | Sales           |
|      4 | Rick Deckard |   7200 | Finance         |
|      5 | Martin Blank |   5600 | NULL            |
+--------+--------------+--------+-----------------+
</pre>
				<!--Note box-->
				<div class="color-box break">
					<div class="shadow">
						<div class="info-tab note-icon" title="Important Notes"><i></i></div>
						<div class="note-box">
							<p><strong>Note:</strong> SQL Server doesn't support the <code>OR REPLACE</code> clause, therefore to replace the view you can simply drop that view and create a new one from stretch.</p>
						</div>
					</div>
				</div>
				<!--End:Note box-->
				<hr />
				<h2>Updating Data Through a View</h2>
				<p>Theoretically, you can also perform <code><a href="sql-insert-statement.php">INSERT</a></code>, <code><a href="sql-update-statement.php">UPDATE</a></code>, and <code><a href="sql-delete-statement.php">DELETE</a></code> on views in addition to the <code><a href="sql-select-statement.php">SELECT</a></code> statement. However, not all views are updatable i.e. capable of modifying the data of an underlying source table. There are some restrictions on the updatability.</p>
				<p>Generally a view is not updatable if it contains any of the following:</p>
				<ul>
					<li>The <code>DISTINCT</code>, <code>GROUP BY</code> or <code>HAVING</code> clauses.</li>
					<li>Aggregate functions such as <code>AVG()</code>, <code>COUNT()</code>, <code>SUM()</code>, <code>MIN()</code>, <code>MAX()</code>, and so forth.</li>
					<li>The <code>UNION</code>, <code>UNION ALL</code>, <code>CROSSJOIN</code>, <code>EXCEPT</code> or <code>INTERSECT</code> operators.</li>
					<li>Subquery in the <code>WHERE</code> clause that refers to a table in the <code>FROM</code> clause.</li>
				</ul>
				<p>If a view satisfies these conditions, you can modify the source table using that view.</p>
				<p>The following statement will update the <i>salary</i> of the employee whose <i>emp_id</i> is equal to 1.</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="javascript:void(0);" target="_blank" class="try-btn disabled" title="Not Supported in Web SQL">Try this code <span>&raquo;</span></a></div>
                        <ul class="syntax-highlighter sql">
                            <li><pre><span class="cm-keyword">UPDATE</span> <span class="cm-variable">emp_dept_view</span> <span class="cm-keyword">SET</span> <span class="cm-variable">salary</span> = <span class="cm-string">'6000'</span> </pre></li>
							<li><pre><span class="cm-keyword">WHERE</span> <span class="cm-variable">emp_id</span> = <span class="cm-variable">1</span>;</pre></li>
                        </ul>
                    </div>
                </div>
                <!--End:Code box-->
				<!--Note box-->
				<div class="color-box">
					<div class="shadow">
						<div class="info-tab note-icon" title="Important Notes"><i></i></div>
						<div class="note-box">
							<p><strong>Note:</strong> For insertability, the view must contain all columns in the base table that do not have a default value. Similarly, for updatability each updatable column in the view must correspond to an updatable column in a source table.</p>
						</div>
					</div>
				</div>
				<!--End:Note box-->
				<hr />
				<h2>Dropping a View</h2>
				<p>Similarly, if you no longer need a view, you can use the <code>DROP VIEW</code> statement to drop it from the database, as shown in the following syntax:</p>
				<div class="shadow">
                    <div class="syntax sql"><span class="keyword">DROP VIEW</span> <em title="Replaceable">view_name</em>;</div>
                </div>
				<p>The following command will drop the view <i>emp_dept_view</i> from the database.</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=sql&amp;file=remove-a-view-from-the-database" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <ul class="syntax-highlighter sql">
                            <li><pre><span class="cm-keyword">DROP</span> <span class="cm-keyword">VIEW</span> <span class="cm-variable">emp_dept_view</span>;</pre></li>
                        </ul>
                    </div>
                </div>
                <!--End:Code box-->
				<!--Bottom Navigation-->
                <div class="bottom-link clearfix">
                    <a href="sql-having-clause.php" class="previous-page-bottom">Previous Page</a>
                    <a href="sql-create-index-statement.php" class="next-page-bottom">Next Page</a>
                </div>
                <!--End:Bottom Navigation-->
                <!-- InstanceEndEditable -->
                <!--Bottom Ads-->
                <div class="bottom-ad clearfix">
                    <div class="ad-label">Advertisements</div>

<!--Rectangle Left-->
<div class="rectangle-left fl">
    
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Large Rectangle Left -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="8162953958"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
<!--End:Rectangle Left-->


<!--Rectangle Right-->
<div class="rectangle-right fr">

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Large Rectangle Right -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="3324015654"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
<!--End:Rectangle Right-->                </div>
                <!--End:Bottom Ads-->
            </div>
            <!--End:Text Content-->
            <!--Feedback Form-->
			<div class="snippets">
	<a href="/snippets/gallery.php" target="_blank">
    	<img src="/lib/images/bootstrap-code-snippets.png" alt="Bootstrap UI Design Templates" />
	</a>
</div>

<div class="report-error" id="feedback">
    <div class="contact-form clearfix">
        <div class="close"><span class="icon-close"></span></div>
        <form id="feedback-form">
            <h3>Your Feedback:</h3>
            <div class="clearfix">
                <div class="name fl"><label>Your Name (optional) <input type="text" name="user-name" id="user-name" /></label></div>
                <div class="email fr"><label>Your E-mail (optional) <input type="text" name="user-email" id="user-email" /></label></div>
            </div>
            <div><label>Page address <input type="text" name="page-url" id="page-url" class="disabled" disabled="disabled" /></label></div>
            <div><label>Description <textarea name="description" id="description" rows="6"></textarea></label></div>
            <p id="feedback-error">We would love to hear from you, please drop us a line.</p>
            <div><button type="button" class="action-btn" onclick="sendFeedback()"><span class="icon-send"></span> Send</button></div>
        </form>
        <div id="response"></div>
    </div>           
</div>            <!--End:Feedback Form-->
        </div>        
        <div class="sidebar">
            <div class="ad-label">Advertisements</div>

<div class="skyscraper primary">

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Premium Skyscraper -->
<ins class="adsbygoogle"
     style="display:inline-block;width:160px;height:600px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="4376141825"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>

<div class="skyscraper">
    
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Bottom Skyscraper -->
<ins class="adsbygoogle"
     style="display:inline-block;width:160px;height:600px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="3387984471"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>        </div>
    </div>
    <!--Footer-->
	<!--Footer-->
<div class="footer">
    <div class="appeal">
        <div class="wrapper">
            <p>Is this website helpful to you? Please give us a
            <a href="/like.php" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=250,width=600,top=150, left='+((screen.width/2)-300));return false;">like</a>,
            or share your <a href="#feedback" class="feedback">feedback</a><em> to help us improve</em>.
            Connect with us on <a href="https://www.facebook.com/tutorialrepublic" target="_blank">Facebook</a> and <a href="https://twitter.com/tutrepublic" target="_blank">Twitter</a> for the latest updates.</p>               
        </div>
    </div>
    <div class="footer-inner">
        <div class="wrapper clearfix">                
            <div class="link-box">
                <h4>About Us</h4>
                <div class="clearfix">
                    <a href="/about-us.php">Our Story</a>                    
                    <a href="/terms-of-use.php">Terms of Use</a>
                    <a href="/privacy-policy.php">Privacy Policy</a>                    
                </div>
            </div>
            <div class="link-box">
                <h4>Contact</h4>
                <div class="clearfix">
                    <a href="/contact-us.php">Contact Us</a>                    
                    <a href="#feedback" class="feedback">Report Error</a>
                    <a href="/advertise-with-us.php">Advertise</a>                    
                </div>
            </div>
            <div class="tool-box">
                <h4>Interactive Tools</h4>
                <div class="tools-list clearfix" id="tools">
                    <a href="/faq/what-is-the-maximum-length-of-title-and-meta-description-tag.php">Title &amp; Meta Length Calculator</a>                           
                    <a href="/html-formatter.php" target="_blank">HTML Formatter</a>                        
                    <a href="/twitter-bootstrap-button-generator.php" target="_blank">Bootstrap Button Generator</a>
                    <a href="/html-reference/html-color-picker.php">HTML Color Picker</a>
                    <a href="/codelab.php?topic=sql&amp;file=select-all" target="_blank">SQL Playground</a>
                    <a href="/codelab.php?topic=html&amp;file=hello-world" target="_blank">HTML Editor</a>                    
                </div>
            </div>
            <div class="footer-logo">
                <img src="/lib/images/logo.svg" alt="TutorialRepublic" />
            </div>
        </div>
    </div>           
        <div class="bottom-strip">
        <div class="wrapper">
            <div class="notice">Copyright &copy; 2019 Tutorial Republic. All Rights Reserved.</div>
            <div class="social-media">
                <em>Share This:</em>
                <a href="https://facebook.com/sharer.php?u=https://www.tutorialrepublic.com%2Fsql-tutorial%2Fsql-create-view-statement.php" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" title="Facebook"><i class="icon-facebook"></i></a>
                <a href="#" id="tweet-btn" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" title="Twitter"><i class="icon-twitter"></i></a>
                <a href="#" id="email-btn" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" rel="noreferrer" title="Gmail"><i class="icon-mail"></i></a>
            </div>
        </div>            
    </div>
    <script>
        var title = document.title.replace('- Tutorial Republic', '');
        document.getElementById('tweet-btn').href = 'https://twitter.com/share?text=' + title + '- &url=https://www.tutorialrepublic.com%2Fsql-tutorial%2Fsql-create-view-statement.php';
        document.getElementById('email-btn').href = 'https://mail.google.com/mail/?view=cm&fs=1&su=' + title + '&body=https://www.tutorialrepublic.com%2Fsql-tutorial%2Fsql-create-view-statement.php';
    </script>
</div>
<!--End:Footer-->
    
<div class="backdrop mobile-only"></div>

<!-- TutorialRepublic base script -->
<script>
// Adding CSS files
[
	'/lib/styles/extended-3.7.css',
	'/lib/icomoon/style.css'
].forEach(function(href) {
	var link = document.createElement('link');
	link.rel = 'stylesheet';
	link.href = href;
	(document.getElementsByTagName('head')[0]).appendChild(link);
});

// Adding JS files
[
	'https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js',
	'/lib/js/prism.js',
	'/lib/js/default-2.9.min.js'
].forEach(function(src) {
	var script = document.createElement('script');
	script.async = false; // important
	script.src = src;
	(document.getElementsByTagName('body')[0]).appendChild(script);
});
</script>


    <!--End:Footer-->
</body>
<!-- InstanceEnd --></html>