<!DOCTYPE html>
<html lang="en"><!-- InstanceBegin template="/Templates/javascript.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
	<!-- InstanceBeginEditable name="doctitle" -->
    <title>JavaScript ES6 Features - Tutorial Republic</title>
    <!-- InstanceEndEditable -->
    	<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta property="fb:admins" content="100001054961582" />
<meta property="fb:app_id" content="1404574483159557" />
<meta property="og:image" content="/lib/images/signature.png" />
<link type="image/x-icon" href="/favicon.ico" rel="shortcut icon" />
<style>
html,body,h1,h2,h3,h4,h5,h6,p,blockquote,pre,img{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}
html,body{min-height:100%}
p{margin:0 0 12px}
ol,ul{margin:0 0 12px}
a,a:active,a:visited{outline:none;color:#1db79f;text-decoration:none}
a img{border:none;outline:none}
a code{color:inherit;background:none}
p code,table td:last-child code,.content ul li code,code.mark{padding:2px 4px;color:#333;background-color:#f1f1f1;border-radius:4px}
table{border-collapse:collapse;border-spacing:0}
table td{vertical-align:top}
body{min-width:1300px;color:#414141;background:#fafafa;font-family:"Segoe UI","Helvetica Neue",Arial,sans-serif;font-size:17px;line-height:1.7}
input,select,textarea,button,div,span,a{box-sizing:border-box}
h1,h2,h3,h4{color:#262626;font-weight:500;margin:20px 0 10px;line-height:1.5;font-weight:600}
h1{font-size:34px;margin-top:17px}
h2{font-size:28px}
h3{font-size:22px}
.space{margin-bottom:25px!important}
.break{margin-bottom:15px!important}
.text-center{text-align:center!important}
.scroll{height:195px;overflow-y:scroll}
.scroll.large{height:245px}
.scroll.xlarge{height:290px}
.scroll.xxlarge{height:340px}
sup{font-size:13px}
.leaderboard{padding-top:8px;position:relative}
.ad-container{height:90px;overflow:hidden}
.intro-image img{display:block;padding:10px 0 25px;max-width:100%}
.clearfix::after{content:".";display:block;height:0;clear:both;visibility:hidden}
code,.code,.syntax,.green-box,.sky-box,.gray-box,.pink-box,.red-box,.at-rule,.codebox pre,.console-output{font-size:16px;font-family:Consolas,Monaco,Courier,monospace}
.console-output{margin:15px 0}
hr{border:none;border-bottom:1px solid #e7e9ed;height:1px;margin:30px 0}
.summary,.topic{border:1px solid #eaeaea;border-width:1px 0;margin:20px 0;padding:10px 0;color:#8e9aa6;line-height:1.5}
h2.section-title span{display:inline-block;border-bottom:4px solid #c9d7e0;padding:0 50px 12px 0}
.wrapper{width:1300px;padding:0 15px;margin:0 auto}
.header{background:#23384e;padding:16px 0}
input.search{background:#fff;border:0 none;color:#807E7E;float:left;height:38px;line-height:26px;font-size:14px;margin:0 0 0 12px;outline:medium none;padding:6px 14px;width:500px;border-radius:2px;box-shadow:0 0 1px rgba(0,0,0,0.6);font-family:inherit}
.search-btn{color:rgba(0,0,0,.6);background:#ebebeb;border:none;outline:none;cursor:pointer;float:left;height:38px;line-height:46px;width:44px;display:block;margin-left:-2px;border-radius:0 2px 2px 0;box-shadow:0 0 1px rgba(0,0,0,0.7)}
.logo{width:304px}
.logo img{height:44px;margin:-3px 0;display:block}
.site-search{float:left;margin-left:100px}
.menu{background-color:#f5f5f5;box-shadow:0 1px 1px rgba(0,0,0,.15);position:relative;z-index:9}
.menu a{color:#666;display:inline-block;padding:0 10px;text-decoration:none;font-size:14px;font-weight:600;height:48px;line-height:48px}
.menu a:first-child{margin-left:-10px}
.menu a.tool-link{float:right;display:inline-block;border-radius:30px;line-height:28px;position:relative;height:auto;top:9px;padding:0 12px;color:#1ebba3;border:1px double #1ebba3}
.fl,.logo{float:left}
.leftcolumn{width:240px;float:left;font-size:16px;color:#4f4f4f}
.centercolumn{width:850px;float:left}
.content{background:#fff;padding:20px 40px;border:1px solid #dedede;border-top:none;border-radius:1px}
.sidebar{width:160px;float:left;padding-top:28px;margin-left:20px;position:relative}
.leftcolumn .segment{margin:16px 0 12px;position:relative;font-size:18px;font-weight:600;line-height:normal}
.leftcolumn a{color:#4f4f4f;font-size:16px;line-height:26px;display:block;border-bottom:1px solid transparent}
.leftcolumn ul{list-style:none;padding:0}
.segment,.chapters,.chapters a{float:left;clear:both}
h1 code,h2 code,h3 code{font:inherit}
.color-box{margin:15px 0;padding-left:20px}
.note-box,.warning-box,.tip-box{padding:8px 8px 3px 26px}
.info-tab{float:left;margin-left:-23px}
.content ul li{margin-top:7px}
.extra{padding-top:5px}
.green-box,.sky-box,.gray-box,.red-box,.pink-box{color:#000;margin-top:15px;padding:10px;background-color:#f6f8fa;border:1px solid #d7e2ec}
.example{background:#f4f5f6;padding:3px;margin:15px 0}
.codebox{background:#fff;border:1px solid #ddd}
.codebox-title{height:41px;padding-left:12px;border-bottom:1px solid #ddd;background:#f5f5f5}
.codebox-title h4{margin:0;font-size:18px;line-height:40px;float:left;display:inline;font-weight:500}
a.try-btn,a.download-btn{width:140px;height:40px;color:#333;font-size:15px;line-height:41px;font-weight:600;text-align:center;text-decoration:none;float:right;display:block;border-left:1px solid #ddd;background:rgba(27,31,35,0.08);box-sizing:border-box;font-family:Arial,sans-serif}
a.try-btn span{font-size:18px;line-height:normal}
.hide,.code-style,.box-size,.bottom-link,.footer,.code-style,.snippets,.report-error,.badge,.social,.ad-label,.mobile-only{display:none}
.skyscraper{width:160px;height:600px;overflow:hidden;margin-bottom:20px;background:#ebecf0}
.bottom-ad{margin-top:46px;padding:24px;position:relative;background:url(/lib/images/smooth-line.png) no-repeat center #f9f9f9}
.rectangle-left,.rectangle-right{min-width:336px;min-height:280px;overflow:hidden}
.fr,a.previous-page,a.next-page,.rectangle-right,.topic-nav{float:right}
a.previous-page,a.next-page{width:32px;height:32px;line-height:30px}
.shadow{background:#F7F8F9;padding:3px;margin:10px 0}
.syntax{color:#2f4959;padding:13px 18px;background:#F9F9FA;border:1px solid #ddd;font-size:15px}
code[class*="language-"],pre[class*="language-"]{color:#000;background:none;font-family:Consolas,Monaco,'Andale Mono','Ubuntu Mono',monospace;text-align:left;white-space:pre;word-break:normal;word-wrap:normal;line-height:1.5;tab-size:4;hyphens:none}
pre[class*="language-"]{position:relative;margin:.5em 0;overflow:visible;padding:0}
pre[class*="language-"]>code{position:relative;border-left:10px solid #358ccb;box-shadow:-1px 0 0 0 #358ccb,0 0 0 1px #dfdfdf;background-color:#fdfdfd;background-image:linear-gradient(transparent 50%,rgba(69,142,209,0.04) 50%);background-size:3em 3em;background-origin:content-box;background-attachment:local}
code[class*="language"]{max-height:inherit;height:inherit;padding:0 1em;display:block;overflow:auto}
:not(pre) > code[class*="language-"]{position:relative;padding:.2em;border-radius:.3em;color:#c92c2c;border:1px solid rgba(0,0,0,0.1);display:inline;white-space:normal}
pre[class*="language-"].line-numbers{padding-left:0}
pre[class*="language-"].line-numbers code{padding-left:3.8em}
pre[class*="language-"].line-numbers .line-numbers-rows{left:0}
pre[class*="language-"][data-line]{padding-top:0;padding-bottom:0;padding-left:0}
pre[data-line] code{position:relative;padding-left:4em}
pre .line-highlight{margin-top:0}
pre.line-numbers{position:relative;padding-left:3.8em;counter-reset:linenumber;white-space:pre-wrap!important}
pre.line-numbers > code{position:relative;white-space:inherit}
.line-numbers-rows,.codebox pre.inactive{display:none}
.codebox pre.syntax-highlighter{margin:0;padding:0;overflow:auto}
pre.line-numbers .line-numbers-rows{border-right:3px solid #6CE26C}
.codebox pre.syntax-highlighter > code{box-shadow:none!important;padding-left:3.8em;background-image:linear-gradient(transparent 50%,#F8F8F8 50%);font-family:Consolas,Monaco,'Andale Mono','Ubuntu Mono',monospace!important;font-size:16px;line-height:1.5}
.codebox pre.syntax-highlighter,.codebox pre.syntax-highlighter code{border:none;width:100%;box-sizing:border-box}
pre.line-numbers code,pre.line-numbers .line-numbers-rows{padding-top:2px;padding-bottom:2px}
.preview-box{padding:15px;text-align:center;cursor:pointer;overflow:hidden;background:#FFF;border:1px solid #e6e6e6}
.preview-box a,.preview-box img{display:block;margin:0 auto}
.download-box{text-align:center;padding:20px 0;margin:20px 0 10px}
.output-box{border-color:#d4d4d4;border-style:solid;border-width:1px 0;padding:5px 15px;overflow:hidden;background:#fff;margin:10px 0}
.demo-box{margin-top:15px}
.subhead{border-bottom:3px solid #DCE3EB;margin-bottom:15px;padding-bottom:10px}
table.data,table.description{width:100%;font-size:92%}
table.data th{color:#000;padding:8px 7px;text-align:left;font-size:15px;background:#F8F8F8}
table.data td{color:#484848;padding:5px 7px;background:#fff}
table.data th,table.data td{vertical-align:top;border:1px solid #DCE3EB}
table.data tr.section th,table.data td.section{font-size:15px;background:#f0f4f7}
table.no-wrap tr td:first-child{white-space:nowrap}
@media screen and (max-width: 1280px) {
body{min-width:1260px}
.wrapper{width:1260px}
.leftcolumn{width:230px}
.centercolumn{width:820px}
}
@media screen and (max-width: 800px) {
body{min-width:100%;max-width:100%;padding-top:46px}
.wrapper{width:100%;padding:0}
.header{height:46px;padding:5px 0;position:fixed;top:0;left:0;right:0;width:100%;z-index:99}
.logo{width:auto;display:block;padding:6px 0 0 60px;position:absolute;left:0;z-index:100}
.logo img{height:30px}
.menu{width:100%;padding-left:12px;padding-right:12px;overflow-x:auto;white-space:nowrap}
.centercolumn{width:100%;float:none}
.content{padding:10px;border-width:0 0 1px 0}
.content img{max-width:100%;height:auto}
.content pre{max-width:100%;overflow:hidden}
.skyscraper{display:inline-block}
.shadow,.example,.console-output{max-width:100%;overflow-x:auto}
.codebox-title{position:relative}
.codebox.multi-style-mode pre{padding-top:7px;margin-top:36px;border-top:1px solid #ddd}
.bottom-ad{height:auto;background:none;padding:30px 0 0;margin:40px 0 0;text-align:center;position:relative}
.rectangle-left,.rectangle-right{float:none;display:inline-block;margin:10px auto;background:#EDEEF2}
.leftcolumn,.footer,.social,.site-search,.code-style,.menu a.tool-link,.backdrop{display:none}
.summary,.topic{padding:5px 0;margin:10px 0}
.leftcolumn,.centercolumn,.sidebar{float:none}
.header,.menu,.centercolumn,.footer,.appeal-text{width:100%}
a.try-btn,a.download-btn{width:130px}
.native-unit{margin-bottom:30px}
.sidebar{margin: 25px auto 0}
.overview{padding-right:0}
.scroll-pane{overflow-x:auto}
table.data{min-width:480px}
table.data pre{display:inline;white-space:normal}
table tr th,table tr td{width:auto!important}
.preview-box{padding:6px}
.leaderboard{margin:20px 0}
h1{font-size:30px}
h2{font-size:24px}
h3{font-size:20px}
.codebox pre.syntax-highlighter{overflow-x:auto}
.codebox pre.syntax-highlighter > code{width:614px;height:auto;overflow-x:hidden}
}
@media screen and (min-width: 801px) {
.site-search,.leftcolumn,.social{display:block!important}
.backdrop{display:none!important}
.hide-scroll{overflow-x:hidden!important}
}</style>    
    <!-- InstanceBeginEditable name="head" -->
    <!-- InstanceEndEditable -->
    
    <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-40117907-1', 'auto');
  ga('send', 'pageview');
</script></head>
<body>
    <!--Header-->
    
<div class="header">
    <div class="wrapper clearfix">
        <button type="button" class="open-menu mobile-only"><i class="icon-menu"></i></button>
        <div class="logo">
            <a href="https://www.tutorialrepublic.com/"><img src="/lib/images/logo.svg" alt="TutorialRepublic" /></a>
        </div>
        <div class="site-search">
            <form action="https://www.google.com/search" method="get" target="_blank" class="clearfix">
                <input type="hidden" value="www.tutorialrepublic.com" name="sitesearch" />
                <input type="text" name="q" placeholder="Search topics, tutorials, questions and answers..." id="searchInput" class="search" />
                <button type="submit" class="search-btn"><span class="icon-search"></span></button>
            </form>
        </div>
        <div class="social">                
            <a href="https://www.facebook.com/tutorialrepublic" target="_blank" title="Join us on Facebook"><i class="icon-facebook"></i></a>
            <a href="https://twitter.com/tutrepublic" target="_blank" title="Follow us on Twitter"><i class="icon-twitter"></i></a>
            <a href="/contact-us.php" target="_blank" title="Send us an Email"><i class="icon-mail"></i></a>
        </div>
        <button type="button" class="open-search mobile-only">
            <i class="icon-search"></i>
        </button>
    </div>    
</div>
<div class="menu">
    <div class="wrapper">
        <a href="//www.tutorialrepublic.com" title="Home Page">HOME</a>
        <a href="/html-tutorial/" title="HTML Tutorial">HTML5</a>            
        <a href="/css-tutorial/" title="CSS Tutorial">CSS3</a>
        <a href="/javascript-tutorial/" title="JavaScript Tutorial">JAVASCRIPT</a>
        <a href="/jquery-tutorial/" title="jQuery Tutorial">JQUERY</a>
        <a href="/twitter-bootstrap-tutorial/" title="Bootstrap Tutorial">BOOTSTRAP4</a>
        <a href="/php-tutorial/" title="PHP Tutorial">PHP7</a> 
        <a href="/sql-tutorial/" title="SQL Tutorial">SQL</a>
        <a href="/references.php" title="Web References">REFERENCES</a>
        <a href="/practice-examples.php" title="Practice Examples and Demos">EXAMPLES</a>
        <a href="/faq.php" title="Frequently Asked Questions and Answers">FAQ</a>
        <a href="/snippets/gallery.php" title="Bootstrap Code Snippets" target="_blank">SNIPPETS</a>
        <a href="/codelab.php" class="tool-link" target="_blank">Online HTML Editor</a>
    </div>        
</div>    <!--End:Header-->
    <div class="wrapper clearfix">
        <div class="leftcolumn" id="myNav">
		
        <div class="segment"><span>JAVASCRIPT</span> BASIC</div>
<div class="chapters">
    <a href="/javascript-tutorial/">JS Introduction</a>
    <a href="/javascript-tutorial/javascript-get-started.php">JS Getting Started</a>
    <a href="/javascript-tutorial/javascript-syntax.php">JS Syntax</a>
	<a href="/javascript-tutorial/javascript-variables.php">JS Variables</a>
	<a href="/javascript-tutorial/javascript-generating-output.php">JS Generating Output</a>
	<a href="/javascript-tutorial/javascript-data-types.php">JS Data Types</a>
	<a href="/javascript-tutorial/javascript-operators.php">JS Operators</a>	
	<a href="/javascript-tutorial/javascript-events.php">JS Events</a>
	<a href="/javascript-tutorial/javascript-strings.php">JS Strings</a>
    <a href="/javascript-tutorial/javascript-numbers.php">JS Numbers</a>
	<a href="/javascript-tutorial/javascript-if-else-statements.php">JS If&hellip;Else</a>
	<a href="/javascript-tutorial/javascript-switch-case-statements.php">JS Switch&hellip;Case</a>	
    <a href="/javascript-tutorial/javascript-arrays.php">JS Arrays</a>
    <a href="/javascript-tutorial/javascript-sorting-arrays.php">JS Sorting Arrays</a>
	<a href="/javascript-tutorial/javascript-loops.php">JS Loops</a>
	<a href="/javascript-tutorial/javascript-functions.php">JS Functions</a>
	<a href="/javascript-tutorial/javascript-objects.php">JS Objects</a>
</div>
<div class="segment"><span>JAVASCRIPT</span> &amp; DOM</div>
<div class="chapters">
    <a href="/javascript-tutorial/javascript-dom-nodes.php">JS DOM Nodes</a>
	<a href="/javascript-tutorial/javascript-dom-selectors.php">JS DOM Selectors</a>
	<a href="/javascript-tutorial/javascript-dom-styling.php">JS DOM Styling</a>
	<a href="/javascript-tutorial/javascript-dom-get-set-attributes.php">JS DOM Get Set Attributes</a>
	<a href="/javascript-tutorial/javascript-dom-manipulation.php">JS DOM Manipulation</a>
    <a href="/javascript-tutorial/javascript-dom-navigation.php">JS DOM Navigation</a>
</div>
<div class="segment"><span>JAVASCRIPT</span> &amp; BOM</div>
<div class="chapters">
	<a href="/javascript-tutorial/javascript-window.php">JS Window</a>
	<a href="/javascript-tutorial/javascript-window-screen.php">JS Screen</a>
	<a href="/javascript-tutorial/javascript-window-location.php">JS Location</a>
	<a href="/javascript-tutorial/javascript-window-history.php">JS History</a>
    <a href="/javascript-tutorial/javascript-window-navigator.php">JS Navigator</a>
    <a href="/javascript-tutorial/javascript-dialog-boxes.php">JS Dialog Boxes</a>
	<a href="/javascript-tutorial/javascript-timers.php">JS Timers</a>
</div>
<div class="segment"><span>JAVASCRIPT</span> ADVANCED</div>
<div class="chapters">
	<a href="/javascript-tutorial/javascript-date-and-time.php">JS Date and Time</a>
	<a href="/javascript-tutorial/javascript-math-operations.php">JS Math Operations</a>
	<a href="/javascript-tutorial/javascript-type-conversions.php">JS Type Conversions</a>
	<a href="/javascript-tutorial/javascript-event-listeners.php">JS Event Listeners</a>
	<a href="/javascript-tutorial/javascript-event-propagation.php">JS Event Propagation</a>
    <a href="/javascript-tutorial/javascript-borrowing-methods.php">JS Borrowing Methods</a>
    <a href="/javascript-tutorial/javascript-hoisting.php">JS Hoisting Behavior</a>
	<a href="/javascript-tutorial/javascript-closures.php">JS Closures</a>
	<a href="/javascript-tutorial/javascript-strict-mode.php">JS Strict Mode</a>   
	<a href="/javascript-tutorial/javascript-json-parsing.php">JS JSON Parsing</a>
    <a href="/javascript-tutorial/javascript-error-handling.php">JS Error Handling</a>
	<a href="/javascript-tutorial/javascript-regular-expressions.php">JS Regular Expressions</a>
	<a href="/javascript-tutorial/javascript-form-validation.php">JS Form Validation</a>
	<a href="/javascript-tutorial/javascript-cookies.php">JS Cookies</a>
	<a href="/javascript-tutorial/javascript-ajax.php">JS AJAX Requests</a>
	<a href="/javascript-tutorial/javascript-es6-features.php">JS ES6 Features</a>
</div>
<div class="segment"><span>JAVASCRIPT</span> EXAMPLES</div>
<div class="chapters">
    <a href="/javascript-examples.php">JS Practice Examples</a>
	<a href="/faq.php#javascript-jquery">JS FAQ's Answers</a>
</div>
<div class="segment"><span>JAVASCRIPT</span> REFERENCE</div>
<ul class="chapters tree-menu">
    <li class="tree"><span class="shorthand">JS&nbsp;Properties&nbsp;and&nbsp;Methods</span>
        <ul class="hide">
			<li><a href="/javascript-reference/javascript-array-object.php">JS Array Object</a></li>
			<li><a href="/javascript-reference/javascript-boolean-object.php">JS Boolean Object</a></li> 
			<li><a href="/javascript-reference/javascript-date-object.php">JS Date Object</a></li> 
			<li><a href="/javascript-reference/javascript-math-object.php">JS Math Object</a></li> 
			<li><a href="/javascript-reference/javascript-number-object.php">JS Number Object</a></li> 
            <li><a href="/javascript-reference/javascript-string-object.php">JS String Object</a></li> 			         
        </ul>
	<li><a href="/javascript-reference/javascript-reserved-keywords.php">JS Reserved Keywords</a></li>    
	<li><a href="/references.php" class="more">More References</a></li>
</ul>        
                </div>
        <div class="centercolumn">
            <!--Text Content-->
            <div class="content">
                <div class="leaderboard">
                    
<div class="ad-label">Advertisements</div>
<div class="ad-container">
    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <!-- Responsive Leaderboard -->
    <ins class="adsbygoogle"
            style="display:inline-block;max-width:728px;width:100%;height:90px"
            data-ad-client="ca-pub-9107540490929984"
            data-ad-slot="4302666817"></ins>
    <script>
    (adsbygoogle = window.adsbygoogle || []).push({});
    </script>
</div>                </div>
                <!-- InstanceBeginEditable name="main_content" -->
                <a href="javascript-ajax.php" class="previous-page" title="Go to Previous Page"></a>
            	<a href="/javascript-examples.php" class="next-page" title="Go to Next Page"></a>
                <h1>JavaScript <span>ES6 Features</span></h1>
                <p class="summary">In this tutorial you will learn about the new features in latest version of JavaScript.</p>
				<h2>What is ECMAScript 6 (or ES6)</h2>
				<p>ECMAScript 2015 (or ES6) is the sixth and major edition of the ECMAScript language specification standard. It defines the standard for the JavaScript implementation.</p>
				<p class="space">ES6 brought significant changes to the JavaScript language. It introduces several new features such as, block-scoped variables, new loop for iterating over arrays and objects, template literals, and many other enhancements to make JavaScript programming easier and more fun. In this chapter, we will discuss some of the best ES6 features that you can use in your everyday JavaScript coding.</p>
				<h2 id="let-keyword">The <code>let</code> Keyword</h2>
				<p>ES6 introduces the new <code>let</code> keyword for declaring variables. Prior to ES6, the only way to declare a variable in JavaScript was the <code>var</code> keyword. Let's see what's the difference between them is.</p>
				<p>There are two critical differences between the <code>var</code> and <code>let</code>. Variables declared with the <code>var</code> keyword are <a href="javascript-functions.php#variable-scope">function-scoped</a> and <a href="javascript-hoisting.php">hoisted</a> at the top within its scope, whereas variables declared with <code>let</code> keyword are block-scoped (<code>{}</code>) and they are not hoisted.</p>
				<p>Block scoping simply means that a new scope is created between a pair of curly brackets i.e. <code>{}</code>. Therefore, if you declare a variable with the <code>let</code> keyword inside a loop, it does not exist outside of the loop, as demonstrated in the following example:</p>
				<!--Code box-->
				<div class="example break">
					<div class="codebox">
						<div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=es6-let-keyword" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
						<pre class="syntax-highlighter line-numbers"><code class="language-javascript">// ES6 syntax
for(let i = 0; i &lt; 5; i++) {
    console.log(i); // 0,1,2,3,4
}
console.log(i); // undefined


// ES5 syntax
for(var i = 0; i &lt; 5; i++) {
    console.log(i); // 0,1,2,3,4
}
console.log(i); // 5</code></pre>
					</div>
				</div>				
                <!--End:Code box-->
				<p>As you can see in the above example the variable <code>i</code> in the first block is not accessible outside the <code>for</code> loop. This also enables us to reuse the same variable name multiple times as its scope is limited to the block (<code>{}</code>), which results in less variable declaration and more cleaner code.</p>
				<hr />
				<h2>The <code>const</code> Keyword</h2>
				<p>The new <code>const</code> keyword makes it possible to define constants. Constants are read-only, you cannot reassign new values to them. They are also block-scoped like <code>let</code>.</p>
				<!--Code box-->
				<div class="example break">
					<div class="codebox">
						<div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=es6-const-keyword" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
						<pre class="syntax-highlighter line-numbers"><code class="language-javascript">const PI = 3.14;
console.log(PI); // 3.14

PI = 10; // error</code></pre>
					</div>
				</div>
                <!--End:Code box-->
				<p>However, you can still change object properties or array elements:</p>
				<!--Code box-->
				<div class="example break">
					<div class="codebox">
						<div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=es6-constants-are-not-truly-immutable" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
						<pre class="syntax-highlighter line-numbers"><code class="language-javascript">// Changing object property value
const PERSON = {name: "Peter", age: 28};
console.log(PERSON.age); // 28
PERSON.age = 30;
console.log(PERSON.age); // 30

// Changing array element
const COLORS = ["red", "green", "blue"];
console.log(COLORS[0]); // red
COLORS[0] = "yellow";
console.log(COLORS[0]); // yellow</code></pre>
					</div>
				</div>
                <!--End:Code box-->
				<hr />
				<h2>The <code>for...of</code> Loop</h2>
				<p>The new <code>for...of</code> loop allows us to iterate over arrays or other iterable objects very easily. Also, the code inside the loop is executed for each element of the iterable object. Here's an example:</p>
				<!--Code box-->
				<div class="example break">
					<div class="codebox">
						<div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=es6-for-of-loop" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
						<pre class="syntax-highlighter line-numbers"><code class="language-javascript">// Iterating over array
let letters = ["a", "b", "c", "d", "e", "f"];

for(let letter of letters) {
    console.log(letter); // a,b,c,d,e,f
}

// Iterating over string
let greet = "Hello World!";

for(let character of greet) {
    console.log(character); // H,e,l,l,o, ,W,o,r,l,d,!
}</code></pre>
					</div>
				</div>
                <!--End:Code box-->
				<p>The <code>for...of</code> loop doesn't work with objects because they are not iterable. If you want to iterate over the properties of an object you can use the <a href="javascript-loops.php#for-in"><code>for-in</code></a> loop.</p>
				<hr />
				<h2 id="template-literals">Template Literals</h2>
				<p>Template literals provide an easy and clean way create multi-line strings and perform string interpolation. Now we can embed variables or expressions into a string at any spot without any hassle.</p>
				<p>Template literals are created using back-tick (<code>` `</code>) (grave accent) character instead of the usual double or single quotes. Variables or expressions can be placed inside the string using the <code>${...}</code> syntax. Compare the following examples and see how much useful it is:</p>
				<!--Code box-->
				<div class="example break">
					<div class="codebox">
						<div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=es6-template-literals" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
						<pre class="syntax-highlighter line-numbers"><code class="language-javascript">// Simple multi-line string
let str = `The quick brown fox
    jumps over the lazy dog.`;

// String with embedded variables and expression
let a = 10;
let b = 20;
let result = `The sum of ${a} and ${b} is ${a+b}.`;
console.log(result); // The sum of 10 and 20 is 30.</code></pre>
					</div>
				</div>
                <!--End:Code box-->
				<p>While in ES5, to achieve the same we had to write something like this:</p>
				<!--Code box-->
				<div class="example break">
					<div class="codebox">
						<div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=creating-multi-line-strings-in-older-versions" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
						<pre class="syntax-highlighter line-numbers"><code class="language-javascript">// Multi-line string
var str = 'The quick brown fox\n\t'
    + 'jumps over the lazy dog.';

// Creating string using variables and expression
var a = 10;
var b = 20;
var result = 'The sum of ' + a + ' and ' + b + ' is ' + (a+b) + '.';
console.log(result); // The sum of 10 and 20 is 30.</code></pre>
					</div>
				</div>
                <!--End:Code box-->
				<hr />
				<h2>Default Values for Function Parameters</h2>
				<p>Now, in ES6 you can specify default values to the <a href="javascript-functions.php#parameters">function parameters</a>. This means that if no arguments are provided to function when it is called these default parameters values will be used. This is one of the most awaited features in JavaScript. Here's an example:</p>
				<!--Code box-->
				<div class="example break">
					<div class="codebox">
						<div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=es6-function-with-default-parameter-values" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
						<pre class="syntax-highlighter line-numbers"><code class="language-javascript">function sayHello(name='World') {
    return `Hello ${name}!`;
}

console.log(sayHello()); // Hello World!
console.log(sayHello('John')); // Hello John!</code></pre>
					</div>
				</div>
                <!--End:Code box-->
				<p>While in ES5, to achieve the same we had to write something like this:</p>
				<!--Code box-->
				<div class="example break">
					<div class="codebox">
						<div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=setting-default-values-for-function-parameters-in-older-versions" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
						<pre class="syntax-highlighter line-numbers"><code class="language-javascript">function sayHello(name) {
    var name = name || 'World'; 
    return 'Hello ' +  name + '!';
}

console.log(sayHello()); // Hello World!
console.log(sayHello('John')); // Hello John!</code></pre>
					</div>
				</div>
                <!--End:Code box-->
				<hr />
				<h2 id="arrow-functions">Arrow Functions</h2>
				<p>Arrow Functions are another interesting feature in ES6. It provides a more concise syntax for writing <a href="javascript-functions.php#function-expressions">function expressions</a> by opting out the <code>function</code> and <code>return</code> keywords.</p>
				<p>Arrow functions are defined using a new syntax, the fat arrow (<code>=&gt;</code>) notation. Let's see how it looks:</p>
				<!--Code box-->
				<div class="example break">
					<div class="codebox">
						<div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=es6-arrow-functions" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
						<pre class="syntax-highlighter line-numbers"><code class="language-javascript">// Function Expression
var sum = function(a, b) {
    return a + b;
}
console.log(sum(2, 3)); // 5

// Arrow function
var sum = (a, b) => a + b;
console.log(sum(2, 3)); // 5</code></pre>
					</div>
				</div>
                <!--End:Code box-->
				<p>As you can see thre is no <code>function</code> and <code>return</code> keyword in arrow function declaration.</p>
				<p>You can also skip the parentheses i.e. <code>()</code> in case when there is exactly one parameter, but you will always need to use it when you have zero or more than one parameter.</p>
				<p>Additionally, if there's more than one expression in the function body, you need to wrap it braces (<code>{}</code>). In this case you also need to use the <code>return</code> statement to return a value.</p>
				<p>There are several variations of how you can write arrow functions. Here are the most commonly used:</p>
				<!--Code box-->
				<div class="example break">
					<div class="codebox">
						<div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=es6-arrow-function-variations" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
						<pre class="syntax-highlighter line-numbers"><code class="language-javascript">// Single parameter, single statement
var greet = name => alert("Hi " + name + "!");
greet("Peter"); // Hi Peter!

// Multiple arguments, single statement
var multiply = (x, y) => x * y;
alert(multiply(2, 3)); // 6


// Single parameter, multiple statements
var test = age => {
    if(age > 18) {
        alert("Adult");
    } else {
        alert("Teenager");
    }
}
test(21); // Adult

// Multiple parameters, multiple statements
var divide = (x, y) => {
    if(y != 0) {
        return x / y;
    }
}
alert(divide(10, 2)); // 5

// No parameter, single statement
var hello = () => alert('Hello World!');
hello(); // Hello World!</code></pre>
					</div>
				</div>
                <!--End:Code box-->				
				<p>There is an important difference between regular functions and arrow functions. Unlike a normal function, an arrow function does not have its own <code>this</code>, it takes <code>this</code> from the outer function where it is defined. In JavaScript, <code>this</code> is the current execution context of a function.</p>
				<p>To understand this clearly, let's check out the following examples:</p>
				<!--Code box-->
				<div class="example break">
					<div class="codebox">
						<div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=this-keyword-value-inside-a-simple-function" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
						<pre class="syntax-highlighter line-numbers"><code class="language-javascript">function Person(nickname, country) {
    this.nickname = nickname;
    this.country = country;
    
    this.getInfo = function() {
        // Outer function context (Person object)
        return function() {
            // Inner function context (Global object 'Window')
            alert(this.constructor.name); // Window
            alert("Hi, I'm " + this.nickname + " from " + this.country);
        };
    }
}

var p = new Person('Rick', 'Argentina');
var printInfo = p.getInfo();
printInfo(); // Hi, I'm undefined from undefined</code></pre>
					</div>
				</div>
                <!--End:Code box-->
				<p>Rewriting the same example using ES6 template literals and arrow function:</p>
				<!--Code box-->
				<div class="example break">
					<div class="codebox">
						<div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=this-keyword-value-inside-an-arrow-function" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
						<pre class="syntax-highlighter line-numbers"><code class="language-javascript">function Person(nickname, country) {
    this.nickname = nickname;
    this.country = country;
    
    this.getInfo = function() {
        // Outer function context (Person object)
        return () => {
            // Inner function context (Person object)
            alert(this.constructor.name); // Person
            alert(`Hi, I'm ${this.nickname} from ${this.country}`);
        };
    }
}

let p = new Person('Rick', 'Argentina');
let printInfo = p.getInfo();
printInfo(); // Hi, I'm Rick from Argentina</code></pre>
					</div>
				</div>
                <!--End:Code box-->
				<p>As you can clearly see, the <code>this</code> keyword in the above example refers to the context of the function enclosing the arrow function which is Person object (<i>line no-9</i>), unlike the previous example where it referred to the global object <a href="javascript-window.php">Window</a> (<i>line no-9</i>).</p>
				<hr />
				<h2>Classes</h2>
				<p>In ECMAScript 5 and earlier, classes were never existed in JavaScript. Classes are introduced in ES6 which looks similar to classes in other object oriented languages, such as Java, PHP, etc., however they do not work exactly the same way. ES6 classes make it easier to create objects, implement inheritance by using the <code>extends</code> keyword, and reuse the code.</p>
				<p>In ES6 you can declare a class using the new <code>class</code> keyword followed by a class-name. By convention class names are written in TitleCase (i.e. capitalizing the first letter of each word).</p>
				<!--Code box-->
				<div class="example break">
					<div class="codebox">
						<div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=es6-classes" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
						<pre class="syntax-highlighter line-numbers"><code class="language-javascript">class Rectangle {
    // Class constructor
    constructor(length, width) {
        this.length = length;
        this.width = width;
    }
    
    // Class method
    getArea() {
        return this.length * this.width;
    }
}

// Square class inherits from the Rectangle class
class Square extends Rectangle {
    // Child class constructor
    constructor(length) {
        // Call parent's constructor
        super(length, length);
    }
    
    // Child class method
    getPerimeter() {
        return 2 * (this.length + this.width);
    }
}

let rectangle = new Rectangle(5, 10);
alert(rectangle.getArea()); // 50

let square = new Square(5);
alert(square.getArea()); // 25
alert(square.getPerimeter()); // 20

alert(square instanceof Square); // true
alert(square instanceof Rectangle); // true
alert(rectangle instanceof Square); // false</code></pre>
					</div>
				</div>
                <!--End:Code box-->
				<p>In the above example the Square class inherits from Rectangle using the <code>extends</code> keyword. Classes that inherit from other classes are referred to as derived classes or child classes.</p>
				<p>Also, you must call <code>super()</code> in the child class constructor before accessing the context (<code>this</code>). For instance, if you omit the <code>super()</code> and call the <code>getArea()</code> method on square object it will result in an error, since <code>getArea()</code> method require access to <code>this</code> keyword.</p>
				<!--Note box-->
                <div class="color-box">
                    <div class="shadow">
                        <div class="info-tab note-icon" title="Important Notes"><i></i></div>
                        <div class="note-box">
                            <p><strong>Note:</strong> Unlike function declarations, class declarations are not hoisted. Class declarations reside in the temporal dead zone (TDZ) until the execution reaches the point of class declaration, similar to <code>let</code> and <code>const</code> declarations. Therefore, you need to declare your class before accessing it, otherwise a ReferenceError will occur.</p>
                        </div>
                    </div>
                </div>
                <!--End:Note box-->
				<hr />
				<h2>Modules</h2>
				<p>Prior to ES6, there were no native support for modules in JavaScript. Everything inside a JavaScript application, for example variables across different JavaScript files, shared the same scope.</p>
				<p>ES6 introduces file based module, in which each module is represented by a separate <code>.js</code> file. Now, you can use the <code>export</code> or <code>import</code> statement in a module to export or import variables, functions, classes or any other entity to/from other modules or files.</p>
				<p>Let's create a module i.e. a JavaScript file "main.js" and place the following code in it:</p>
				<!--Code box-->
				<div class="example break">
					<div class="codebox">
						<div class="codebox-title"><h4>Example</h4><a href="javascript:void(0);" target="_blank" class="try-btn disabled" title="Disabled">Try this code <span>&raquo;</span></a></div>
						<pre class="syntax-highlighter line-numbers"><code class="language-javascript">let greet = "Hello World!";
const PI = 3.14; 

function multiplyNumbers(a, b) {
    return a * b;
}

// Exporting variables and functions
export { greet, PI, multiplyNumbers };</code></pre>
					</div>
				</div>
                <!--End:Code box-->
				<p>Now create another JavaScript file "app.js" with the following code:</p>
				<!--Code box-->
				<div class="example break">
					<div class="codebox">
						<div class="codebox-title"><h4>Example</h4><a href="javascript:void(0);" target="_blank" class="try-btn disabled" title="Disabled">Try this code <span>&raquo;</span></a></div>
						<pre class="syntax-highlighter line-numbers"><code class="language-javascript">import { greet, PI, multiplyNumbers } from './main.js';

alert(greet); // Hello World!
alert(PI); // 3.14
alert(multiplyNumbers(6, 15)); // 90</code></pre>
					</div>
				</div>
                <!--End:Code box-->
				<p>Finally create a HTML file "test.html" and with the following code and open this HTML file in your browser using HTTP protocol (or use localhost). Also notice the <code>type="module"</code> on script tag.</p>
				<!--Code box-->
				<div class="example break">
					<div class="codebox">
						<div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=es6-modules" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
						<pre class="syntax-highlighter line-numbers"><code class="language-markup">&lt;!DOCTYPE html&gt;
&lt;html lang="en"&gt;
&lt;head&gt;
    &lt;meta charset="utf-8"&gt;
    &lt;title&gt;ES6 Module Demo&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
    &lt;script type="module" src="app.js"&gt;&lt;/script&gt;
&lt;/body&gt;
&lt;/html&gt;</code></pre>
					</div>
				</div>
                <!--End:Code box-->
				<hr />
				<h2 id="rest-operator">The Rest Parameters</h2>
				<p>ES6 introduces rest parameters that allow us to pass an arbitrary number of parameters to a function in the form of an array. This is particularly helpful in situations when you want to pass parameters to a function but you have no idea how many you will need.</p>
				<p>A rest parameter is specified by prefixing a named parameter with rest operator (<code>...</code>) i.e. three dots. Rest parameter can only be the last one in the list of parameters, and there can only be one rest parameter. Take a look at the following example, to see how it works:</p>
				<!--Code box-->
				<div class="example break">
					<div class="codebox">
						<div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=es6-rest-parameter" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
						<pre class="syntax-highlighter line-numbers"><code class="language-javascript">function sortNames(...names) {
    return names.sort();
}

alert(sortNames("Sarah", "Harry", "Peter")); // Harry,Peter,Sarah
alert(sortNames("Tony", "Ben", "Rick", "Jos")); // John,Jos,Rick,Tony</code></pre>
					</div>
				</div>
                <!--End:Code box-->
				<p>When the rest parameter is the only parameter in a function, it gets all the arguments passed to the function, otherwise it gets the rest of the arguments that exceeds the number of named parameters.</p>
				<!--Code box-->
				<div class="example break">
					<div class="codebox">
						<div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=es6-get-extra-function-arguments-with-rest-parameter" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
						<pre class="syntax-highlighter line-numbers"><code class="language-javascript">function myFunction(a, b, ...args) {
    return args;
}

alert(myFunction(1, 2, 3, 4, 5)); // 3,4,5
alert(myFunction(-7, 5, 0, -2, 4.5, 1, 3)); // 0,-2,4.5,1,3</code></pre>
					</div>
				</div>
                <!--End:Code box-->
				<!--Note box-->
                <div class="color-box">
                    <div class="shadow">
                        <div class="info-tab note-icon" title="Important Notes"><i></i></div>
                        <div class="note-box">
                            <p><strong>Note:</strong> Don't confuse the term rest parameters with the REST (REpresentational State Transfer). This has nothing to do with RESTful web services.</p>
                        </div>
                    </div>
                </div>
                <!--End:Note box-->
				<hr />
				<h2 id="spread-operator">The Spread Operator</h2>
				<p>The spread operator, which is also denoted by (<code>...</code>), performs the exact opposite function of the rest operator. The spread operator spreads out (i.e. splits up) an array and passes the values into the specified function, as shown in the following example:</p>
				<!--Code box-->
				<div class="example break">
					<div class="codebox">
						<div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=es6-spread-operator" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
						<pre class="syntax-highlighter line-numbers"><code class="language-javascript">function addNumbers(a, b, c) {
    return a + b + c;
}

let numbers = [5, 12, 8];

// ES5 way of passing array as an argument of a function
alert(addNumbers.apply(null, numbers)); // 25

// ES6 spread operator
alert(addNumbers(...numbers)); // 25</code></pre>
					</div>
				</div>
                <!--End:Code box-->
				<p>The spread operator can also be used to insert the elements of an array into another array without using the array methods like <code>push()</code>, <code>unshift()</code> <code>concat()</code>, etc.</p>
				<!--Code box-->
				<div class="example break">
					<div class="codebox">
						<div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=es6-insert-array-elements-into-another-array-using-spread-operator" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
						<pre class="syntax-highlighter line-numbers"><code class="language-javascript">let pets = ["Cat", "Dog", "Parrot"];
let bugs = ["Ant", "Bee"];

// Creating an array by inserting elements from other arrays
let animals = [...pets, "Tiger", "Wolf", "Zebra", ...bugs];

alert(animals); // Cat,Dog,Parrot,Tiger,Wolf,Zebra,Ant,Bee</code></pre>
					</div>
				</div>
                <!--End:Code box-->
				<hr />
				<h2>Destructuring Assignment</h2>
				<p>The destructuring assignment is an expression that makes it easy to extract values from arrays, or properties from objects, into distinct variables by providing a shorter syntax.</p>
				<p>There are two kinds of destructuring assignment expressions&mdash;the <em>array</em> and <em>object</em> destructuring assignment. Well, let's see how each of them exactly works:</p>
				<h3>The array destructuring assignment</h3>
				<p>Prior to ES6, to get an individual value of an array we need to write something like this:</p>
				<!--Code box-->
				<div class="example break">
					<div class="codebox">
						<div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=accessing-individual-array-elements-in-older-versions" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
						<pre class="syntax-highlighter line-numbers"><code class="language-javascript">// ES5 syntax
var fruits = ["Apple", "Banana"];

var a = fruits[0];
var b = fruits[1];
alert(a); // Apple
alert(b); // Banana</code></pre>
					</div>
				</div>
                <!--End:Code box-->
				<p>In ES6, we can do the same thing in just one line using the array destructuring assignment:</p>
				<!--Code box-->
				<div class="example break">
					<div class="codebox">
						<div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=es6-array-destructuring-assignment" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
						<pre class="syntax-highlighter line-numbers"><code class="language-javascript">// ES6 syntax
let fruits = ["Apple", "Banana"];

let [a, b] = fruits; // Array destructuring assignment

alert(a); // Apple
alert(b); // Banana</code></pre>
					</div>
				</div>
                <!--End:Code box-->
				<p>You can also use <a href="#rest-operator">rest operator</a> in the array destructuring assignment, as shown here:</p>
				<!--Code box-->
				<div class="example break">
					<div class="codebox">
						<div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=es6-using-rest-operator-in-array-destructuring-assignment" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
						<pre class="syntax-highlighter line-numbers"><code class="language-javascript">// ES6 syntax
let fruits = ["Apple", "Banana", "Mango"];

let [a, ...r] = fruits;

alert(a); // Apple
alert(r); // Banana,Mango
alert(Array.isArray(r)); // true</code></pre>
					</div>
				</div>
                <!--End:Code box-->
				<h3>The object destructuring assignment</h3>
				<p>In ES5 to extract the property values of an object we need to write something like this:</p>
				<!--Code box-->
				<div class="example break">
					<div class="codebox">
						<div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=accessing-object-property-values-in-older-versions" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
						<pre class="syntax-highlighter line-numbers"><code class="language-javascript">// ES5 syntax
var person = {name: "Peter", age: 28};

var name = person.name;
var age = person.age;

alert(name); // Peter
alert(age); // 28</code></pre>
					</div>
				</div>
                <!--End:Code box-->
				<p>But in ES6, you can extract object's property values and assign them to the variables easily like this:</p>
				<!--Code box-->
				<div class="example break">
					<div class="codebox">
						<div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=es6-object-destructuring-assignment" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
						<pre class="syntax-highlighter line-numbers"><code class="language-javascript">// ES6 syntax
let person = {name: "Peter", age: 28};

let {name, age} = person; // Object destructuring assignment

alert(name); // Peter
alert(age); // 28</code></pre>
					</div>
				</div>
                <!--End:Code box-->
				<p>Most of the features we've discussed above are supported in the latest version of the major web browsers such as Google Chrome, Mozilla Firefox, Microsoft Edge, Safari, etc.</p>
                <p>Alternatively, you can use the online transpilers (source-to-source compilers) like <a rel="nofollow" href="https://babeljs.io/repl/" target="_blank">Babel</a> free of cost to transpile your current ES6 code to ES5 for better browser compatibility without leaving out the benefits of enhanced syntax and capabilities of ES6.</p>
				<!--Bottom Navigation-->
				<div class="bottom-link clearfix">
                    <a href="javascript-ajax.php" class="previous-page-bottom">Previous Page</a>
                    <a href="/javascript-examples.php" class="next-page-bottom">Next Page</a>
                </div>
                <!--End:Bottom Navigation-->
                <!-- InstanceEndEditable -->
                <!--Bottom Ads-->
                <div class="bottom-ad clearfix">
                    <div class="ad-label">Advertisements</div>

<!--Rectangle Left-->
<div class="rectangle-left fl">
    
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Large Rectangle Left -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="8162953958"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
<!--End:Rectangle Left-->


<!--Rectangle Right-->
<div class="rectangle-right fr">

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Large Rectangle Right -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="3324015654"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
<!--End:Rectangle Right-->                </div>
                <!--End:Bottom Ads-->
            </div>
            <!--End:Text Content-->
            <!--Feedback Form-->
			<div class="snippets">
	<a href="/snippets/gallery.php" target="_blank">
    	<img src="/lib/images/bootstrap-code-snippets.png" alt="Bootstrap UI Design Templates" />
	</a>
</div>

<div class="report-error" id="feedback">
    <div class="contact-form clearfix">
        <div class="close"><span class="icon-close"></span></div>
        <form id="feedback-form">
            <h3>Your Feedback:</h3>
            <div class="clearfix">
                <div class="name fl"><label>Your Name (optional) <input type="text" name="user-name" id="user-name" /></label></div>
                <div class="email fr"><label>Your E-mail (optional) <input type="text" name="user-email" id="user-email" /></label></div>
            </div>
            <div><label>Page address <input type="text" name="page-url" id="page-url" class="disabled" disabled="disabled" /></label></div>
            <div><label>Description <textarea name="description" id="description" rows="6"></textarea></label></div>
            <p id="feedback-error">We would love to hear from you, please drop us a line.</p>
            <div><button type="button" class="action-btn" onclick="sendFeedback()"><span class="icon-send"></span> Send</button></div>
        </form>
        <div id="response"></div>
    </div>           
</div>            <!--End:Feedback Form-->
        </div>        
        <div class="sidebar">
            <div class="ad-label">Advertisements</div>

<div class="skyscraper primary">

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Premium Skyscraper -->
<ins class="adsbygoogle"
     style="display:inline-block;width:160px;height:600px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="4376141825"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>

<div class="skyscraper">
    
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Bottom Skyscraper -->
<ins class="adsbygoogle"
     style="display:inline-block;width:160px;height:600px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="3387984471"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>        </div>
    </div>
    <!--Footer-->
	<!--Footer-->
<div class="footer">
    <div class="appeal">
        <div class="wrapper">
            <p>Is this website helpful to you? Please give us a
            <a href="/like.php" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=250,width=600,top=150, left='+((screen.width/2)-300));return false;">like</a>,
            or share your <a href="#feedback" class="feedback">feedback</a><em> to help us improve</em>.
            Connect with us on <a href="https://www.facebook.com/tutorialrepublic" target="_blank">Facebook</a> and <a href="https://twitter.com/tutrepublic" target="_blank">Twitter</a> for the latest updates.</p>               
        </div>
    </div>
    <div class="footer-inner">
        <div class="wrapper clearfix">                
            <div class="link-box">
                <h4>About Us</h4>
                <div class="clearfix">
                    <a href="/about-us.php">Our Story</a>                    
                    <a href="/terms-of-use.php">Terms of Use</a>
                    <a href="/privacy-policy.php">Privacy Policy</a>                    
                </div>
            </div>
            <div class="link-box">
                <h4>Contact</h4>
                <div class="clearfix">
                    <a href="/contact-us.php">Contact Us</a>                    
                    <a href="#feedback" class="feedback">Report Error</a>
                    <a href="/advertise-with-us.php">Advertise</a>                    
                </div>
            </div>
            <div class="tool-box">
                <h4>Interactive Tools</h4>
                <div class="tools-list clearfix" id="tools">
                    <a href="/faq/what-is-the-maximum-length-of-title-and-meta-description-tag.php">Title &amp; Meta Length Calculator</a>                           
                    <a href="/html-formatter.php" target="_blank">HTML Formatter</a>                        
                    <a href="/twitter-bootstrap-button-generator.php" target="_blank">Bootstrap Button Generator</a>
                    <a href="/html-reference/html-color-picker.php">HTML Color Picker</a>
                    <a href="/codelab.php?topic=sql&amp;file=select-all" target="_blank">SQL Playground</a>
                    <a href="/codelab.php?topic=html&amp;file=hello-world" target="_blank">HTML Editor</a>                    
                </div>
            </div>
            <div class="footer-logo">
                <img src="/lib/images/logo.svg" alt="TutorialRepublic" />
            </div>
        </div>
    </div>           
        <div class="bottom-strip">
        <div class="wrapper">
            <div class="notice">Copyright &copy; 2019 Tutorial Republic. All Rights Reserved.</div>
            <div class="social-media">
                <em>Share This:</em>
                <a href="https://facebook.com/sharer.php?u=https://www.tutorialrepublic.com%2Fjavascript-tutorial%2Fjavascript-es6-features.php" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" title="Facebook"><i class="icon-facebook"></i></a>
                <a href="#" id="tweet-btn" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" title="Twitter"><i class="icon-twitter"></i></a>
                <a href="#" id="email-btn" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" rel="noreferrer" title="Gmail"><i class="icon-mail"></i></a>
            </div>
        </div>            
    </div>
    <script>
        var title = document.title.replace('- Tutorial Republic', '');
        document.getElementById('tweet-btn').href = 'https://twitter.com/share?text=' + title + '- &url=https://www.tutorialrepublic.com%2Fjavascript-tutorial%2Fjavascript-es6-features.php';
        document.getElementById('email-btn').href = 'https://mail.google.com/mail/?view=cm&fs=1&su=' + title + '&body=https://www.tutorialrepublic.com%2Fjavascript-tutorial%2Fjavascript-es6-features.php';
    </script>
</div>
<!--End:Footer-->
    
<div class="backdrop mobile-only"></div>

<!-- TutorialRepublic base script -->
<script>
// Adding CSS files
[
	'/lib/styles/extended.new-3.7.css',
	'/lib/icomoon/style.css'
].forEach(function(href) {
	var link = document.createElement('link');
	link.rel = 'stylesheet';
	link.href = href;
	(document.getElementsByTagName('head')[0]).appendChild(link);
});

// Adding JS files
[
	'https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js',
	'/lib/js/prism.js',
	'/lib/js/default.new-2.9.min.js'
].forEach(function(src) {
	var script = document.createElement('script');
	script.async = false; // important
	script.src = src;
	(document.getElementsByTagName('body')[0]).appendChild(script);
});
</script>


    <!--End:Footer-->
</body>
<!-- InstanceEnd --></html>