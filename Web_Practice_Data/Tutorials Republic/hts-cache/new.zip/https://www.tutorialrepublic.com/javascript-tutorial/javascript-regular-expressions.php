<!DOCTYPE html>
<html lang="en"><!-- InstanceBegin template="/Templates/javascript.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
	<!-- InstanceBeginEditable name="doctitle" -->
    <title>Regular Expressions in JavaScript - Tutorial Republic</title>
    <!-- InstanceEndEditable -->
    	<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta property="fb:admins" content="100001054961582" />
<meta property="fb:app_id" content="1404574483159557" />
<meta property="og:image" content="/lib/images/signature.png" />
<link type="image/x-icon" href="/favicon.ico" rel="shortcut icon" />
<style>
html,body,h1,h2,h3,h4,h5,h6,p,blockquote,pre,img{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}
html,body{min-height:100%}
p{margin:0 0 12px}
ol,ul{margin:0 0 12px}
a,a:active,a:visited{outline:none;color:#1db79f;text-decoration:none}
a img{border:none;outline:none}
a code{color:inherit;background:none}
p code,table td:last-child code,.content ul li code,code.mark{padding:2px 4px;color:#333;background-color:#f1f1f1;border-radius:4px}
table{border-collapse:collapse;border-spacing:0}
table td{vertical-align:top}
body{min-width:1300px;color:#414141;background:#fafafa;font-family:"Segoe UI","Helvetica Neue",Arial,sans-serif;font-size:17px;line-height:1.7}
input,select,textarea,button,div,span,a{box-sizing:border-box}
h1,h2,h3,h4{color:#262626;font-weight:500;margin:20px 0 10px;line-height:1.5;font-weight:600}
h1{font-size:34px;margin-top:17px}
h2{font-size:28px}
h3{font-size:22px}
.space{margin-bottom:25px!important}
.break{margin-bottom:15px!important}
.text-center{text-align:center!important}
.scroll{height:195px;overflow-y:scroll}
.scroll.large{height:245px}
.scroll.xlarge{height:290px}
.scroll.xxlarge{height:340px}
sup{font-size:13px}
.leaderboard{padding-top:8px;position:relative}
.ad-container{height:90px;overflow:hidden}
.intro-image img{display:block;padding:10px 0 25px;max-width:100%}
.clearfix::after{content:".";display:block;height:0;clear:both;visibility:hidden}
code,.code,.syntax,.green-box,.sky-box,.gray-box,.pink-box,.red-box,.at-rule,.codebox pre,.console-output{font-size:16px;font-family:Consolas,Monaco,Courier,monospace}
.console-output{margin:15px 0}
hr{border:none;border-bottom:1px solid #e7e9ed;height:1px;margin:30px 0}
.summary,.topic{border:1px solid #eaeaea;border-width:1px 0;margin:20px 0;padding:10px 0;color:#8e9aa6;line-height:1.5}
h2.section-title span{display:inline-block;border-bottom:4px solid #c9d7e0;padding:0 50px 12px 0}
.wrapper{width:1300px;padding:0 15px;margin:0 auto}
.header{background:#23384e;padding:16px 0}
input.search{background:#fff;border:0 none;color:#807E7E;float:left;height:38px;line-height:26px;font-size:14px;margin:0 0 0 12px;outline:medium none;padding:6px 14px;width:500px;border-radius:2px;box-shadow:0 0 1px rgba(0,0,0,0.6);font-family:inherit}
.search-btn{color:rgba(0,0,0,.6);background:#ebebeb;border:none;outline:none;cursor:pointer;float:left;height:38px;line-height:46px;width:44px;display:block;margin-left:-2px;border-radius:0 2px 2px 0;box-shadow:0 0 1px rgba(0,0,0,0.7)}
.logo{width:304px}
.logo img{height:44px;margin:-3px 0;display:block}
.site-search{float:left;margin-left:100px}
.menu{background-color:#f5f5f5;box-shadow:0 1px 1px rgba(0,0,0,.15);position:relative;z-index:9}
.menu a{color:#666;display:inline-block;padding:0 10px;text-decoration:none;font-size:14px;font-weight:600;height:48px;line-height:48px}
.menu a:first-child{margin-left:-10px}
.menu a.tool-link{float:right;display:inline-block;border-radius:30px;line-height:28px;position:relative;height:auto;top:9px;padding:0 12px;color:#1ebba3;border:1px double #1ebba3}
.fl,.logo{float:left}
.leftcolumn{width:240px;float:left;font-size:16px;color:#4f4f4f}
.centercolumn{width:850px;float:left}
.content{background:#fff;padding:20px 40px;border:1px solid #dedede;border-top:none;border-radius:1px}
.sidebar{width:160px;float:left;padding-top:28px;margin-left:20px;position:relative}
.leftcolumn .segment{margin:16px 0 12px;position:relative;font-size:18px;font-weight:600;line-height:normal}
.leftcolumn a{color:#4f4f4f;font-size:16px;line-height:26px;display:block;border-bottom:1px solid transparent}
.leftcolumn ul{list-style:none;padding:0}
.segment,.chapters,.chapters a{float:left;clear:both}
h1 code,h2 code,h3 code{font:inherit}
.color-box{margin:15px 0;padding-left:20px}
.note-box,.warning-box,.tip-box{padding:8px 8px 3px 26px}
.info-tab{float:left;margin-left:-23px}
.content ul li{margin-top:7px}
.extra{padding-top:5px}
.green-box,.sky-box,.gray-box,.red-box,.pink-box{color:#000;margin-top:15px;padding:10px;background-color:#f6f8fa;border:1px solid #d7e2ec}
.example{background:#f4f5f6;padding:3px;margin:15px 0}
.codebox{background:#fff;border:1px solid #ddd}
.codebox-title{height:41px;padding-left:12px;border-bottom:1px solid #ddd;background:#f5f5f5}
.codebox-title h4{margin:0;font-size:18px;line-height:40px;float:left;display:inline;font-weight:500}
a.try-btn,a.download-btn{width:140px;height:40px;color:#333;font-size:15px;line-height:41px;font-weight:600;text-align:center;text-decoration:none;float:right;display:block;border-left:1px solid #ddd;background:rgba(27,31,35,0.08);box-sizing:border-box;font-family:Arial,sans-serif}
a.try-btn span{font-size:18px;line-height:normal}
.hide,.code-style,.box-size,.bottom-link,.footer,.code-style,.snippets,.report-error,.badge,.social,.ad-label,.mobile-only{display:none}
.skyscraper{width:160px;height:600px;overflow:hidden;margin-bottom:20px;background:#ebecf0}
.bottom-ad{margin-top:46px;padding:24px;position:relative;background:url(/lib/images/smooth-line.png) no-repeat center #f9f9f9}
.rectangle-left,.rectangle-right{min-width:336px;min-height:280px;overflow:hidden}
.fr,a.previous-page,a.next-page,.rectangle-right,.topic-nav{float:right}
a.previous-page,a.next-page{width:32px;height:32px;line-height:30px}
.shadow{background:#F7F8F9;padding:3px;margin:10px 0}
.syntax{color:#2f4959;padding:13px 18px;background:#F9F9FA;border:1px solid #ddd;font-size:15px}
code[class*="language-"],pre[class*="language-"]{color:#000;background:none;font-family:Consolas,Monaco,'Andale Mono','Ubuntu Mono',monospace;text-align:left;white-space:pre;word-break:normal;word-wrap:normal;line-height:1.5;tab-size:4;hyphens:none}
pre[class*="language-"]{position:relative;margin:.5em 0;overflow:visible;padding:0}
pre[class*="language-"]>code{position:relative;border-left:10px solid #358ccb;box-shadow:-1px 0 0 0 #358ccb,0 0 0 1px #dfdfdf;background-color:#fdfdfd;background-image:linear-gradient(transparent 50%,rgba(69,142,209,0.04) 50%);background-size:3em 3em;background-origin:content-box;background-attachment:local}
code[class*="language"]{max-height:inherit;height:inherit;padding:0 1em;display:block;overflow:auto}
:not(pre) > code[class*="language-"]{position:relative;padding:.2em;border-radius:.3em;color:#c92c2c;border:1px solid rgba(0,0,0,0.1);display:inline;white-space:normal}
pre[class*="language-"].line-numbers{padding-left:0}
pre[class*="language-"].line-numbers code{padding-left:3.8em}
pre[class*="language-"].line-numbers .line-numbers-rows{left:0}
pre[class*="language-"][data-line]{padding-top:0;padding-bottom:0;padding-left:0}
pre[data-line] code{position:relative;padding-left:4em}
pre .line-highlight{margin-top:0}
pre.line-numbers{position:relative;padding-left:3.8em;counter-reset:linenumber;white-space:pre-wrap!important}
pre.line-numbers > code{position:relative;white-space:inherit}
.line-numbers-rows,.codebox pre.inactive{display:none}
.codebox pre.syntax-highlighter{margin:0;padding:0;overflow:auto}
pre.line-numbers .line-numbers-rows{border-right:3px solid #6CE26C}
.codebox pre.syntax-highlighter > code{box-shadow:none!important;padding-left:3.8em;background-image:linear-gradient(transparent 50%,#F8F8F8 50%);font-family:Consolas,Monaco,'Andale Mono','Ubuntu Mono',monospace!important;font-size:16px;line-height:1.5}
.codebox pre.syntax-highlighter,.codebox pre.syntax-highlighter code{border:none;width:100%;box-sizing:border-box}
pre.line-numbers code,pre.line-numbers .line-numbers-rows{padding-top:2px;padding-bottom:2px}
.preview-box{padding:15px;text-align:center;cursor:pointer;overflow:hidden;background:#FFF;border:1px solid #e6e6e6}
.preview-box a,.preview-box img{display:block;margin:0 auto}
.download-box{text-align:center;padding:20px 0;margin:20px 0 10px}
.output-box{border-color:#d4d4d4;border-style:solid;border-width:1px 0;padding:5px 15px;overflow:hidden;background:#fff;margin:10px 0}
.demo-box{margin-top:15px}
.subhead{border-bottom:3px solid #DCE3EB;margin-bottom:15px;padding-bottom:10px}
table.data,table.description{width:100%;font-size:92%}
table.data th{color:#000;padding:8px 7px;text-align:left;font-size:15px;background:#F8F8F8}
table.data td{color:#484848;padding:5px 7px;background:#fff}
table.data th,table.data td{vertical-align:top;border:1px solid #DCE3EB}
table.data tr.section th,table.data td.section{font-size:15px;background:#f0f4f7}
table.no-wrap tr td:first-child{white-space:nowrap}
@media screen and (max-width: 1280px) {
body{min-width:1260px}
.wrapper{width:1260px}
.leftcolumn{width:230px}
.centercolumn{width:820px}
}
@media screen and (max-width: 800px) {
body{min-width:100%;max-width:100%;padding-top:46px}
.wrapper{width:100%;padding:0}
.header{height:46px;padding:5px 0;position:fixed;top:0;left:0;right:0;width:100%;z-index:99}
.logo{width:auto;display:block;padding:6px 0 0 60px;position:absolute;left:0;z-index:100}
.logo img{height:30px}
.menu{width:100%;padding-left:12px;padding-right:12px;overflow-x:auto;white-space:nowrap}
.centercolumn{width:100%;float:none}
.content{padding:10px;border-width:0 0 1px 0}
.content img{max-width:100%;height:auto}
.content pre{max-width:100%;overflow:hidden}
.skyscraper{display:inline-block}
.shadow,.example,.console-output{max-width:100%;overflow-x:auto}
.codebox-title{position:relative}
.codebox.multi-style-mode pre{padding-top:7px;margin-top:36px;border-top:1px solid #ddd}
.bottom-ad{height:auto;background:none;padding:30px 0 0;margin:40px 0 0;text-align:center;position:relative}
.rectangle-left,.rectangle-right{float:none;display:inline-block;margin:10px auto;background:#EDEEF2}
.leftcolumn,.footer,.social,.site-search,.code-style,.menu a.tool-link,.backdrop{display:none}
.summary,.topic{padding:5px 0;margin:10px 0}
.leftcolumn,.centercolumn,.sidebar{float:none}
.header,.menu,.centercolumn,.footer,.appeal-text{width:100%}
a.try-btn,a.download-btn{width:130px}
.native-unit{margin-bottom:30px}
.sidebar{margin: 25px auto 0}
.overview{padding-right:0}
.scroll-pane{overflow-x:auto}
table.data{min-width:480px}
table.data pre{display:inline;white-space:normal}
table tr th,table tr td{width:auto!important}
.preview-box{padding:6px}
.leaderboard{margin:20px 0}
h1{font-size:30px}
h2{font-size:24px}
h3{font-size:20px}
.codebox pre.syntax-highlighter{overflow-x:auto}
.codebox pre.syntax-highlighter > code{width:614px;height:auto;overflow-x:hidden}
}
@media screen and (min-width: 801px) {
.site-search,.leftcolumn,.social{display:block!important}
.backdrop{display:none!important}
.hide-scroll{overflow-x:hidden!important}
}</style>    
    <!-- InstanceBeginEditable name="head" -->
    <!-- InstanceEndEditable -->
    
    <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-40117907-1', 'auto');
  ga('send', 'pageview');
</script></head>
<body>
    <!--Header-->
    
<div class="header">
    <div class="wrapper clearfix">
        <button type="button" class="open-menu mobile-only"><i class="icon-menu"></i></button>
        <div class="logo">
            <a href="https://www.tutorialrepublic.com/"><img src="/lib/images/logo.svg" alt="TutorialRepublic" /></a>
        </div>
        <div class="site-search">
            <form action="https://www.google.com/search" method="get" target="_blank" class="clearfix">
                <input type="hidden" value="www.tutorialrepublic.com" name="sitesearch" />
                <input type="text" name="q" placeholder="Search topics, tutorials, questions and answers..." id="searchInput" class="search" />
                <button type="submit" class="search-btn"><span class="icon-search"></span></button>
            </form>
        </div>
        <div class="social">                
            <a href="https://www.facebook.com/tutorialrepublic" target="_blank" title="Join us on Facebook"><i class="icon-facebook"></i></a>
            <a href="https://twitter.com/tutrepublic" target="_blank" title="Follow us on Twitter"><i class="icon-twitter"></i></a>
            <a href="/contact-us.php" target="_blank" title="Send us an Email"><i class="icon-mail"></i></a>
        </div>
        <button type="button" class="open-search mobile-only">
            <i class="icon-search"></i>
        </button>
    </div>    
</div>
<div class="menu">
    <div class="wrapper">
        <a href="//www.tutorialrepublic.com" title="Home Page">HOME</a>
        <a href="/html-tutorial/" title="HTML Tutorial">HTML5</a>            
        <a href="/css-tutorial/" title="CSS Tutorial">CSS3</a>
        <a href="/javascript-tutorial/" title="JavaScript Tutorial">JAVASCRIPT</a>
        <a href="/jquery-tutorial/" title="jQuery Tutorial">JQUERY</a>
        <a href="/twitter-bootstrap-tutorial/" title="Bootstrap Tutorial">BOOTSTRAP4</a>
        <a href="/php-tutorial/" title="PHP Tutorial">PHP7</a> 
        <a href="/sql-tutorial/" title="SQL Tutorial">SQL</a>
        <a href="/references.php" title="Web References">REFERENCES</a>
        <a href="/practice-examples.php" title="Practice Examples and Demos">EXAMPLES</a>
        <a href="/faq.php" title="Frequently Asked Questions and Answers">FAQ</a>
        <a href="/snippets/gallery.php" title="Bootstrap Code Snippets" target="_blank">SNIPPETS</a>
        <a href="/codelab.php" class="tool-link" target="_blank">Online HTML Editor</a>
    </div>        
</div>    <!--End:Header-->
    <div class="wrapper clearfix">
        <div class="leftcolumn" id="myNav">
		
        <div class="segment"><span>JAVASCRIPT</span> BASIC</div>
<div class="chapters">
    <a href="/javascript-tutorial/">JS Introduction</a>
    <a href="/javascript-tutorial/javascript-get-started.php">JS Getting Started</a>
    <a href="/javascript-tutorial/javascript-syntax.php">JS Syntax</a>
	<a href="/javascript-tutorial/javascript-variables.php">JS Variables</a>
	<a href="/javascript-tutorial/javascript-generating-output.php">JS Generating Output</a>
	<a href="/javascript-tutorial/javascript-data-types.php">JS Data Types</a>
	<a href="/javascript-tutorial/javascript-operators.php">JS Operators</a>	
	<a href="/javascript-tutorial/javascript-events.php">JS Events</a>
	<a href="/javascript-tutorial/javascript-strings.php">JS Strings</a>
    <a href="/javascript-tutorial/javascript-numbers.php">JS Numbers</a>
	<a href="/javascript-tutorial/javascript-if-else-statements.php">JS If&hellip;Else</a>
	<a href="/javascript-tutorial/javascript-switch-case-statements.php">JS Switch&hellip;Case</a>	
    <a href="/javascript-tutorial/javascript-arrays.php">JS Arrays</a>
    <a href="/javascript-tutorial/javascript-sorting-arrays.php">JS Sorting Arrays</a>
	<a href="/javascript-tutorial/javascript-loops.php">JS Loops</a>
	<a href="/javascript-tutorial/javascript-functions.php">JS Functions</a>
	<a href="/javascript-tutorial/javascript-objects.php">JS Objects</a>
</div>
<div class="segment"><span>JAVASCRIPT</span> &amp; DOM</div>
<div class="chapters">
    <a href="/javascript-tutorial/javascript-dom-nodes.php">JS DOM Nodes</a>
	<a href="/javascript-tutorial/javascript-dom-selectors.php">JS DOM Selectors</a>
	<a href="/javascript-tutorial/javascript-dom-styling.php">JS DOM Styling</a>
	<a href="/javascript-tutorial/javascript-dom-get-set-attributes.php">JS DOM Get Set Attributes</a>
	<a href="/javascript-tutorial/javascript-dom-manipulation.php">JS DOM Manipulation</a>
    <a href="/javascript-tutorial/javascript-dom-navigation.php">JS DOM Navigation</a>
</div>
<div class="segment"><span>JAVASCRIPT</span> &amp; BOM</div>
<div class="chapters">
	<a href="/javascript-tutorial/javascript-window.php">JS Window</a>
	<a href="/javascript-tutorial/javascript-window-screen.php">JS Screen</a>
	<a href="/javascript-tutorial/javascript-window-location.php">JS Location</a>
	<a href="/javascript-tutorial/javascript-window-history.php">JS History</a>
    <a href="/javascript-tutorial/javascript-window-navigator.php">JS Navigator</a>
    <a href="/javascript-tutorial/javascript-dialog-boxes.php">JS Dialog Boxes</a>
	<a href="/javascript-tutorial/javascript-timers.php">JS Timers</a>
</div>
<div class="segment"><span>JAVASCRIPT</span> ADVANCED</div>
<div class="chapters">
	<a href="/javascript-tutorial/javascript-date-and-time.php">JS Date and Time</a>
	<a href="/javascript-tutorial/javascript-math-operations.php">JS Math Operations</a>
	<a href="/javascript-tutorial/javascript-type-conversions.php">JS Type Conversions</a>
	<a href="/javascript-tutorial/javascript-event-listeners.php">JS Event Listeners</a>
	<a href="/javascript-tutorial/javascript-event-propagation.php">JS Event Propagation</a>
    <a href="/javascript-tutorial/javascript-borrowing-methods.php">JS Borrowing Methods</a>
    <a href="/javascript-tutorial/javascript-hoisting.php">JS Hoisting Behavior</a>
	<a href="/javascript-tutorial/javascript-closures.php">JS Closures</a>
	<a href="/javascript-tutorial/javascript-strict-mode.php">JS Strict Mode</a>   
	<a href="/javascript-tutorial/javascript-json-parsing.php">JS JSON Parsing</a>
    <a href="/javascript-tutorial/javascript-error-handling.php">JS Error Handling</a>
	<a href="/javascript-tutorial/javascript-regular-expressions.php">JS Regular Expressions</a>
	<a href="/javascript-tutorial/javascript-form-validation.php">JS Form Validation</a>
	<a href="/javascript-tutorial/javascript-cookies.php">JS Cookies</a>
	<a href="/javascript-tutorial/javascript-ajax.php">JS AJAX Requests</a>
	<a href="/javascript-tutorial/javascript-es6-features.php">JS ES6 Features</a>
</div>
<div class="segment"><span>JAVASCRIPT</span> EXAMPLES</div>
<div class="chapters">
    <a href="/javascript-examples.php">JS Practice Examples</a>
	<a href="/faq.php#javascript-jquery">JS FAQ's Answers</a>
</div>
<div class="segment"><span>JAVASCRIPT</span> REFERENCE</div>
<ul class="chapters tree-menu">
    <li class="tree"><span class="shorthand">JS&nbsp;Properties&nbsp;and&nbsp;Methods</span>
        <ul class="hide">
			<li><a href="/javascript-reference/javascript-array-object.php">JS Array Object</a></li>
			<li><a href="/javascript-reference/javascript-boolean-object.php">JS Boolean Object</a></li> 
			<li><a href="/javascript-reference/javascript-date-object.php">JS Date Object</a></li> 
			<li><a href="/javascript-reference/javascript-math-object.php">JS Math Object</a></li> 
			<li><a href="/javascript-reference/javascript-number-object.php">JS Number Object</a></li> 
            <li><a href="/javascript-reference/javascript-string-object.php">JS String Object</a></li> 			         
        </ul>
	<li><a href="/javascript-reference/javascript-reserved-keywords.php">JS Reserved Keywords</a></li>    
	<li><a href="/references.php" class="more">More References</a></li>
</ul>        
                </div>
        <div class="centercolumn">
            <!--Text Content-->
            <div class="content">
                <div class="leaderboard">
                    
<div class="ad-label">Advertisements</div>
<div class="ad-container">
    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <!-- Responsive Leaderboard -->
    <ins class="adsbygoogle"
            style="display:inline-block;max-width:728px;width:100%;height:90px"
            data-ad-client="ca-pub-9107540490929984"
            data-ad-slot="4302666817"></ins>
    <script>
    (adsbygoogle = window.adsbygoogle || []).push({});
    </script>
</div>                </div>
                <!-- InstanceBeginEditable name="main_content" -->
                <a href="javascript-error-handling.php" class="previous-page" title="Go to Previous Page"></a>
            	<a href="javascript-form-validation.php" class="next-page" title="Go to Next Page"></a>
                <h1>JavaScript <span>Regular Expressions</span></h1>
                <p class="summary">In this tutorial you will learn how regular expressions work, as well as how to use them to perform pattern matching in an efficient way in JavaScript.</p>
				<h2>What is Regular Expression</h2>
				<p>Regular Expressions, commonly known as "<strong>regex</strong>" or "<strong>RegExp</strong>", are a specially formatted text strings used to find patterns in text. Regular expressions are one of the most powerful tools available today for effective and efficient text processing and manipulations. For example, it can be used to verify whether the format of data i.e. name, email, phone number, etc. entered by the user is correct or not, find or replace matching string within text content, and so on.</p>
				<p>JavaScript supports Perl style regular expressions. Why Perl style regular expressions? Because Perl (<em>Practical Extraction and Report Language</em>) was the first mainstream programming language that provided integrated support for regular expressions and it is well known for its strong support of regular expressions and its extraordinary text processing and manipulation capabilities.</p>
				<p>Let's begin with a brief overview of the commonly used JavaScript's built-in methods for performing pattern-matching before delving deep into the world of regular expressions.</p>
				<div class="shadow">
					<table class="data">
						<thead>
							<tr>
								<th>Function</th>
								<th>What it Does</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td><code>exec()</code></td>
								<td>Search for a match in a string. It returns an array of information or <code>null</code> on mismatch.</td>
							</tr>
							<tr>
								<td><code>test()</code></td>
								<td>Test whether a string matches a pattern. It returns <code>true</code> or <code>false</code>.</td>
							</tr>
							<tr>
								<td><code>search()</code></td>
								<td>Search for a match within a string. It returns the index of the first match, or <code>-1</code> if not found.</td>
							</tr>							
							<tr>
								<td><code>replace()</code></td>
								<td>Search for a match in a string, and replaces the matched substring with a replacement string.</td>
							</tr>
							<tr>
								<td><code>match()</code></td>
								<td>Search for a match in a string. It returns an array of information or <code>null</code> on mismatch.</td>
							</tr>							
							<tr>
								<td><code>split()</code></td>
								<td>Splits up a string into an array of substrings using a regular expression.</td>
							</tr>
						</tbody>
					</table>
				</div>
				<!--Note box-->
                <div class="color-box">
                    <div class="shadow">
                        <div class="info-tab note-icon" title="Important Notes"><i></i></div>
                        <div class="note-box">
                            <p><strong>Note:</strong> The methods <code>exec()</code> and <code>test()</code> are RegExp methods that takes a string as a parameter, whereas the methods <code>search()</code>, <code>replace()</code>, <code>match()</code> and <code>split()</code>  are String methods that takes a regular expression as a parameter.</p>
                        </div>
                    </div>
                </div>
                <!--End:Note box-->
				<hr />
				<h2>Defining Regular Expressions</h2>
				<p>In JavaScript, regular expressions are represented by RegExp object, which is a native JavaScript object like String, Array, and so on. There are two ways of creating a new RegExp object &mdash; one is using the literal syntax, and the other is using the <code>RegExp()</code> constructor.</p>
				<p>The literal syntax uses forward slashes (<code><em>/pattern/</em></code>) to wrap the regular expression pattern, whereas the constructor syntax uses quotes (<code><em>"pattern"</em></code>). The following example demonstrates both ways of creating a regular expression that matches any string that begins with "Mr.".</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=creating-a-regular-expression" target="_blank" class="try-btn" title="Run this code to view the output">Run this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-javascript">// Literal syntax 
var regex = /^Mr\./;

// Constructor syntax
var regex = new RegExp("^Mr\\.");</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<p>As you can see, the regular expression literal syntax is shorter and easier to read. Therefore it is preferable to use the literal syntax. We'll also use it throughout this tutorial.</p>
				<!--Note box-->
				<div class="color-box space">
					<div class="shadow">
						<div title="Important Notes" class="info-tab note-icon"><i></i></div>
						<div class="note-box">
							<p><strong>Note:</strong> When using the constructor syntax, you've to double-escape <a href="#special-characters">special characters</a>, which means to match "." you need to write <code>"\\."</code> instead of <code>"\."</code>. If there is only one backslash, it would be interpreted by JavaScript's string parser as an escaping character and removed.</p>
						</div>
					</div>
				</div>
				<!--End:Note box-->
				<h2>Pattern Matching with Regular Expression</h2>
				<p>Regular expression patterns include the use of letters, digits, punctuation marks, etc., plus a set of special regular expression characters (do not confuse with the <a href="../html-tutorial/html-entities.php">HTML special characters</a>).</p>
				<p id="special-characters">The characters that are given special meaning within a regular expression, are: <br /><code>.</code> <code>*</code> <code>?</code> <code>+</code> <code>[</code> <code>]</code> <code>(</code> <code>)</code> <code>{</code> <code>}</code> <code>^</code> <code>$</code> <code>|</code> <code>\</code>. You will need to backslash these characters whenever you want to use them literally. For example, if you want to match ".", you'd have to write <code>\.</code>. All other characters automatically assume their literal meanings.</p>
				<p class="space">The following sections describe the various options available for formulating patterns:</p>
				<h2 id="character-classes">Character Classes</h2>
				<p>Square brackets surrounding a pattern of characters are called a character class e.g. <code>[abc]</code>. A character class always matches a single character out of a list of specified characters that means the expression <code>[abc]</code> matches only a, b or c character.</p>
				<p>Negated character classes can also be defined that match any character except those contained within the brackets. A negated character class is defined by placing a caret (<code>^</code>) symbol immediately after the opening bracket, like <code>[^abc]</code>, which matches any character except a, b, and c.</p>
				<p>You can also define a range of characters by using the hyphen (<code>-</code>) character inside a character class, like <code>[0-9]</code>. Let's look at some examples of the character classes:</p>
				<div class="shadow">
					<table class="data">
						<thead>
							<tr>
								<th>RegExp</th>
								<th>What it Does</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td><code>[abc]</code></td>
								<td>Matches any one of the characters a, b, or c.</td>
							</tr>
							<tr>
								<td><code>[^abc]</code></td>
								<td>Matches any one character other than a, b, or c.</td>
							</tr>
							<tr>
								<td><code>[a-z]</code></td>
								<td>Matches any one character from lowercase a to lowercase z.</td>
							</tr>
							<tr>
								<td><code>[A-Z]</code></td>
								<td>Matches any one character from uppercase a to uppercase z.</td>
							</tr>
							<tr>
								<td><code>[a-Z]</code></td>
								<td>Matches any one character from lowercase a to uppercase Z.</td>
							</tr>
							<tr>
								<td><code>[0-9]</code></td>
								<td>Matches a single digit between 0 and 9.</td>
							</tr>
							<tr>
								<td><code>[a-z0-9]</code></td>
								<td>Matches a single character between a and z or between 0 and 9.</td>
							</tr>
						</tbody>
					</table>
				</div>
				<p>The following example will show you how to find whether a pattern exists within a string or not using the regular expression with the JavaScript <code>test()</code> method:</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=match-a-single-character-using-regular-expression" target="_blank" class="try-btn" title="Run this code to view the output">Run this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-javascript">var regex = /ca[kf]e/;
var str = "He was eating cake in the cafe.";

// Test the string against the regular expression
if(regex.test(str)) {
    alert("Match found!");
} else {
    alert("Match not found.");
}</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<p>Further, you can add the <a href="#flags">global flag</a> <code>g</code> to a regular expression to find all matches in a string:</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=find-all-occurrences-of-a-pattern-in-a-string-using-regular-expression" target="_blank" class="try-btn" title="Run this code to view the output">Run this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-javascript">var regex = /ca[kf]e/g;
var str = "He was eating cake in the cafe.";
var matches = str.match(regex);
alert(matches.length); // Outputs: 2</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<!--Tip Box-->
				<div class="color-box">
					<div class="shadow">
						<div class="info-tab tip-icon" title="Useful Tips"><i></i></div>
						<div class="tip-box">
							<p><strong>Tip:</strong> Regular expressions aren't exclusive to JavaScript. Languages such as Java, Perl, Python, PHP, etc. use the same notation for finding patterns in text.</p>
						</div>
					</div>
				</div>
				<!--End:Tip Box-->
				<hr />
				<h2>Predefined Character Classes</h2>
				<p>Some character classes such as digits, letters, and whitespaces are used so frequently that there are shortcut names for them. The following table lists those predefined character classes:</p>
				<div class="shadow">
					<table class="data">
						<thead>
							<tr>
								<th style="width: 60px;">Shortcut</th>
								<th>What it Does</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td><code>.</code></td>
								<td>Matches any single character except newline <code>\n</code>.</td>
							</tr>
							<tr>
								<td><code>\d</code></td>
								<td>matches any digit character. Same as <code>[0-9]</code></td>
							</tr>
							<tr>
								<td><code>\D</code></td>
								<td>Matches any non-digit character. Same as <code>[^0-9]</code></td>
							</tr>
							<tr>
								<td><code>\s</code></td>
								<td>Matches any whitespace character (space, tab, newline or carriage return character). <br />Same as <code>[ \t\n\r]</code></td>
							</tr>
							<tr>
								<td><code>\S</code></td>
								<td>Matches any non-whitespace character. <br />Same as <code>[^ \t\n\r]</code></td>
							</tr>
							<tr>
								<td><code>\w</code></td>
								<td>Matches any word character (definned as a to z, A to Z,0 to 9, and the underscore). <br />Same as <code>[a-zA-Z_0-9]</code></td>
							</tr>
							<tr>
								<td><code>\W</code></td>
								<td>Matches any non-word character. Same as <code>[^a-zA-Z_0-9]</code></td>
							</tr>
						</tbody>
					</table>
				</div>
				<p>The following example will show you how to find and replace space with a hyphen character in a string using regular expression with the JavaScript <code>replace()</code> method:</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=find-and-replace-characters-in-a-string-using-regular-expression" target="_blank" class="try-btn" title="Run this code to view the output">Run this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-javascript">var regex = /\s/g;
var replacement = "-";
var str = "Earth revolves around\nthe\tSun";

// Replace spaces, newlines and tabs
document.write(str.replace(regex, replacement) + "&lt;hr&gt;");

// Replace only spaces
document.write(str.replace(/ /g, "-"));</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<hr />				
				<h2 id="repetition-quantifiers">Repetition Quantifiers</h2>
				<p>In the previous section we've learnt how to match a single character in a variety of fashions. But what if you want to match on more than one character? For example, let's say you want to find out words containing one or more instances of the letter p, or words containing at least two p's, and so on.</p>
				<p>This is where quantifiers come into play. With quantifiers you can specify how many times a character in a regular expression should match. Quantifiers can be applied to the individual characters, as well as <a href="#character-classes">classes of characters</a>, and <a href="#grouping">groups of characters</a> contained by the parentheses.</p>
				<p>The following table lists the various ways to quantify a particular pattern:</p>
				<div class="shadow">
					<table class="data">
						<thead>
							<tr>
								<th style="width: 80px;">RegExp</th>
								<th>What it Does</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td><code>p+</code></td>
								<td>Matches one or more occurrences of the letter p.</td>
							</tr>
							<tr>
								<td><code>p*</code></td>
								<td>Matches zero or more occurrences of the letter p.</td>
							</tr>
							<tr>
								<td><code>p?</code></td>
								<td>Matches zero or one occurrences of the letter p.</td>
							</tr>
							<tr>
								<td><code>p{2}</code></td>
								<td>Matches exactly two occurrences of the letter p.</td>
							</tr>
							<tr>
								<td><code>p{2,3}</code></td>
								<td>Matches at least two occurrences of the letter p, but not more than three occurrences.</tr>
							<tr>
								<td><code>p{2,}</code></td>
								<td>Matches two or more occurrences of the letter p.</td>
							</tr>
							<tr>
								<td><code>p{,3}</code></td>
								<td>Matches at most three occurrences of the letter p</td>
							</tr>
						</tbody>
					</table>
				</div>
				<p>The regular expression in the following example will splits the string at comma, sequence of commas, whitespace, or combination thereof using the JavaScript <code>split()</code> method:</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=split-a-string-using-regular-expression" target="_blank" class="try-btn" title="Run this code to view the output">Run this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-javascript">var regex = /[\s,]+/;
var str = "My favourite colors are red, green and blue";
var parts = str.split(regex);

// Loop through parts array and display substrings
for(var part of parts){
    document.write("&lt;p&gt;" + part + "&lt;/p&gt;");
}</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<hr />
				<h2>Position Anchors</h2>
				<p>There are certain situations where you want to match at the beginning or end of a line, word, or string. To do this you can use anchors. Two common anchors are caret (<code>^</code>) which represent the start of the string, and the dollar (<code>$</code>) sign which represent the end of the string.</p>
				<div class="shadow">
					<table class="data">
						<thead>
							<tr>
								<th>RegExp</th>
								<th>What it Does</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td><code>^p</code></td>
								<td>Matches the letter p at the beginning of a line.</td>
							</tr>
							<tr>
								<td><code>p$</code></td>
								<td>Matches the letter p at the end of a line.</td>
							</tr>
						</tbody>
					</table>
				</div>
				<p>The regular expression in the following example will match only those names in the names array which start with the letter "J" using the JavaScript <code>test()</code> function:</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=match-strings-beginning-with-specific-characters-using-regular-expression" target="_blank" class="try-btn" title="Run this code to view the output">Run this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-javascript">var regex = /^J/;
var names = ["James Bond", "Clark Kent", "John Rambo"];

// Loop through names array and display matched names
for(var name of names) {
    if(regex.test(name)) {
        document.write("&lt;p&gt;" + name + "&lt;/p&gt;")
    }
}</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<hr />
				<h2 id="flags">Pattern Modifiers (Flags)</h2>
				<p>A pattern modifier allows you to control the way a pattern match is handled. Pattern modifiers are placed directly after the regular expression, for example, if you want to search for a pattern in a case-insensitive manner, you can use the <code>i</code> modifier, like this: <code>/pattern/i</code>.</p>
				<p>The following table lists some of the most commonly used pattern modifiers.</p>
				<div class="shadow">
					<table class="data">
						<thead>
							<tr>
								<th>Modifier</th>
								<th>What it Does</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td><code>g</code></td>
								<td>Perform a global match i.e. finds all occurrences.</td>
							</tr>
							<tr>
								<td><code>i</code></td>
								<td>Makes the match case-insensitive manner.</td>
							</tr>
							<tr>
								<td><code>m</code></td>
								<td>Changes the behavior of <code>^</code> and <code>$</code> to match against a newline boundary (i.e. start or end of each line within a multiline string), instead of a string boundary.</td>
							</tr>							
							<tr>
								<td><code>o</code></td>
								<td>Evaluates the expression only once.</td>
							</tr>
							<tr>
								<td><code>s</code></td>
								<td>Changes the behavior of <code>.</code> (dot) to match all characters, including newlines.</td>
							</tr>
							<tr>
								<td><code>x</code></td>
								<td>Allows you to use whitespace and comments within a regular expression for clarity.</td>
							</tr>
						</tbody>
					</table>
				</div>				
				<p>The following example will show you how to use the <code>g</code> and <code>i</code> modifiers in a regular expression to perform a global and case-insensitive search with the JavaScript <code>match()</code> method.</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=match-the-pattern-in-a-case-insensitive-manner-using-regular-expression" target="_blank" class="try-btn" title="Run this code to view the output">Run this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-javascript">var regex = /color/gi;
var str = "Color red is more visible than color blue in daylight.";
var matches = str.match(regex); // global, case-insensitive match
console.log(matches);
// expected output: ["Color", "color"]</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<p>Similarly, the following example shows how to match at the beginning of every line in a multi-line string using the <code>^</code> anchor and <code>m</code> modifier with the JavaScript <code>match()</code> method.</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=match-a-pattern-in-a-multiline-string-using-regular-expression" target="_blank" class="try-btn" title="Run this code to view the output">Run this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-javascript">var regex = /^color/gim;
var str = "Color red is more visible than \ncolor blue in daylight.";
var matches = str.match(regex); // global, case-insensitive, multiline match
console.log(matches);
// expected output: ["Color", "color"]</code></pre>
                    </div>
                </div>
                <!--End:Code box-->				
				<hr />
				<h2>Alternation</h2>
				<p>Alternation allows you to specify alternative version of a pattern. Alternation in a regular expression works just like the <code>OR</code> operator in an <code>if-else</code> conditional statement.</p>
				<p>You can specify alternation using a vertical bar (<code>|</code>). For example, the regexp <code>/fox|dog|cat/</code> matches the string "fox", or the string "dog", or the string "cat". Here's an example:</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=specify-alternative-version-of-a-pattern-in-a-regular-expression" target="_blank" class="try-btn" title="Run this code to view the output">Run this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-javascript">var regex = /fox|dog|cat/;
var str = "The quick brown fox jumps over the lazy dog.";
var matches = str.match(regex);
console.log(matches);
// expected output: ["fox", index: 16, ...]</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<!--Note box-->
				<div class="color-box">
					<div class="shadow">
						<div title="Important Notes" class="info-tab note-icon"><i></i></div>
						<div class="note-box">
							<p><strong>Note:</strong> Alternatives are evaluated from left to right until a match is found. If the left alternative matches, the right alternative is ignored completely even if it has a match.</p>
						</div>
					</div>
				</div>
				<!--End:Note box-->
				<hr />
				<h2 id="grouping">Grouping</h2>
				<p>Regular expressions use parentheses to group subexpressions, just like mathematical expressions. Parentheses allow a <a href="#repetition-quantifiers">repetition quantifier</a> to be applied to an entire subexpression.</p>
				<p>For example, in regexp <code>/go+/</code> the quantifier <code>+</code> is applied only to the last character <code>o</code> and it matches the strings "go", "goo", and so on. Whereas, in regexp <code>/(go)+/</code> the quantifier <code>+</code> is applied to the group of characters <code>g</code> and <code>o</code> and it matches the strings "go", "gogo", and so on.</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=grouping-subexpressions-in-a-regular-expression" target="_blank" class="try-btn" title="Run this code to view the output">Run this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-javascript">var regex = /(go)+/i; 
var str = "One day Gogo will go to school.";
var matches = str.match(regex); // case-insensitive match
console.log(matches);
// expected output: ["Gogo", "go", index: 8, ...]</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<!--Note box-->
				<div class="color-box">
					<div class="shadow">
						<div title="Important Notes" class="info-tab note-icon"><i></i></div>
						<div class="note-box">
							<p><strong>Note:</strong> If the string matches the pattern, the <code>match()</code> method returns an array containing the entire matched string as the first element, followed by any results captured in parentheses, and the index of the whole match. If no matches were found, it returns <code>null</code>.</p>
						</div>
					</div>
				</div>
				<!--End:Note box-->
				<!--Tip Box-->
				<div class="color-box">
					<div class="shadow">
						<div class="info-tab tip-icon" title="Useful Tips"><i></i></div>
						<div class="tip-box">
							<p><strong>Tip:</strong> If the regular expression includes the <code>g</code> flag, the <code>match()</code> method only returns an array containing all matched substrings rather than match object. Captured groups, index of the whole match, and other properties are not returned.</p>
						</div>
					</div>
				</div>
				<!--End:Tip Box-->
				<hr />
				<h2>Word Boundaries</h2>
				<p>A word boundary character ( <code>\b</code>) helps you search for the words that begins and/or ends with a pattern. For example, the regexp <code>/\bcar/</code> matches the words beginning with the pattern car, and would match cart, carrot, or cartoon, but would not match oscar.</p>
				<p>Similarly, the regexp <code>/car\b/</code> matches the words ending with the pattern car, and would match oscar or supercar, but would not match cart. Likewise, the <code>/\bcar\b/</code> matches the words beginning and ending with the pattern car, and would match only the word car.</p>
				<p>The following example will highlight the words beginning with car in bold:</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=javascript&amp;file=match-words-starts-or-ends-with-a-pattern-using-regular-expression" target="_blank" class="try-btn" title="Run this code to view the output">Run this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-javascript">var regex = /(\bcar\w*)/g;
var str = "Words begining with car: cart, carrot, cartoon. Words ending with car: oscar, supercar.";
var replacement = '&lt;b&gt;$1&lt;/b&gt;';
var result = str.replace(regex, replacement);
document.write(result);</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<!--Bottom Navigation-->
				<div class="bottom-link clearfix">
                    <a href="javascript-error-handling.php" class="previous-page-bottom">Previous Page</a>
                    <a href="javascript-form-validation.php" class="next-page-bottom">Next Page</a>
                </div>
                <!--End:Bottom Navigation--> 
                <!-- InstanceEndEditable -->
                <!--Bottom Ads-->
                <div class="bottom-ad clearfix">
                    <div class="ad-label">Advertisements</div>

<!--Rectangle Left-->
<div class="rectangle-left fl">
    
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Large Rectangle Left -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="8162953958"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
<!--End:Rectangle Left-->


<!--Rectangle Right-->
<div class="rectangle-right fr">

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Large Rectangle Right -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="3324015654"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
<!--End:Rectangle Right-->                </div>
                <!--End:Bottom Ads-->
            </div>
            <!--End:Text Content-->
            <!--Feedback Form-->
			<div class="snippets">
	<a href="/snippets/gallery.php" target="_blank">
    	<img src="/lib/images/bootstrap-code-snippets.png" alt="Bootstrap UI Design Templates" />
	</a>
</div>

<div class="report-error" id="feedback">
    <div class="contact-form clearfix">
        <div class="close"><span class="icon-close"></span></div>
        <form id="feedback-form">
            <h3>Your Feedback:</h3>
            <div class="clearfix">
                <div class="name fl"><label>Your Name (optional) <input type="text" name="user-name" id="user-name" /></label></div>
                <div class="email fr"><label>Your E-mail (optional) <input type="text" name="user-email" id="user-email" /></label></div>
            </div>
            <div><label>Page address <input type="text" name="page-url" id="page-url" class="disabled" disabled="disabled" /></label></div>
            <div><label>Description <textarea name="description" id="description" rows="6"></textarea></label></div>
            <p id="feedback-error">We would love to hear from you, please drop us a line.</p>
            <div><button type="button" class="action-btn" onclick="sendFeedback()"><span class="icon-send"></span> Send</button></div>
        </form>
        <div id="response"></div>
    </div>           
</div>            <!--End:Feedback Form-->
        </div>        
        <div class="sidebar">
            <div class="ad-label">Advertisements</div>

<div class="skyscraper primary">

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Premium Skyscraper -->
<ins class="adsbygoogle"
     style="display:inline-block;width:160px;height:600px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="4376141825"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>

<div class="skyscraper">
    
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Bottom Skyscraper -->
<ins class="adsbygoogle"
     style="display:inline-block;width:160px;height:600px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="3387984471"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>        </div>
    </div>
    <!--Footer-->
	<!--Footer-->
<div class="footer">
    <div class="appeal">
        <div class="wrapper">
            <p>Is this website helpful to you? Please give us a
            <a href="/like.php" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=250,width=600,top=150, left='+((screen.width/2)-300));return false;">like</a>,
            or share your <a href="#feedback" class="feedback">feedback</a><em> to help us improve</em>.
            Connect with us on <a href="https://www.facebook.com/tutorialrepublic" target="_blank">Facebook</a> and <a href="https://twitter.com/tutrepublic" target="_blank">Twitter</a> for the latest updates.</p>               
        </div>
    </div>
    <div class="footer-inner">
        <div class="wrapper clearfix">                
            <div class="link-box">
                <h4>About Us</h4>
                <div class="clearfix">
                    <a href="/about-us.php">Our Story</a>                    
                    <a href="/terms-of-use.php">Terms of Use</a>
                    <a href="/privacy-policy.php">Privacy Policy</a>                    
                </div>
            </div>
            <div class="link-box">
                <h4>Contact</h4>
                <div class="clearfix">
                    <a href="/contact-us.php">Contact Us</a>                    
                    <a href="#feedback" class="feedback">Report Error</a>
                    <a href="/advertise-with-us.php">Advertise</a>                    
                </div>
            </div>
            <div class="tool-box">
                <h4>Interactive Tools</h4>
                <div class="tools-list clearfix" id="tools">
                    <a href="/faq/what-is-the-maximum-length-of-title-and-meta-description-tag.php">Title &amp; Meta Length Calculator</a>                           
                    <a href="/html-formatter.php" target="_blank">HTML Formatter</a>                        
                    <a href="/twitter-bootstrap-button-generator.php" target="_blank">Bootstrap Button Generator</a>
                    <a href="/html-reference/html-color-picker.php">HTML Color Picker</a>
                    <a href="/codelab.php?topic=sql&amp;file=select-all" target="_blank">SQL Playground</a>
                    <a href="/codelab.php?topic=html&amp;file=hello-world" target="_blank">HTML Editor</a>                    
                </div>
            </div>
            <div class="footer-logo">
                <img src="/lib/images/logo.svg" alt="TutorialRepublic" />
            </div>
        </div>
    </div>           
        <div class="bottom-strip">
        <div class="wrapper">
            <div class="notice">Copyright &copy; 2019 Tutorial Republic. All Rights Reserved.</div>
            <div class="social-media">
                <em>Share This:</em>
                <a href="https://facebook.com/sharer.php?u=https://www.tutorialrepublic.com%2Fjavascript-tutorial%2Fjavascript-regular-expressions.php" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" title="Facebook"><i class="icon-facebook"></i></a>
                <a href="#" id="tweet-btn" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" title="Twitter"><i class="icon-twitter"></i></a>
                <a href="#" id="email-btn" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" rel="noreferrer" title="Gmail"><i class="icon-mail"></i></a>
            </div>
        </div>            
    </div>
    <script>
        var title = document.title.replace('- Tutorial Republic', '');
        document.getElementById('tweet-btn').href = 'https://twitter.com/share?text=' + title + '- &url=https://www.tutorialrepublic.com%2Fjavascript-tutorial%2Fjavascript-regular-expressions.php';
        document.getElementById('email-btn').href = 'https://mail.google.com/mail/?view=cm&fs=1&su=' + title + '&body=https://www.tutorialrepublic.com%2Fjavascript-tutorial%2Fjavascript-regular-expressions.php';
    </script>
</div>
<!--End:Footer-->
    
<div class="backdrop mobile-only"></div>

<!-- TutorialRepublic base script -->
<script>
// Adding CSS files
[
	'/lib/styles/extended.new-3.7.css',
	'/lib/icomoon/style.css'
].forEach(function(href) {
	var link = document.createElement('link');
	link.rel = 'stylesheet';
	link.href = href;
	(document.getElementsByTagName('head')[0]).appendChild(link);
});

// Adding JS files
[
	'https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js',
	'/lib/js/prism.js',
	'/lib/js/default.new-2.9.min.js'
].forEach(function(src) {
	var script = document.createElement('script');
	script.async = false; // important
	script.src = src;
	(document.getElementsByTagName('body')[0]).appendChild(script);
});
</script>


    <!--End:Footer-->
</body>
<!-- InstanceEnd --></html>