<!DOCTYPE html>
<html lang="en"><!-- InstanceBegin template="/Templates/html.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
	<!-- InstanceBeginEditable name="doctitle" -->
    <title>HTML Language Codes - List of Two Letter ISO Language Codes</title>
    <meta name="description" content="A comprehensive list of ISO language codes for international languages along with the name of their language families. Language codes are case-insensitive." />
    <!-- InstanceEndEditable -->
    	<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta property="fb:admins" content="100001054961582" />
<meta property="fb:app_id" content="1404574483159557" />
<meta property="og:image" content="/lib/images/signature.png" />
<link type="image/x-icon" href="/favicon.ico" rel="shortcut icon" />
<style>
html,body,h1,h2,h3,h4,h5,h6,p,blockquote,pre,img{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}
html,body{min-height:100%}
p{margin:0 0 12px}
ol,ul{margin:0 0 12px}
a,a:active,a:visited{outline:none;color:#1db79f;text-decoration:none}
a code{color:inherit}
a img{border:none;outline:none}
code{color:#000}
table{border-collapse:collapse;border-spacing:0}
table td{vertical-align:top}
body{min-width:1300px;color:#414141;background:#fafafa;font-family:"Segoe UI","Helvetica Neue",Arial,sans-serif;font-size:17px;line-height:1.7}
input,select,textarea,button,div,span,a{box-sizing:border-box}
h1,h2,h3,h4{color:#262626;font-weight:500;margin:20px 0 10px;line-height:1.5;font-weight:600}
h1{font-size:34px;margin-top:17px}
h2{font-size:28px}
h3{font-size:22px}
.space{margin-bottom:25px!important}
.break{margin-bottom:15px!important}
.text-center{text-align:center!important}
.scroll{height:195px;overflow-y:scroll}
.scroll.large{height:245px}
.scroll.xlarge{height:290px}
.scroll.xxlarge{height:340px}
sup{font-size:13px}
pre{background:none;border-radius:0}
.leaderboard{padding-top:8px;position:relative}
.ad-container{height:90px;overflow:hidden}
.intro-image img{display:block;padding:10px 0 25px;max-width:100%}
.clearfix::after{content:".";display:block;height:0;clear:both;visibility:hidden}
code,.code,.syntax,.green-box,.sky-box,.gray-box,.pink-box,.red-box,.at-rule,.codebox ul,.console-output{font-size:16px;font-family:Consolas,Monaco,Courier,monospace}
p code,table.data td:last-child code,.content ul li code,code.mark{padding:2px 4px;color:#333;background-color:#f1f1f1;border-radius:4px}
p code a,table.data td:last-child code a, .content ul li code a{padding:2px 0;background:#fff;margin:0 -4px;font-size:16px}
.console-output{margin:15px 0}
hr{border:none;border-bottom:1px solid #e7e9ed;height:1px;margin:30px 0}
.summary,.topic{border:1px solid #eaeaea;border-width:1px 0;margin:20px 0;padding:10px 0;color:#8e9aa6;line-height:1.5}
h2.section-title span{display:inline-block;border-bottom:4px solid #c9d7e0;padding:0 50px 12px 0}
.wrapper{width:1300px;padding:0 15px;margin:0 auto}
.header{background:#23384e;padding:16px 0}
input.search{background:#fff;border:0 none;color:#807E7E;float:left;height:38px;line-height:26px;font-size:14px;margin:0 0 0 12px;outline:medium none;padding:6px 14px;width:500px;border-radius:2px;box-shadow:0 0 1px rgba(0,0,0,0.6);font-family:inherit}
.search-btn{color:rgba(0,0,0,.6);background:#ebebeb;border:none;outline:none;cursor:pointer;float:left;height:38px;line-height:46px;width:44px;display:block;margin-left:-2px;border-radius:0 2px 2px 0;box-shadow:0 0 1px rgba(0,0,0,0.7)}
.logo{width:304px}
.logo img{height:44px;margin:-3px 0;display:block}
.site-search{float:left;margin-left:100px}
.menu{background-color:#f5f5f5;box-shadow:0 1px 1px rgba(0,0,0,.15);position:relative;z-index:9}
.menu a{color:#666;display:inline-block;padding:0 10px;text-decoration:none;font-size:14px;font-weight:600;height:48px;line-height:48px}
.menu a:first-child{margin-left:-10px}
.menu a.tool-link{float:right;display:inline-block;border-radius:30px;line-height:28px;position:relative;height:auto;top:9px;padding:0 12px;color:#1ebba3;border:1px double #1ebba3}
.fl,.logo{float:left}
.leftcolumn{width:240px;float:left;font-size:16px;color:#4f4f4f}
.centercolumn{width:850px;float:left}
.content{background:#fff;padding:20px 40px;border:1px solid #dedede;border-top:none;border-radius:1px}
.sidebar{float:left;padding-top:28px;width:160px;margin-left:20px;position:relative}
.leftcolumn .segment{margin:16px 0 12px;position:relative;font-size:18px;font-weight:600;display:inline-block;line-height:normal}
.leftcolumn a{color:#4f4f4f;font-size:16px;line-height:26px;display:block;border-bottom:1px solid transparent}
.leftcolumn ul{list-style:none;padding:0}
.segment,.chapters,.chapters a,.toggle-tree-menu{float:left;clear:both}
ul.tree-menu li.tree{margin-left:-12px;float:left;width:100%}
ul.tree-menu li a,ul.tree-menu li code{color:#4f4f4f;font-size:15.4px}
ul.chapters.tree-menu li a{font-size:16px}
h1 code,h2 code,h3 code{font:inherit}
.color-box{margin:15px 0;padding-left:20px}
.note-box,.warning-box,.tip-box{padding:8px 8px 3px 26px}
.info-tab{float:left;margin-left:-23px}
.content ul li{margin-top:7px}
.extra{padding-top:5px}
.green-box,.sky-box,.gray-box,.red-box,.pink-box{color:#000;margin-top:15px;padding:10px;background-color:#f6f8fa;border:1px solid #d7e2ec}
.example{background:#f4f5f6;padding:3px;margin:15px 0}
.codebox{background:#fff;border:1px solid #ddd}
.codebox-title{height:41px;padding-left:12px;border-bottom:1px solid #ddd;background:#f5f5f5}
.codebox-title h4{margin:0;font-size:18px;line-height:38px;float:left;display:inline;font-weight:500}
a.try-btn,a.download-btn{width:140px;height:40px;color:#333;font-size:15px;line-height:41px;font-weight:600;text-align:center;text-decoration:none;float:right;display:block;border-left:1px solid #ddd;background:rgba(27,31,35,0.08);box-sizing:border-box;font-family:Arial,sans-serif}
a.try-btn span{font-size:18px;line-height:normal}
.hide,.code-style,.box-size,.bottom-link,.footer,.code-style,.snippets,.report-error,.badge,.social,.ad-label,.mobile-only{display:none}
.skyscraper{width:160px;height:600px;overflow:hidden;margin-bottom:20px;background:#ebecf0}
.bottom-ad{margin-top:46px;padding:24px;position:relative;background:url(/lib/images/smooth-line.png) no-repeat center #f9f9f9}
.rectangle-left,.rectangle-right{min-width:336px;min-height:280px;overflow:hidden}
.fr,a.previous-page,a.next-page,.topic-nav{float:right}
a.previous-page,a.next-page{width:32px;height:32px;line-height:30px}
.shadow{background:#F7F8F9;padding:3px;margin:10px 0}
.syntax{color:#2f4959;padding:13px 18px;background:#F9F9FA;border:1px solid #ddd;font-size:15px}
.codebox ul{font-size:14px;padding:7px;list-style:decimal inside none}
.codebox ul.lead-zero,.codebox ul.lead-double-zero{list-style-type:decimal-leading-zero}
.codebox ul li{padding:0 9px;color:#AFAFAF;background-image:none;margin:0}
.codebox ul pre,.codebox ul li,.codebox ul li code{line-height:1.6;vertical-align:top}
.codebox ul pre,.codebox ul code{width:90%;font-size:16px;color:#222;display:inline-block;padding-left:10px;border-left:3px solid #6CE26C;white-space:pre-wrap;word-break:normal}
.codebox ul.lead-double-zero li{text-align:right}
.codebox ul.lead-double-zero li pre{text-align:left}
.codebox ul.sql.single-line pre{line-height:26px}
.content .codebox ul li code{color:#222;padding:0 0 0 10px}
.preview-box{padding:15px;text-align:center;cursor:pointer;overflow:hidden;background:#FFF;border:1px solid #e6e6e6}
.preview-box a,.preview-box img{display:block;margin:0 auto}
.topic a:first-of-type{margin-left:2px}
.topic-nav{padding-right:5px;color:#d0d0d0}
.topic-nav a{padding:0 15px;margin:0 0 0 5px;position:relative;display:inline-block}
.topic-nav a::after{font-size:24px;position:absolute;line-height:normal;top:-6px}
.topic-nav a:first-child{margin:0 5px 0 0}
.topic-nav a:first-child::after{content:'\00AB';left:-5px}
.topic-nav a:last-child::after{content:'\00BB';right:-5px}
.download-box{text-align:center;padding:20px 0;margin:20px 0 10px}
.output-box{border-color:#d4d4d4;border-style:solid;border-width:1px 0;padding:5px 15px;overflow:hidden;background:#fff;margin:10px 0}
.demo-box{margin-top:15px}
.subhead{border-bottom:3px solid #DCE3EB;margin-bottom:15px;padding-bottom:10px}
table.data,table.description{width:100%;font-size:92%}
table.data th{color:#000;padding:8px 7px;text-align:left;font-size:15px;background:#F8F8F8}
table.data td{color:#484848;padding:5px 7px;background:#fff}
table.data th,table.data td{vertical-align:top;border:1px solid #DCE3EB}
table.data tr.section th,table.data td.section{font-size:15px;background:#f0f4f7}
table.description th{width:150px;padding:7px;vertical-align: middle}
table.no-wrap tr td:first-child{white-space:nowrap}
.overview{padding-right:202px}
.overview .intro-image{float:right;margin-right:-202px;text-align:right}
.overview .intro-image + p{padding-top:0}
.support{background:#F8F8F8;border:1px solid #ccc;color:#2F4959;padding:15px}
.support table td:first-child{width:200px;padding:0 25px 0 10px;border-right:1px dashed #D0D0D0}
.support h2{color:#2F4959;font-size:16px;padding:0 0 0 30px;margin-top:0}
.support ul{margin-left:10px}
.support ul li{margin-top:4px}
h1 sup{background:#ec0000;border-radius:3px;padding:5px 10px;font-size:15px;color:#fff;position:relative;top:5px}
@media screen and (max-width: 1280px) {
body{min-width:1260px}
.wrapper{width:1260px}
.leftcolumn{width:230px}
.centercolumn{width:820px}
}
@media screen and (max-width: 800px) {
body{min-width:100%;max-width:100%;padding-top:46px}
.wrapper{width:100%;padding:0}
.header{height:46px;padding:5px 0;position:fixed;top:0;left:0;right:0;width:100%;z-index:99}
.logo{width:auto;display:block;padding:6px 0 0 60px;position:absolute;left:0;z-index:100}
.logo img{height:30px}
.menu{width:100%;padding-left:12px;padding-right:12px;overflow-x:auto;white-space:nowrap}
.centercolumn{width:100%;float:none}
.content{padding:10px;border-width:0 0 1px 0}
.sidebar{margin: 25px auto 0}
.skyscraper{display:inline-block}
.shadow,.example{max-width:100%;overflow-x:auto}
.codebox-title{position:relative}
.codebox.multi-style-mode ul{padding-top:7px;margin-top:36px;border-top:1px solid #ddd}
.codebox ul,.codebox ul.scroll{overflow-x:auto}
.rectangle-left,.rectangle-right{float:none;display:inline-block;margin:10px auto;background:#EDEEF2}
.leftcolumn,.footer,.header .social,.header .site-search,.overview .intro-image,.toggle-tree-menu,.code-style,.support table td:first-child,ul.tree-menu code.shorthand,.menu a.tool-link,.backdrop{display:none}
.summary,.topic{padding:5px 0;margin:10px 0}
.leftcolumn,.centercolumn,.sidebar{float:none}
.header,.menu,.container,.footer,.appeal-text{width:100%;box-sizing:border-box}
.centercolumn{width:100%}
.content img{max-width:100%;height:auto}
.codebox ul li{width:614px}
.codebox ul.scroll li{width:597px}
.codebox ul,.codebox ul.scroll{overflow-x:auto}
a.try-btn,a.download-btn{width:130px}
.bottom-ad{height:auto;background:none;padding:30px 0 0;margin:40px 0 0;text-align:center;position:relative}
.native-unit{margin-bottom:30px}
.overview{padding-right:0}
.scroll-pane{overflow-x:auto}
table.data{min-width:480px}
table.data pre{display:inline;white-space:normal}
table tr th,table tr td{width:auto!important}
.support h2,.support ul{padding-left:0}
p.topic{vertical-align:top}
p.topic > a{word-wrap:break-word;display:inline-block}
.example-list ul li,ul.faq-list li{padding-bottom:3px}
.preview-box{padding:6px}
.topic-nav{float:none;display:block;padding:6px 0 0 5px}
.codebox.multi-style-mode ul{padding-top:7px;margin-top:34px;border-top:1px solid #ccc}
.content pre{max-width:100%;overflow:hidden}
.shadow,.content pre.console-output{max-width:100%;overflow-x:auto}
ul.tree-menu li.tree{margin-left:0}
.support ul{margin-left:20px}
.leaderboard{margin:20px 0}
h1{font-size:28px}
h2{font-size:24px}
h3{font-size:20px}
}
@media screen and (min-width: 801px) {
.site-search,.leftcolumn,.social{display:block!important}
.backdrop{display:none!important}
}</style>    
    <!-- InstanceBeginEditable name="head" -->
    <!-- InstanceEndEditable -->
    
    <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-40117907-1', 'auto');
  ga('send', 'pageview');
</script></head>
<body>
    <!--Header-->
    
<div class="header">
    <div class="wrapper clearfix">
        <button type="button" class="open-menu mobile-only"><i class="icon-menu"></i></button>
        <div class="logo">
            <a href="https://www.tutorialrepublic.com/"><img src="/lib/images/logo.svg" alt="TutorialRepublic" /></a>
        </div>
        <div class="site-search">
            <form action="https://www.google.com/search" method="get" target="_blank" class="clearfix">
                <input type="hidden" value="www.tutorialrepublic.com" name="sitesearch" />
                <input type="text" name="q" placeholder="Search topics, tutorials, questions and answers..." id="searchInput" class="search" />
                <button type="submit" class="search-btn"><span class="icon-search"></span></button>
            </form>
        </div>
        <div class="social">                
            <a href="https://www.facebook.com/tutorialrepublic" target="_blank" title="Join us on Facebook"><i class="icon-facebook"></i></a>
            <a href="https://twitter.com/tutrepublic" target="_blank" title="Follow us on Twitter"><i class="icon-twitter"></i></a>
            <a href="/contact-us.php" target="_blank" title="Send us an Email"><i class="icon-mail"></i></a>
        </div>
        <button type="button" class="open-search mobile-only">
            <i class="icon-search"></i>
        </button>
    </div>    
</div>
<div class="menu">
    <div class="wrapper">
        <a href="//www.tutorialrepublic.com" title="Home Page">HOME</a>
        <a href="/html-tutorial/" title="HTML Tutorial">HTML5</a>            
        <a href="/css-tutorial/" title="CSS Tutorial">CSS3</a>
        <a href="/javascript-tutorial/" title="JavaScript Tutorial">JAVASCRIPT</a>
        <a href="/jquery-tutorial/" title="jQuery Tutorial">JQUERY</a>
        <a href="/twitter-bootstrap-tutorial/" title="Bootstrap Tutorial">BOOTSTRAP4</a>
        <a href="/php-tutorial/" title="PHP Tutorial">PHP7</a> 
        <a href="/sql-tutorial/" title="SQL Tutorial">SQL</a>
        <a href="/references.php" title="Web References">REFERENCES</a>
        <a href="/practice-examples.php" title="Practice Examples and Demos">EXAMPLES</a>
        <a href="/faq.php" title="Frequently Asked Questions and Answers">FAQ</a>
        <a href="/snippets/gallery.php" title="Bootstrap Code Snippets" target="_blank">SNIPPETS</a>
        <a href="/codelab.php" class="tool-link" target="_blank">Online HTML Editor</a>
    </div>        
</div>    <!--End:Header-->
    <div class="wrapper clearfix">
        <div class="leftcolumn" id="myNav">
		
        <div class="segment"><span>HTML</span> BASIC</div>
<div class="chapters">
    <a href="/html-tutorial/">HTML Introduction</a>
    <a href="/html-tutorial/html-get-started.php">HTML Getting Started</a>
    <a href="/html-tutorial/html-elements.php">HTML Elements</a>
    <a href="/html-tutorial/html-attributes.php">HTML Attributes</a>
    <a href="/html-tutorial/html-headings.php">HTML Headings</a>
    <a href="/html-tutorial/html-paragraphs.php">HTML Paragraphs</a>
    <a href="/html-tutorial/html-links.php">HTML Links</a>
    <a href="/html-tutorial/html-text-formatting.php">HTML Text Formatting</a>
    <a href="/html-tutorial/html-styles.php">HTML Styles</a>
    <a href="/html-tutorial/html-images.php">HTML Images</a>
    <a href="/html-tutorial/html-tables.php">HTML Tables</a>
    <a href="/html-tutorial/html-lists.php">HTML Lists</a>
    <a href="/html-tutorial/html-forms.php">HTML Forms</a>
    <a href="/html-tutorial/html-iframes.php">HTML Iframes</a>
</div>
<div class="segment"><span>HTML</span> ADVANCED</div>
<div class="chapters">
    <a href="/html-tutorial/html-doctypes.php">HTML Doctypes</a>
    <a href="/html-tutorial/html-layout.php">HTML Layout</a>
    <a href="/html-tutorial/html-head.php">HTML Head</a>
    <a href="/html-tutorial/html-meta.php">HTML Meta</a>
    <a href="/html-tutorial/html-scripts.php">HTML Scripts</a>
    <a href="/html-tutorial/html-entities.php">HTML Entities</a>
    <a href="/html-tutorial/html-url.php">HTML URL</a>
    <a href="/html-tutorial/html-url-encode.php">HTML URL Encode</a>
    <a href="/html-tutorial/html-validation.php">HTML Validation</a>
</div>
<div class="segment"><span>HTML5</span> FEATURES</div>
<div class="chapters">
	<a href="/html-tutorial/html5-new-input-types.php">HTML5 New Input Types</a>
    <a href="/html-tutorial/html5-canvas.php">HTML5 Canvas</a>
    <a href="/html-tutorial/html5-svg.php">HTML5 SVG</a>
    <a href="/html-tutorial/html5-audio.php">HTML5 Audio</a>
    <a href="/html-tutorial/html5-video.php">HTML5 Video</a>
    <a href="/html-tutorial/html5-web-storage.php">HTML5 Web Storage</a>
    <a href="/html-tutorial/html5-application-cache.php">HTML5 Application Cache</a>
    <a href="/html-tutorial/html5-web-workers.php">HTML5 Web Workers</a>
    <a href="/html-tutorial/html5-server-sent-events.php">HTML5 SSE</a>
    <a href="/html-tutorial/html5-geolocation.php">HTML5 Geolocation</a>
    <a href="/html-tutorial/html5-drag-and-drop.php">HTML5 Drag &amp; Drop</a>
</div>
<div class="segment"><span>HTML5</span> EXAMPLES</div>
<div class="chapters">
    <a href="/html-examples.php">HTML5 Practice Examples</a>
	<a href="/faq.php#html-css">HTML5 FAQ's Answers</a>
</div>
<div class="segment"><span>HTML5</span> REFERENCE</div>
<div class="chapters">
    <a href="/html-reference/html5-tags.php">HTML5 Tags/Elements</a>
	<a href="/html-reference/html5-global-attributes.php">HTML5 Global Attributes</a>
    <a href="/html-reference/html5-event-attributes.php">HTML5 Event Attributes</a>
    <a href="/html-reference/html-color-picker.php">HTML5 Color Picker</a>
    <a href="/html-reference/html-language-codes.php">HTML5 Language Codes</a>
    <a href="/html-reference/html-character-entities.php">HTML5 Character Entities</a>
    <a href="/html-reference/http-status-codes.php">HTTP Status Codes</a>
    <a href="/references.php" class="more">More References</a>
</div>        
                </div>
        <div class="centercolumn">
            <!--Text Content-->
            <div class="content">
                <div class="leaderboard">
                    
<div class="ad-label">Advertisements</div>
<div class="ad-container">
    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <!-- Responsive Leaderboard -->
    <ins class="adsbygoogle"
            style="display:inline-block;max-width:728px;width:100%;height:90px"
            data-ad-client="ca-pub-9107540490929984"
            data-ad-slot="4302666817"></ins>
    <script>
    (adsbygoogle = window.adsbygoogle || []).push({});
    </script>
</div>                </div>
                <!-- InstanceBeginEditable name="main_content" -->
            <a href="html-common-attributes.php" class="previous-page" title="Go to Previous Page"></a>
            <a href="html-character-entities.php" class="next-page" title="Go to Next Page"></a>
            <h1>HTML <code>Language</code> Codes</h1>
            <p class="summary">A language code is used to indicate the language of the content.</p>
	    	<h2>Description</h2>
            <p>The following table lists the two-letter ISO 639 language codes (sorted alphabetically by language) that can be used with the <code>lang</code> and <code>xml:lang</code> attributes to indicate the language contained inside the element in HTML and XHTML document. Language codes are case-insensitive.</p> 
          	<div class="shadow">
                <table class="data compact">
                    <tr>
                        <th style="width: 40%;">Language Family</th>
                        <th style="width: 40%;">Language</th>
                        <th style="width: 20%;">ISO Code</th>
                    </tr>
                    <tr>
                        <td>Northwest Caucasian</td>
                        <td>Abkhazian</td>
                        <td>ab</td>
                    </tr>
                    <tr>
                        <td>Afro-Asiatic</td>
                        <td>Afar</td>
                        <td>aa</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Afrikaans</td>
                        <td>af</td>
                    </tr>
                    <tr>
                        <td>ndo-European</td>
                        <td>Albanian</td>
                        <td>sq</td>
                    </tr>
                    <tr>
                        <td>Afro-Asiatic</td>
                        <td>Amharic</td>
                        <td>am</td>
                    </tr>
                    <tr>
                        <td>Afro-Asiatic</td>
                        <td>Arabic</td>
                        <td>ar</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Aragonese</td>
                        <td>an</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Armenian</td>
                        <td>hy</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Assamese</td>
                        <td>as</td>
                    </tr>
                    <tr>
                        <td>Aymaran</td>
                        <td>Aymara</td>
                        <td>ay</td>
                    </tr>
                    <tr>
                        <td>Turkic</td>
                        <td>Azerbaijani</td>
                        <td>az</td>
                    </tr>
                    <tr>
                        <td>Turkic</td>
                        <td>Bashkir</td>
                        <td>ba</td>
                    </tr>
                    <tr>
                        <td>Language isolate</td>
                        <td>Basque</td>
                        <td>eu</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Bengali (Bangla)</td>
                        <td>bn</td>
                    </tr>
                    <tr>
                        <td>Sino-Tibetan</td>
                        <td>Bhutani</td>
                        <td>dz</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Bihari</td>
                        <td>bh</td>
                    </tr>
                    <tr>
                        <td>Creole</td>
                        <td>Bislama</td>
                        <td>bi</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Breton</td>
                        <td>br</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Bulgarian</td>
                        <td>bg</td>
                    </tr>
                    <tr>
                        <td>Sino-Tibetan</td>
                        <td>Burmese</td>
                        <td>my</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Byelorussian (Belarusian)</td>
                        <td>be</td>
                    </tr>
                    <tr>
                        <td>Austro-Asiatic</td>
                        <td>Cambodian</td>
                        <td>km</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Catalan</td>
                        <td>ca</td>
                    </tr>
                    <tr>
                        <td>Sino-Tibetan</td>
                        <td>Chinese</td>
                        <td>zh</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Corsican</td>
                        <td>co</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Croatian</td>
                        <td>hr</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Czech</td>
                        <td>cs</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Danish</td>
                        <td>da</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Dutch</td>
                        <td>nl</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>English (American)</td>
                        <td>en</td>
                    </tr>
                    <tr>
                        <td>Constructed</td>
                        <td>Esperanto</td>
                        <td>eo</td>
                    </tr>
                    <tr>
                        <td>Uralic</td>
                        <td>Estonian</td>
                        <td>et</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Faeroese</td>
                        <td>fo</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Farsi</td>
                        <td>fa</td>
                    </tr>
                    <tr>
                        <td>Austronesian</td>
                        <td>Fiji</td>
                        <td>fj</td>
                    </tr>
                    <tr>
                        <td>Uralic</td>
                        <td>Finnish</td>
                        <td>fi</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>French</td>
                        <td>fr</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Frisian</td>
                        <td>fy</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Gaelic (Scottish)</td>
                        <td>gd</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Gaelic (Manx)</td>
                        <td>gv</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Galician</td>
                        <td>gl</td>
                    </tr>
                    <tr>
                        <td>South Caucasian</td>
                        <td>Georgian</td>
                        <td>ka</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>German</td>
                        <td>de</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Greek</td>
                        <td>el</td>
                    </tr>
                    <tr>
                        <td>Eskimo-Aleut</td>
                        <td>Kalaallisut (Greenlandic)</td>
                        <td>kl</td>
                    </tr>
                    <tr>
                        <td>Tupian</td>
                        <td>Guarani</td>
                        <td>gn</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Gujarati</td>
                        <td>gu</td>
                    </tr>
                    <tr>
                        <td>Creole</td>
                        <td>Haitian Creole</td>
                        <td>ht</td>
                    </tr>
                    <tr>
                        <td>Afro-Asiatic</td>
                        <td>Hausa</td>
                        <td>ha</td>
                    </tr>
                    <tr>
                        <td>Afro-Asiatic</td>
                        <td>Hebrew</td>
                        <td>he, iw</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Hindi</td>
                        <td>hi</td>
                    </tr>
                    <tr>
                        <td>Uralic</td>
                        <td>Hungarian</td>
                        <td>hu</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Icelandic</td>
                        <td>is</td>
                    </tr>
                    <tr>
                        <td>Constructed</td>
                        <td>Ido</td>
                        <td>io</td>
                    </tr>
                    <tr>
                        <td>Austronesian</td>
                        <td>Indonesian</td>
                        <td>id, in</td>
                    </tr>
                    <tr>
                        <td>Constructed</td>
                        <td>Interlingua</td>
                        <td>ia</td>
                    </tr>
                    <tr>
                        <td>Constructed</td>
                        <td>Interlingue</td>
                        <td>ie</td>
                    </tr>
                    <tr>
                        <td>Eskimo-Aleut</td>
                        <td>Inuktitut</td>
                        <td>iu</td>
                    </tr>
                    <tr>
                        <td>Eskimo-Aleut</td>
                        <td>Inupiak</td>
                        <td>ik</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Irish</td>
                        <td>ga</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Italian</td>
                        <td>it</td>
                    </tr>
                    <tr>
                        <td>Japonic</td>
                        <td>Japanese</td>
                        <td>ja</td>
                    </tr>
                    <tr>
                        <td>Austronesian</td>
                        <td>Javanese</td>
                        <td>jv</td>
                    </tr>
                    <tr>
                        <td>Dravidian</td>
                        <td>Kannada</td>
                        <td>kn</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Kashmiri</td>
                        <td>ks</td>
                    </tr>
                    <tr>
                        <td>Turkic</td>
                        <td>Kazakh</td>
                        <td>kk</td>
                    </tr>
                    <tr>
                        <td>Niger-Congo</td>
                        <td>Kinyarwanda (Ruanda)</td>
                        <td>rw</td>
                    </tr>
                    <tr>
                        <td>Turkic</td>
                        <td>Kirghiz</td>
                        <td>ky</td>
                    </tr>
                    <tr>
                        <td>Niger-Congo</td>
                        <td>Kirundi (Rundi)</td>
                        <td>rn</td>
                    </tr>
                    <tr>
                        <td>Language isolate</td>
                        <td>Korean</td>
                        <td>ko</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Kurdish</td>
                        <td>ku</td>
                    </tr>
                    <tr>
                        <td>Tai-Kadai</td>
                        <td>Laothian</td>
                        <td>lo</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Latin</td>
                        <td>la</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Latvian (Lettish)</td>
                        <td>lv</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Limburgish ( Limburger)</td>
                        <td>li</td>
                    </tr>
                    <tr>
                        <td>Niger-Congo</td>
                        <td>Lingala</td>
                        <td>ln</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Lithuanian</td>
                        <td>lt</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Macedonian</td>
                        <td>mk</td>
                    </tr>
                    <tr>
                        <td>Austronesian</td>
                        <td>Malagasy</td>
                        <td>mg</td>
                    </tr>
                    <tr>
                        <td>Austronesian</td>
                        <td>Malay</td>
                        <td>ms</td>
                    </tr>
                    <tr>
                        <td>Austronesian</td>
                        <td>Malayalam</td>
                        <td>ml</td>
                    </tr>
                    <tr>
                        <td>Afro-Asiatic</td>
                        <td>Maltese</td>
                        <td>mt</td>
                    </tr>
                    <tr>
                        <td>Austronesian</td>
                        <td>Maori</td>
                        <td>mi</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Marathi</td>
                        <td>mr</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Moldavian</td>
                        <td>mo</td>
                    </tr>
                    <tr>
                        <td>Mongolic</td>
                        <td>Mongolian</td>
                        <td>mn</td>
                    </tr>
                    <tr>
                        <td>Austronesian</td>
                        <td>Nauru</td>
                        <td>na</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Nepali</td>
                        <td>ne</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Norwegian</td>
                        <td>no</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Occitan</td>
                        <td>oc</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Oriya</td>
                        <td>or</td>
                    </tr>
                    <tr>
                        <td>Afro-Asiatic</td>
                        <td>Oromo (Afan, Galla)</td>
                        <td>om</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Pashto (Pushto)</td>
                        <td>ps</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Polish</td>
                        <td>pl</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Portuguese</td>
                        <td>pt</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Punjabi</td>
                        <td>pa</td>
                    </tr>
                    <tr>
                        <td>Quechuan</td>
                        <td>Quechua</td>
                        <td>qu</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Rhaeto-Romance</td>
                        <td>rm</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Romanian</td>
                        <td>ro</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Russian</td>
                        <td>ru</td>
                    </tr>
                    <tr>
                        <td>Austronesian</td>
                        <td>Samoan</td>
                        <td>sm</td>
                    </tr>
                    <tr>
                        <td>Creole</td>
                        <td>Sango</td>
                        <td>sg</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Sanskrit</td>
                        <td>sa</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Serbian</td>
                        <td>sr</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Serbo-Croatian</td>
                        <td>sh</td>
                    </tr>
                    <tr>
                        <td>Niger-Congo</td>
                        <td>Sesotho</td>
                        <td>st</td>
                    </tr>
                    <tr>
                        <td>Niger-Congo</td>
                        <td>Setswana</td>
                        <td>tn</td>
                    </tr>
                    <tr>
                        <td>Niger-Congo</td>
                        <td>Shona</td>
                        <td>sn</td>
                    </tr>
                    <tr>
                        <td>Sino-Tibetan</td>
                        <td>Sichuan Yi</td>
                        <td>ii</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Sindhi</td>
                        <td>sd</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Sinhalese</td>
                        <td>si</td>
                    </tr>
                    <tr>
                        <td>Niger-Congo</td>
                        <td>Siswati</td>
                        <td>ss</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Slovak</td>
                        <td>sk</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Slovenian</td>
                        <td>sl</td>
                    </tr>
                    <tr>
                        <td>Afro-Asiatic</td>
                        <td>Somali</td>
                        <td>so</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Spanish</td>
                        <td>es</td>
                    </tr>
                    <tr>
                        <td>Austronesian</td>
                        <td>Sundanese</td>
                        <td>su</td>
                    </tr>
                    <tr>
                        <td>Niger-Congo</td>
                        <td>Swahili (Kiswahili)</td>
                        <td>sw</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Swedish</td>
                        <td>sv</td>
                    </tr>
                    <tr>
                        <td>Austronesian</td>
                        <td>Tagalog</td>
                        <td>tl</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Tajik</td>
                        <td>tg</td>
                    </tr>
                    <tr>
                        <td>Dravidian</td>
                        <td>Tamil</td>
                        <td>ta</td>
                    </tr>
                    <tr>
                        <td>Turkic</td>
                        <td>Tatar</td>
                        <td>tt</td>
                    </tr>
                    <tr>
                        <td>Dravidian</td>
                        <td>Telugu</td>
                        <td>te</td>
                    </tr>
                    <tr>
                        <td>Tai-Kadai</td>
                        <td>Thai</td>
                        <td>th</td>
                    </tr>
                    <tr>
                        <td>Sino-Tibetan</td>
                        <td>Tibetan</td>
                        <td>bo</td>
                    </tr>
                    <tr>
                        <td>Afro-Asiatic</td>
                        <td>Tigrinya</td>
                        <td>ti</td>
                    </tr>
                    <tr>
                        <td>Austronesian</td>
                        <td>Tonga</td>
                        <td>to</td>
                    </tr>
                    <tr>
                        <td>Niger-Congo</td>
                        <td>Tsonga</td>
                        <td>ts</td>
                    </tr>
                    <tr>
                        <td>Turkic</td>
                        <td>Turkish</td>
                        <td>tr</td>
                    </tr>
                    <tr>
                        <td>Turkic</td>
                        <td>Turkmen</td>
                        <td>tk</td>
                    </tr>
                    <tr>
                        <td>Niger-Congo</td>
                        <td>Twi</td>
                        <td>tw</td>
                    </tr>
                    <tr>
                        <td>Turkic</td>
                        <td>Uighur</td>
                        <td>ug</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Ukrainian</td>
                        <td>uk</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Urdu</td>
                        <td>ur</td>
                    </tr>
                    <tr>
                        <td>Turkic</td>
                        <td>Uzbek</td>
                        <td>uz</td>
                    </tr>
                    <tr>
                        <td>Austro-Asiatic</td>
                        <td>Vietnamese</td>
                        <td>vi</td>
                    </tr>
                    <tr>
                        <td>Constructed</td>
                        <td>Volap&#252;k</td>
                        <td>vo</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Wallon</td>
                        <td>wa</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Welsh</td>
                        <td>cy</td>
                    </tr>
                    <tr>
                        <td>Niger-Congo</td>
                        <td>Wolof</td>
                        <td>wo</td>
                    </tr>
                    <tr>
                        <td>Niger-Congo</td>
                        <td>Xhosa</td>
                        <td>xh</td>
                    </tr>
                    <tr>
                        <td>Indo-European</td>
                        <td>Yiddish</td>
                        <td>yi, ji</td>
                    </tr>
                    <tr>
                        <td>Niger-Congo</td>
                        <td>Yoruba</td>
                        <td>yo</td>
                    </tr>
                    <tr>
                        <td>Niger-Congo</td>
                        <td>Zulu</td>
                        <td>zu</td>
                    </tr>
                </table>
            </div>
          	<!--Bottom Navigation-->
            <div class="bottom-link clearfix">
                <a href="html-common-attributes.php" class="previous-page-bottom">Previous Page</a>
                <a href="html-character-entities.php" class="next-page-bottom">Next Page</a>
            </div>
            <!--End:Bottom Navigation--> 
          	<!-- InstanceEndEditable -->
                <!--Bottom Ads-->
                <div class="bottom-ad clearfix">
                    <div class="ad-label">Advertisements</div>

<!--Rectangle Left-->
<div class="rectangle-left fl">
    
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Large Rectangle Left -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="8162953958"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
<!--End:Rectangle Left-->


<!--Rectangle Right-->
<div class="rectangle-right fr">

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Large Rectangle Right -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="3324015654"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
<!--End:Rectangle Right-->                </div>
                <!--End:Bottom Ads-->
            </div>
            <!--End:Text Content-->
            <!--Feedback Form-->
			<div class="snippets">
	<a href="/snippets/gallery.php" target="_blank">
    	<img src="/lib/images/bootstrap-code-snippets.png" alt="Bootstrap UI Design Templates" />
	</a>
</div>

<div class="report-error" id="feedback">
    <div class="contact-form clearfix">
        <div class="close"><span class="icon-close"></span></div>
        <form id="feedback-form">
            <h3>Your Feedback:</h3>
            <div class="clearfix">
                <div class="name fl"><label>Your Name (optional) <input type="text" name="user-name" id="user-name" /></label></div>
                <div class="email fr"><label>Your E-mail (optional) <input type="text" name="user-email" id="user-email" /></label></div>
            </div>
            <div><label>Page address <input type="text" name="page-url" id="page-url" class="disabled" disabled="disabled" /></label></div>
            <div><label>Description <textarea name="description" id="description" rows="6"></textarea></label></div>
            <p id="feedback-error">We would love to hear from you, please drop us a line.</p>
            <div><button type="button" class="action-btn" onclick="sendFeedback()"><span class="icon-send"></span> Send</button></div>
        </form>
        <div id="response"></div>
    </div>           
</div>            <!--End:Feedback Form-->
        </div>        
        <div class="sidebar">
            <div class="ad-label">Advertisements</div>

<div class="skyscraper primary">

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Premium Skyscraper -->
<ins class="adsbygoogle"
     style="display:inline-block;width:160px;height:600px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="4376141825"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>

<div class="skyscraper">
    
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Bottom Skyscraper -->
<ins class="adsbygoogle"
     style="display:inline-block;width:160px;height:600px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="3387984471"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>        </div>
    </div>
    <!--Footer-->
	<!--Footer-->
<div class="footer">
    <div class="appeal">
        <div class="wrapper">
            <p>Is this website helpful to you? Please give us a
            <a href="/like.php" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=250,width=600,top=150, left='+((screen.width/2)-300));return false;">like</a>,
            or share your <a href="#feedback" class="feedback">feedback</a><em> to help us improve</em>.
            Connect with us on <a href="https://www.facebook.com/tutorialrepublic" target="_blank">Facebook</a> and <a href="https://twitter.com/tutrepublic" target="_blank">Twitter</a> for the latest updates.</p>               
        </div>
    </div>
    <div class="footer-inner">
        <div class="wrapper clearfix">                
            <div class="link-box">
                <h4>About Us</h4>
                <div class="clearfix">
                    <a href="/about-us.php">Our Story</a>                    
                    <a href="/terms-of-use.php">Terms of Use</a>
                    <a href="/privacy-policy.php">Privacy Policy</a>                    
                </div>
            </div>
            <div class="link-box">
                <h4>Contact</h4>
                <div class="clearfix">
                    <a href="/contact-us.php">Contact Us</a>                    
                    <a href="#feedback" class="feedback">Report Error</a>
                    <a href="/advertise-with-us.php">Advertise</a>                    
                </div>
            </div>
            <div class="tool-box">
                <h4>Interactive Tools</h4>
                <div class="tools-list clearfix" id="tools">
                    <a href="/faq/what-is-the-maximum-length-of-title-and-meta-description-tag.php">Title &amp; Meta Length Calculator</a>                           
                    <a href="/html-formatter.php" target="_blank">HTML Formatter</a>                        
                    <a href="/twitter-bootstrap-button-generator.php" target="_blank">Bootstrap Button Generator</a>
                    <a href="/html-reference/html-color-picker.php">HTML Color Picker</a>
                    <a href="/codelab.php?topic=sql&amp;file=select-all" target="_blank">SQL Playground</a>
                    <a href="/codelab.php?topic=html&amp;file=hello-world" target="_blank">HTML Editor</a>                    
                </div>
            </div>
            <div class="footer-logo">
                <img src="/lib/images/logo.svg" alt="TutorialRepublic" />
            </div>
        </div>
    </div>           
        <div class="bottom-strip">
        <div class="wrapper">
            <div class="notice">Copyright &copy; 2019 Tutorial Republic. All Rights Reserved.</div>
            <div class="social-media">
                <em>Share This:</em>
                <a href="https://facebook.com/sharer.php?u=https://www.tutorialrepublic.com%2Fhtml-reference%2Fhtml-language-codes.php" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" title="Facebook"><i class="icon-facebook"></i></a>
                <a href="#" id="tweet-btn" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" title="Twitter"><i class="icon-twitter"></i></a>
                <a href="#" id="email-btn" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" rel="noreferrer" title="Gmail"><i class="icon-mail"></i></a>
            </div>
        </div>            
    </div>
    <script>
        var title = document.title.replace('- Tutorial Republic', '');
        document.getElementById('tweet-btn').href = 'https://twitter.com/share?text=' + title + '- &url=https://www.tutorialrepublic.com%2Fhtml-reference%2Fhtml-language-codes.php';
        document.getElementById('email-btn').href = 'https://mail.google.com/mail/?view=cm&fs=1&su=' + title + '&body=https://www.tutorialrepublic.com%2Fhtml-reference%2Fhtml-language-codes.php';
    </script>
</div>
<!--End:Footer-->
    
<div class="backdrop mobile-only"></div>

<!-- TutorialRepublic base script -->
<script>
// Adding CSS files
[
	'/lib/styles/extended-3.7.css',
	'/lib/icomoon/style.css'
].forEach(function(href) {
	var link = document.createElement('link');
	link.rel = 'stylesheet';
	link.href = href;
	(document.getElementsByTagName('head')[0]).appendChild(link);
});

// Adding JS files
[
	'https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js',
	'/lib/js/prism.js',
	'/lib/js/default-2.9.min.js'
].forEach(function(src) {
	var script = document.createElement('script');
	script.async = false; // important
	script.src = src;
	(document.getElementsByTagName('body')[0]).appendChild(script);
});
</script>


    <!--End:Footer-->
</body>
<!-- InstanceEnd --></html>