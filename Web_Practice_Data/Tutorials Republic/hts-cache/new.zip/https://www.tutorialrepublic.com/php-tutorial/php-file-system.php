<!DOCTYPE html>
<html lang="en"><!-- InstanceBegin template="/Templates/php.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
	<!-- InstanceBeginEditable name="doctitle" -->
    <title>Understanding PHP File System Functions - Tutorial Republic</title>
	<meta name="description" content="In this tutorial you will learn how to create, access (or read) and manipulate files dynamically using the PHP's file system functions." />
    <!-- InstanceEndEditable -->
    	<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta property="fb:admins" content="100001054961582" />
<meta property="fb:app_id" content="1404574483159557" />
<meta property="og:image" content="/lib/images/signature.png" />
<link type="image/x-icon" href="/favicon.ico" rel="shortcut icon" />
<style>
html,body,h1,h2,h3,h4,h5,h6,p,blockquote,pre,img{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}
html,body{min-height:100%}
p{margin:0 0 12px}
ol,ul{margin:0 0 12px}
a,a:active,a:visited{outline:none;color:#1db79f;text-decoration:none}
a img{border:none;outline:none}
a code{color:inherit;background:none}
p code,table td:last-child code,.content ul li code,code.mark{padding:2px 4px;color:#333;background-color:#f1f1f1;border-radius:4px}
table{border-collapse:collapse;border-spacing:0}
table td{vertical-align:top}
body{min-width:1300px;color:#414141;background:#fafafa;font-family:"Segoe UI","Helvetica Neue",Arial,sans-serif;font-size:17px;line-height:1.7}
input,select,textarea,button,div,span,a{box-sizing:border-box}
h1,h2,h3,h4{color:#262626;font-weight:500;margin:20px 0 10px;line-height:1.5;font-weight:600}
h1{font-size:34px;margin-top:17px}
h2{font-size:28px}
h3{font-size:22px}
.space{margin-bottom:25px!important}
.break{margin-bottom:15px!important}
.text-center{text-align:center!important}
.scroll{height:195px;overflow-y:scroll}
.scroll.large{height:245px}
.scroll.xlarge{height:290px}
.scroll.xxlarge{height:340px}
sup{font-size:13px}
.leaderboard{padding-top:8px;position:relative}
.ad-container{height:90px;overflow:hidden}
.intro-image img{display:block;padding:10px 0 25px;max-width:100%}
.clearfix::after{content:".";display:block;height:0;clear:both;visibility:hidden}
code,.code,.syntax,.green-box,.sky-box,.gray-box,.pink-box,.red-box,.at-rule,.codebox pre,.console-output{font-size:16px;font-family:Consolas,Monaco,Courier,monospace}
.console-output{margin:15px 0}
hr{border:none;border-bottom:1px solid #e7e9ed;height:1px;margin:30px 0}
.summary,.topic{border:1px solid #eaeaea;border-width:1px 0;margin:20px 0;padding:10px 0;color:#8e9aa6;line-height:1.5}
h2.section-title span{display:inline-block;border-bottom:4px solid #c9d7e0;padding:0 50px 12px 0}
.wrapper{width:1300px;padding:0 15px;margin:0 auto}
.header{background:#23384e;padding:16px 0}
input.search{background:#fff;border:0 none;color:#807E7E;float:left;height:38px;line-height:26px;font-size:14px;margin:0 0 0 12px;outline:medium none;padding:6px 14px;width:500px;border-radius:2px;box-shadow:0 0 1px rgba(0,0,0,0.6);font-family:inherit}
.search-btn{color:rgba(0,0,0,.6);background:#ebebeb;border:none;outline:none;cursor:pointer;float:left;height:38px;line-height:46px;width:44px;display:block;margin-left:-2px;border-radius:0 2px 2px 0;box-shadow:0 0 1px rgba(0,0,0,0.7)}
.logo{width:304px}
.logo img{height:44px;margin:-3px 0;display:block}
.site-search{float:left;margin-left:100px}
.menu{background-color:#f5f5f5;box-shadow:0 1px 1px rgba(0,0,0,.15);position:relative;z-index:9}
.menu a{color:#666;display:inline-block;padding:0 10px;text-decoration:none;font-size:14px;font-weight:600;height:48px;line-height:48px}
.menu a:first-child{margin-left:-10px}
.menu a.tool-link{float:right;display:inline-block;border-radius:30px;line-height:28px;position:relative;height:auto;top:9px;padding:0 12px;color:#1ebba3;border:1px double #1ebba3}
.fl,.logo{float:left}
.leftcolumn{width:240px;float:left;font-size:16px;color:#4f4f4f}
.centercolumn{width:850px;float:left}
.content{background:#fff;padding:20px 40px;border:1px solid #dedede;border-top:none;border-radius:1px}
.sidebar{width:160px;float:left;padding-top:28px;margin-left:20px;position:relative}
.leftcolumn .segment{margin:16px 0 12px;position:relative;font-size:18px;font-weight:600;line-height:normal}
.leftcolumn a{color:#4f4f4f;font-size:16px;line-height:26px;display:block;border-bottom:1px solid transparent}
.leftcolumn ul{list-style:none;padding:0}
.segment,.chapters,.chapters a{float:left;clear:both}
h1 code,h2 code,h3 code{font:inherit}
.color-box{margin:15px 0;padding-left:20px}
.note-box,.warning-box,.tip-box{padding:8px 8px 3px 26px}
.info-tab{float:left;margin-left:-23px}
.content ul li{margin-top:7px}
.extra{padding-top:5px}
.green-box,.sky-box,.gray-box,.red-box,.pink-box{color:#000;margin-top:15px;padding:10px;background-color:#f6f8fa;border:1px solid #d7e2ec}
.example{background:#f4f5f6;padding:3px;margin:15px 0}
.codebox{background:#fff;border:1px solid #ddd}
.codebox-title{height:41px;padding-left:12px;border-bottom:1px solid #ddd;background:#f5f5f5}
.codebox-title h4{margin:0;font-size:18px;line-height:40px;float:left;display:inline;font-weight:500}
a.try-btn,a.download-btn{width:140px;height:40px;color:#333;font-size:15px;line-height:41px;font-weight:600;text-align:center;text-decoration:none;float:right;display:block;border-left:1px solid #ddd;background:rgba(27,31,35,0.08);box-sizing:border-box;font-family:Arial,sans-serif}
a.try-btn span{font-size:18px;line-height:normal}
.hide,.code-style,.box-size,.bottom-link,.footer,.code-style,.snippets,.report-error,.badge,.social,.ad-label,.mobile-only{display:none}
.skyscraper{width:160px;height:600px;overflow:hidden;margin-bottom:20px;background:#ebecf0}
.bottom-ad{margin-top:46px;padding:24px;position:relative;background:url(/lib/images/smooth-line.png) no-repeat center #f9f9f9}
.rectangle-left,.rectangle-right{min-width:336px;min-height:280px;overflow:hidden}
.fr,a.previous-page,a.next-page,.rectangle-right,.topic-nav{float:right}
a.previous-page,a.next-page{width:32px;height:32px;line-height:30px}
.shadow{background:#F7F8F9;padding:3px;margin:10px 0}
.syntax{color:#2f4959;padding:13px 18px;background:#F9F9FA;border:1px solid #ddd;font-size:15px}
code[class*="language-"],pre[class*="language-"]{color:#000;background:none;font-family:Consolas,Monaco,'Andale Mono','Ubuntu Mono',monospace;text-align:left;white-space:pre;word-break:normal;word-wrap:normal;line-height:1.5;tab-size:4;hyphens:none}
pre[class*="language-"]{position:relative;margin:.5em 0;overflow:visible;padding:0}
pre[class*="language-"]>code{position:relative;border-left:10px solid #358ccb;box-shadow:-1px 0 0 0 #358ccb,0 0 0 1px #dfdfdf;background-color:#fdfdfd;background-image:linear-gradient(transparent 50%,rgba(69,142,209,0.04) 50%);background-size:3em 3em;background-origin:content-box;background-attachment:local}
code[class*="language"]{max-height:inherit;height:inherit;padding:0 1em;display:block;overflow:auto}
:not(pre) > code[class*="language-"]{position:relative;padding:.2em;border-radius:.3em;color:#c92c2c;border:1px solid rgba(0,0,0,0.1);display:inline;white-space:normal}
pre[class*="language-"].line-numbers{padding-left:0}
pre[class*="language-"].line-numbers code{padding-left:3.8em}
pre[class*="language-"].line-numbers .line-numbers-rows{left:0}
pre[class*="language-"][data-line]{padding-top:0;padding-bottom:0;padding-left:0}
pre[data-line] code{position:relative;padding-left:4em}
pre .line-highlight{margin-top:0}
pre.line-numbers{position:relative;padding-left:3.8em;counter-reset:linenumber;white-space:pre-wrap!important}
pre.line-numbers > code{position:relative;white-space:inherit}
.line-numbers-rows,.codebox pre.inactive{display:none}
.codebox pre.syntax-highlighter{margin:0;padding:0;overflow:auto}
pre.line-numbers .line-numbers-rows{border-right:3px solid #6CE26C}
.codebox pre.syntax-highlighter > code{box-shadow:none!important;padding-left:3.8em;background-image:linear-gradient(transparent 50%,#F8F8F8 50%);font-family:Consolas,Monaco,'Andale Mono','Ubuntu Mono',monospace!important;font-size:16px;line-height:1.5}
.codebox pre.syntax-highlighter,.codebox pre.syntax-highlighter code{border:none;width:100%;box-sizing:border-box}
pre.line-numbers code,pre.line-numbers .line-numbers-rows{padding-top:2px;padding-bottom:2px}
.preview-box{padding:15px;text-align:center;cursor:pointer;overflow:hidden;background:#FFF;border:1px solid #e6e6e6}
.preview-box a,.preview-box img{display:block;margin:0 auto}
.download-box{text-align:center;padding:20px 0;margin:20px 0 10px}
.output-box{border-color:#d4d4d4;border-style:solid;border-width:1px 0;padding:5px 15px;overflow:hidden;background:#fff;margin:10px 0}
.demo-box{margin-top:15px}
.subhead{border-bottom:3px solid #DCE3EB;margin-bottom:15px;padding-bottom:10px}
table.data,table.description{width:100%;font-size:92%}
table.data th{color:#000;padding:8px 7px;text-align:left;font-size:15px;background:#F8F8F8}
table.data td{color:#484848;padding:5px 7px;background:#fff}
table.data th,table.data td{vertical-align:top;border:1px solid #DCE3EB}
table.data tr.section th,table.data td.section{font-size:15px;background:#f0f4f7}
table.no-wrap tr td:first-child{white-space:nowrap}
@media screen and (max-width: 1280px) {
body{min-width:1260px}
.wrapper{width:1260px}
.leftcolumn{width:230px}
.centercolumn{width:820px}
}
@media screen and (max-width: 800px) {
body{min-width:100%;max-width:100%;padding-top:46px}
.wrapper{width:100%;padding:0}
.header{height:46px;padding:5px 0;position:fixed;top:0;left:0;right:0;width:100%;z-index:99}
.logo{width:auto;display:block;padding:6px 0 0 60px;position:absolute;left:0;z-index:100}
.logo img{height:30px}
.menu{width:100%;padding-left:12px;padding-right:12px;overflow-x:auto;white-space:nowrap}
.centercolumn{width:100%;float:none}
.content{padding:10px;border-width:0 0 1px 0}
.content img{max-width:100%;height:auto}
.content pre{max-width:100%;overflow:hidden}
.skyscraper{display:inline-block}
.shadow,.example,.console-output{max-width:100%;overflow-x:auto}
.codebox-title{position:relative}
.codebox.multi-style-mode pre{padding-top:7px;margin-top:36px;border-top:1px solid #ddd}
.bottom-ad{height:auto;background:none;padding:30px 0 0;margin:40px 0 0;text-align:center;position:relative}
.rectangle-left,.rectangle-right{float:none;display:inline-block;margin:10px auto;background:#EDEEF2}
.leftcolumn,.footer,.social,.site-search,.code-style,.menu a.tool-link,.backdrop{display:none}
.summary,.topic{padding:5px 0;margin:10px 0}
.leftcolumn,.centercolumn,.sidebar{float:none}
.header,.menu,.centercolumn,.footer,.appeal-text{width:100%}
a.try-btn,a.download-btn{width:130px}
.native-unit{margin-bottom:30px}
.sidebar{margin: 25px auto 0}
.overview{padding-right:0}
.scroll-pane{overflow-x:auto}
table.data{min-width:480px}
table.data pre{display:inline;white-space:normal}
table tr th,table tr td{width:auto!important}
.preview-box{padding:6px}
.leaderboard{margin:20px 0}
h1{font-size:30px}
h2{font-size:24px}
h3{font-size:20px}
.codebox pre.syntax-highlighter{overflow-x:auto}
.codebox pre.syntax-highlighter > code{width:614px;height:auto;overflow-x:hidden}
}
@media screen and (min-width: 801px) {
.site-search,.leftcolumn,.social{display:block!important}
.backdrop{display:none!important}
.hide-scroll{overflow-x:hidden!important}
}</style>    
    <!-- InstanceBeginEditable name="head" -->
    <!-- InstanceEndEditable -->
    
    <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-40117907-1', 'auto');
  ga('send', 'pageview');
</script></head>
<body>
    <!--Header-->
    
<div class="header">
    <div class="wrapper clearfix">
        <button type="button" class="open-menu mobile-only"><i class="icon-menu"></i></button>
        <div class="logo">
            <a href="https://www.tutorialrepublic.com/"><img src="/lib/images/logo.svg" alt="TutorialRepublic" /></a>
        </div>
        <div class="site-search">
            <form action="https://www.google.com/search" method="get" target="_blank" class="clearfix">
                <input type="hidden" value="www.tutorialrepublic.com" name="sitesearch" />
                <input type="text" name="q" placeholder="Search topics, tutorials, questions and answers..." id="searchInput" class="search" />
                <button type="submit" class="search-btn"><span class="icon-search"></span></button>
            </form>
        </div>
        <div class="social">                
            <a href="https://www.facebook.com/tutorialrepublic" target="_blank" title="Join us on Facebook"><i class="icon-facebook"></i></a>
            <a href="https://twitter.com/tutrepublic" target="_blank" title="Follow us on Twitter"><i class="icon-twitter"></i></a>
            <a href="/contact-us.php" target="_blank" title="Send us an Email"><i class="icon-mail"></i></a>
        </div>
        <button type="button" class="open-search mobile-only">
            <i class="icon-search"></i>
        </button>
    </div>    
</div>
<div class="menu">
    <div class="wrapper">
        <a href="//www.tutorialrepublic.com" title="Home Page">HOME</a>
        <a href="/html-tutorial/" title="HTML Tutorial">HTML5</a>            
        <a href="/css-tutorial/" title="CSS Tutorial">CSS3</a>
        <a href="/javascript-tutorial/" title="JavaScript Tutorial">JAVASCRIPT</a>
        <a href="/jquery-tutorial/" title="jQuery Tutorial">JQUERY</a>
        <a href="/twitter-bootstrap-tutorial/" title="Bootstrap Tutorial">BOOTSTRAP4</a>
        <a href="/php-tutorial/" title="PHP Tutorial">PHP7</a> 
        <a href="/sql-tutorial/" title="SQL Tutorial">SQL</a>
        <a href="/references.php" title="Web References">REFERENCES</a>
        <a href="/practice-examples.php" title="Practice Examples and Demos">EXAMPLES</a>
        <a href="/faq.php" title="Frequently Asked Questions and Answers">FAQ</a>
        <a href="/snippets/gallery.php" title="Bootstrap Code Snippets" target="_blank">SNIPPETS</a>
        <a href="/codelab.php" class="tool-link" target="_blank">Online HTML Editor</a>
    </div>        
</div>    <!--End:Header-->
    <div class="wrapper clearfix">
        <div class="leftcolumn" id="myNav">
		
        <div class="segment"><span>PHP</span> BASIC</div>
<div class="chapters">
    <a href="/php-tutorial/">PHP Introduction</a>
    <a href="/php-tutorial/php-get-started.php">PHP Getting Started</a>
    <a href="/php-tutorial/php-syntax.php">PHP Syntax</a>
    <a href="/php-tutorial/php-variables.php">PHP Variables</a>
	<a href="/php-tutorial/php-constants.php">PHP Constants</a>
    <a href="/php-tutorial/php-echo-and-print-statements.php">PHP Echo and Print</a>
	<a href="/php-tutorial/php-data-types.php">PHP Data Types</a>
    <a href="/php-tutorial/php-strings.php">PHP Strings</a>
    <a href="/php-tutorial/php-operators.php">PHP Operators</a>
    <a href="/php-tutorial/php-if-else-statements.php">PHP If&hellip;Else</a>
    <a href="/php-tutorial/php-switch-case-statements.php">PHP Switch&hellip;Case</a>
    <a href="/php-tutorial/php-arrays.php">PHP Arrays</a>
    <a href="/php-tutorial/php-sorting-arrays.php">PHP Sorting Arrays</a>    
    <a href="/php-tutorial/php-loops.php">PHP Loops</a>
    <a href="/php-tutorial/php-functions.php">PHP Functions</a>
	<a href="/php-tutorial/php-math-operations.php">PHP Math Operations</a>
    <a href="/php-tutorial/php-get-and-post.php">PHP GET and POST</a>
</div>
<div class="segment"><span>PHP</span> ADVANCED</div>
<div class="chapters">
    <a href="/php-tutorial/php-date-and-time.php">PHP Date and Time</a>
    <a href="/php-tutorial/php-include-files.php">PHP Include Files</a>
    <a href="/php-tutorial/php-file-system.php">PHP File system</a>
	<a href="/php-tutorial/php-parsing-directories.php">PHP Parsing Directories</a>
    <a href="/php-tutorial/php-file-upload.php">PHP File Upload</a>
	<a href="/php-tutorial/php-file-download.php">PHP File Download</a>
    <a href="/php-tutorial/php-cookies.php">PHP Cookies</a> 
    <a href="/php-tutorial/php-sessions.php">PHP Sessions</a>       
    <a href="/php-tutorial/php-send-email.php">PHP Send Email</a>
    <a href="/php-tutorial/php-form-handling.php">PHP Form Handling</a>
    <a href="/php-tutorial/php-form-validation.php">PHP Form Validation</a>
	<a href="/php-tutorial/php-filters.php">PHP Filters</a>
    <a href="/php-tutorial/php-error-handling.php">PHP Error Handling</a>
	<a href="/php-tutorial/php-classes-and-objects.php">PHP Classes and Objects</a>
	<a href="/php-tutorial/php-magic-constants.php">PHP Magic Constants</a>
	<a href="/php-tutorial/php-json-parsing.php">PHP JSON Parsing</a>
	<a href="/php-tutorial/php-regular-expressions.php">PHP Regular Expressions</a>
	<a href="/php-tutorial/php-exception-handling.php">PHP Exception Handling</a>
</div>
<div class="segment"><span>PHP</span> &amp; MySQL DATABASE</div>
<div class="chapters">
    <a href="/php-tutorial/php-mysql-introduction.php">PHP MySQL Introduction</a>
    <a href="/php-tutorial/php-mysql-connect.php">PHP MySQL Connect</a>
    <a href="/php-tutorial/php-mysql-create-database.php">PHP MySQL Create Database</a>
	<a href="/php-tutorial/php-mysql-create-table.php">PHP MySQL Create Table</a>
    <a href="/php-tutorial/php-mysql-insert-query.php">PHP MySQL Insert</a>	
	<a href="/php-tutorial/php-mysql-prepared-statements.php">PHP MySQL Prepared</a>
	<a href="/php-tutorial/php-mysql-last-inserted-id.php">PHP MySQL Last Inserted ID</a>
    <a href="/php-tutorial/php-mysql-select-query.php">PHP MySQL Select</a>
    <a href="/php-tutorial/php-mysql-where-clause.php">PHP MySQL Where</a>
	<a href="/php-tutorial/php-mysql-limit-clause.php">PHP MySQL Limit</a>        
    <a href="/php-tutorial/php-mysql-order-by-clause.php">PHP MySQL Order By</a>
    <a href="/php-tutorial/php-mysql-update-query.php">PHP MySQL Update</a>
    <a href="/php-tutorial/php-mysql-delete-query.php">PHP MySQL Delete</a>
	<a href="/php-tutorial/php-mysql-crud-application.php">PHP&thinsp;MySQL&thinsp;CRUD Application</a>
	<a href="/php-tutorial/php-mysql-ajax-live-search.php">PHP MySQL Ajax Search</a>
	<a href="/php-tutorial/php-mysql-login-system.php">PHP MySQL Login System</a>
</div>
<div class="segment"><span>PHP</span> EXAMPLES</div>
<div class="chapters">
    <a href="/php-examples.php">PHP Practice Examples</a>
	<a href="/faq.php#php-mysql">PHP FAQ's Answers</a>
</div>
<div class="segment"><span>PHP</span> REFERENCE</div>
<div class="chapters">
    <a href="/php-reference/php-string-functions.php">PHP String Functions</a>
    <a href="/php-reference/php-array-functions.php">PHP Array Functions</a>
    <a href="/php-reference/php-file-system-functions.php">PHP File System Functions</a>
    <a href="/php-reference/php-date-and-time-functions.php">PHP Date/Time Functions</a>
    <a href="/php-reference/php-calendar-functions.php">PHP Calendar Functions</a>
    <a href="/php-reference/php-mysqli-functions.php">PHP MySQLi Functions</a>
    <a href="/php-reference/php-filters.php">PHP Filters</a>
    <a href="/php-reference/php-error-levels.php">PHP Error Levels</a>
</div>        
                </div>
        <div class="centercolumn">
            <!--Text Content-->
            <div class="content">
                <div class="leaderboard">
                    
<div class="ad-label">Advertisements</div>
<div class="ad-container">
    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <!-- Responsive Leaderboard -->
    <ins class="adsbygoogle"
            style="display:inline-block;max-width:728px;width:100%;height:90px"
            data-ad-client="ca-pub-9107540490929984"
            data-ad-slot="4302666817"></ins>
    <script>
    (adsbygoogle = window.adsbygoogle || []).push({});
    </script>
</div>                </div>
                <!-- InstanceBeginEditable name="main_content" -->
                <a href="php-include-files.php" class="previous-page" title="Go to Previous Page"></a>
                <a href="php-parsing-directories.php" class="next-page" title="Go to Next Page"></a>
                <h1>PHP <span>File System</span></h1>
                <p class="summary">In this tutorial you will learn how to create, access (or read) and manipulate files dynamically using the PHP's file system functions.</p>
                <h2>Working with Files in PHP</h2>
                <p class="space">Since PHP is a server side programming language, it allows you to work with files and directories stored on the web server. In this tutorial you will learn how to create, access, and manipulate files on your web server using the PHP file system functions.</p>
                <h2>Opening a File with PHP <code>fopen()</code> Function</h2>
                <p>To work with a file you first need to open the file. The PHP <code>fopen()</code> function is used to open a file. The basic syntax of this function can be given with:</p>
                <div class="shadow">
                    <div class="syntax"><span class="keyword">fopen</span>(<em>filename</em>, <em>mode</em>)</div>
                </div>
                <p>The first parameter passed to <code>fopen()</code> specifies the name of the file you want to open, and the second parameter specifies in which mode the file should be opened. For example:</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=php&amp;file=open-a-file" target="_blank" class="try-btn" title="Run this code to view the output">Run this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-php">&lt;?php
$handle = fopen("data.txt", "r");
?&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <p>The file may be opened in one of the following modes:</p>
                <div class="shadow" id="modes">
                    <table class="data align-center">
                        <thead>
                            <tr>
                            	<th style="width: 50px;">Modes</th>
                            	<th>What it does</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><code>r</code></td>
                                <td>Open the file for reading only.</td>
                            </tr>
                            <tr>
                                <td><code>r+</code></td>
                                <td>Open the file for reading and writing.</td>
                            </tr>
                            <tr>
                                <td><code>w</code></td>
                                <td>Open the file for writing only and clears the contents of file. If the file does not exist, PHP will attempt to create it.</td>
                            </tr>
                            <tr>
                                <td><code>w+</code></td>
                                <td>Open the file for reading and writing and clears the contents of file. If the file does not exist, PHP will attempt to create it.</td>
                            </tr>
                            <tr>
                                <td><code>a</code></td>
                                <td>Append. Opens the file for writing only. Preserves file content by writing to the end of the file. If the file does not exist, PHP will attempt to create it.</td>
                            </tr>
                            <tr>
                                <td><code>a+</code></td>
                                <td>Read/Append. Opens the file for reading and writing. Preserves file content by writing to the end of the file. If the file does not exist, PHP will attempt to create it.</td>
                            </tr>
                            <tr>
                                <td><code>x</code></td>
                                <td>Open the file for writing only. Return <code>FALSE</code> and generates an error if the file already exists. If the file does not exist, PHP will attempt to create it.</td>
                            </tr>
                            <tr>
                                <td><code>x+</code></td>
                                <td>Open the file for reading and writing; otherwise it has the same behavior as 'x'.</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <p>If you try to open a file that doesn't exist, PHP will generate a warning message. So, to avoid these error messages you should always implement a simple check whether a file or directory exists or not before trying to access it, with the PHP <code>file_exists()</code> function.</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=php&amp;file=check-file-exists-or-not" target="_blank" class="try-btn" title="Run this code to view the output">Run this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-php">&lt;?php
$file = "data.txt";
 
// Check the existence of file
if(file_exists($file)){
    // Attempt to open the file
    $handle = fopen($file, "r");
} else{
    echo "ERROR: File does not exist.";
}
?&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <!--Tip Box-->
                <div class="color-box">
                    <div class="shadow">
                        <div class="info-tab tip-icon" title="Useful Tips"><i></i></div>
                        <div class="tip-box">
                            <p><strong>Tip:</strong> Operations on files and directories are prone to errors. So it's a good practice to implement some form of error checking so that if an error occurs your script will handle the error gracefully. See the tutorial on <a href="php-error-handling.php">PHP error handling</a>.</p>
                        </div>
                    </div>
                </div>
                <!--End:Tip Box-->
                <hr />
                <h2>Closing a File with PHP <code>fclose()</code> Function</h2>
                <p>Once you've finished working with a file, it needs to be closed. The <code>fclose()</code> function is used to close the file, as shown in the following example:</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=php&amp;file=close-a-file" target="_blank" class="try-btn" title="Run this code to view the output">Run this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-php">&lt;?php
$file = "data.txt";
 
// Check the existence of file
if(file_exists($file)){
    // Open the file for reading
    $handle = fopen($file, "r") or die("ERROR: Cannot open the file.");
        
    /* Some code to be executed */
        
    // Closing the file handle
    fclose($handle);
} else{
    echo "ERROR: File does not exist.";
}
?&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <!--Note box-->
                <div class="color-box">
                    <div class="shadow">
                    <div class="info-tab note-icon" title="Important Notes"><i></i></div>
                    <div class="note-box">
                        <p><strong>Note:</strong> Although PHP automatically closes all open files when script terminates, but it's a good practice to close a file after performing all the operations.</p>
                    </div>
                    </div>
                </div>
                <!--End:Note box-->
                <hr />
                <h2>Reading from Files with PHP <code>fread()</code> Function</h2>
                <p>Now that you have understood how to open and close files. In the following section you will learn how to read data from a file. PHP has several functions for reading data from a file. You can read from just one character to the entire file with a single operation.</p>
                <h3>Reading Fixed Number of Characters</h3>
                <p>The  <code>fread()</code> function can be used to read a specified number of characters from a file. The basic syntax of this function can be given with.</p>
                <div class="shadow">
                    <div class="syntax"><span class="keyword">fread</span>(<em>file handle</em>, <em>length in bytes</em>)</div>
                </div>
                <p>This function takes two parameter &mdash; A file handle and the number of bytes to read. The following example reads 20 bytes from the "data.txt" file including spaces. Let's suppose the file "data.txt" contains a paragraph of text "The quick brown fox jumps over the lazy dog."</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=php&amp;file=read-strings-of-characters" target="_blank" class="try-btn" title="Run this code to view the output">Run this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-php">&lt;?php
$file = "data.txt";
 
// Check the existence of file
if(file_exists($file)){
    // Open the file for reading
    $handle = fopen($file, "r") or die("ERROR: Cannot open the file.");
        
    // Read fixed number of bytes from the file
    $content = fread($handle, "20");
        
    // Closing the file handle
    fclose($handle);
        
    // Display the file content 
    echo $content;
} else{
    echo "ERROR: File does not exist.";
}
?&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <p>The above example will produce the following output:</p>
                <div class="output-box break">
                    The quick brown fox
                </div>
                <h3>Reading the Entire Contents of a File</h3>
                <p>The <code>fread()</code> function can be used in conjugation with the <code>filesize()</code> function to read the entire file at once. The <code>filesize()</code> function returns the size of the file in bytes.</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=php&amp;file=read-entire-file" target="_blank" class="try-btn" title="Run this code to view the output">Run this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-php">&lt;?php
$file = "data.txt";
 
// Check the existence of file
if(file_exists($file)){
    // Open the file for reading
    $handle = fopen($file, "r") or die("ERROR: Cannot open the file.");
        
    // Reading the entire file
    $content = fread($handle, filesize($file));
        
    // Closing the file handle
    fclose($handle);
        
    // Display the file content
    echo $content;
} else{
    echo "ERROR: File does not exist.";
}
?&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<p>The above example will produce the following output:</p>
                <div class="output-box">
                    The quick brown fox jumps over the lazy dog.
                </div>
        		<p>The easiest way to read the entire contents of a file in PHP is with the <code>readfile()</code> function. This function allows you to read the contents of a file without needing to open it. The following example will generate the same output as above example:</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=php&amp;file=get-all-contents-of-a-file" target="_blank" class="try-btn" title="Run this code to view the output">Run this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-php">&lt;?php
$file = "data.txt";
 
// Check the existence of file
if(file_exists($file)){
    // Reads and outputs the entire file
    readfile($file) or die("ERROR: Cannot open the file.");
} else{
    echo "ERROR: File does not exist.";
}
?&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<p>The above example will produce the following output:</p>
                <div class="output-box">
                    The quick brown fox jumps over the lazy dog.
                </div>
        		<p>Another way to read the whole contents of a file without needing to open it is with the <code>file_get_contents()</code> function. This function accepts the name and path to a file, and reads the entire file into a string variable. Here's an example:</p>
        		<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=php&amp;file=get-file-contents-as-a-string" target="_blank" class="try-btn" title="Run this code to view the output">Run this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-php">&lt;?php
$file = "data.txt";
 
// Check the existence of file
if(file_exists($file)){
    // Reading the entire file into a string
    $content = file_get_contents($file) or die("ERROR: Cannot open the file.");
        
    // Display the file content 
    echo $content;
} else{
    echo "ERROR: File does not exist.";
}
?&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <p>One more method of reading the whole data from a file is the PHP's <code>file()</code> function. It does a similar job to <code>file_get_contents()</code> function, but it returns the file contents as an array of lines, rather than a single string. Each element of the returned array corresponds to a line in the file.</p>
                <p>To process the file data, you need to iterate over the array using a <a href="php-loops.php#foreach-loop">foreach loop</a>. Here's an example, which reads a file into an array and then displays it using the loop:</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=php&amp;file=get-file-contents-as-an-array" target="_blank" class="try-btn" title="Run this code to view the output">Run this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-php">&lt;?php
$file = "data.txt";
 
// Check the existence of file
if(file_exists($file)){
    // Reading the entire file into an array
    $arr = file($file) or die("ERROR: Cannot open the file.");
    foreach($arr as $line){
        echo $line;
    }
} else{
    echo "ERROR: File does not exist.";
}
?&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <hr />
                <h2>Writing the Files Using PHP <code>fwrite()</code> Function</h2>
                <p>Similarly, you can write data to a file or append to an existing file using the PHP <code>fwrite()</code> function. The basic syntax of this function can be given with:</p>
                <div class="shadow">
                    <div class="syntax"><span class="keyword">fwrite</span>(<i>file handle</i>, <i>string</i>)</div>
                </div>
                <p>The <code>fwrite()</code> function takes two parameter &mdash; A file handle and the string of data that is to be written, as demonstrated in the following example:</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="javascript:void(0);" target="_blank" class="try-btn disabled" title="Disabled">Run this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-php">&lt;?php
$file = "note.txt";
    
// String of data to be written
$data = "The quick brown fox jumps over the lazy dog.";
    
// Open the file for writing
$handle = fopen($file, "w") or die("ERROR: Cannot open the file.");
    
// Write data to the file
fwrite($handle, $data) or die ("ERROR: Cannot write the file.");
    
// Closing the file handle
fclose($handle);
    
echo "Data written to the file successfully.";
?&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<p>In the above example, if the "note.txt" file doesn't exist PHP will automatically create it and write the data. But, if the "note.txt" file already exist, PHP will erase the contents of this file, if it has any, before writing the new data, however if you just want to append the file and preserve existing contents just use the <a href="#modes">mode</a> <code>a</code> instead of <code>w</code> in the above example.</p>
                <p>An alternative way is using the <code>file_put_contents()</code> function. It is counterpart of <code>file_get_contents()</code> function and provides an easy method of writing the data to a file without needing to open it. This function accepts the name and path to a file together with the data to be written to the file. Here's an example:</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="javascript:void(0);" target="_blank" class="try-btn disabled" title="Disabled">Run this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-php">&lt;?php
$file = "note.txt";
    
// String of data to be written
$data = "The quick brown fox jumps over the lazy dog.";
    
// Write data to the file
file_put_contents($file, $data) or die("ERROR: Cannot write the file.");
    
echo "Data written to the file successfully.";
?&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <p>If the file specified in the <code>file_put_contents()</code> function already exists, PHP will overwrite it by default. If you would like to preserve the file's contents you can pass the special <code>FILE_APPEND</code> flag as a third parameter to the <code>file_put_contents()</code> function. It will simply append the new data to the file instead of overwitting it. Here's an example:</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="javascript:void(0);" target="_blank" class="try-btn disabled" title="Disabled">Run this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-php">&lt;?php
$file = "note.txt";
    
// String of data to be written
$data = "The quick brown fox jumps over the lazy dog.";
    
// Write data to the file
file_put_contents($file, $data, FILE_APPEND) or die("ERROR: Cannot write the file.");
    
echo "Data written to the file successfully.";
?&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<hr />
				<h2>Renaming Files with PHP <code>rename()</code> Function</h2>
				<p>You can rename a file or directory using the PHP's <code>rename()</code> function, like this:</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="javascript:void(0);" target="_blank" class="try-btn disabled" title="Disabled">Run this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-php">&lt;?php
$file = "file.txt";
 
// Check the existence of file
if(file_exists($file)){
    // Attempt to rename the file
    if(rename($file, "newfile.txt")){
        echo "File renamed successfully.";
    } else{
        echo "ERROR: File cannot be renamed.";
    }
} else{
    echo "ERROR: File does not exist.";
}
?&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<hr />
				<h2>Removing Files with PHP <code>unlink()</code> Function</h2>
				<p>You can delete files or directories using the PHP's <code>unlink()</code> function, like this:</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="javascript:void(0);" target="_blank" class="try-btn disabled" title="Disabled">Run this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-php">&lt;?php
$file = "note.txt";
 
// Check the existence of file
if(file_exists($file)){
    // Attempt to delete the file
    if(unlink($file)){
        echo "File removed successfully.";
    } else{
        echo "ERROR: File cannot be removed.";
    }
} else{
    echo "ERROR: File does not exist.";
}
?&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<p>In the next chapter we will learn more about <a href="php-parsing-directories.php">parsing directories or folders</a> in PHP.</p>
                <hr />
                <h2>PHP Filesystem Functions</h2>
                <p>The following table provides the overview of some other useful PHP filesystem functions that can be used for reading and writing the files dynamically.</p>
                <div class="shadow">
                    <table class="data">
                        <thead>
                            <tr>
                            	<th style="width: 150px;">Function</th>
                            	<th>Description</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><code>fgetc()</code></td>
                                <td>Reads a single character at a time.</td>
                            </tr>
                            <tr>
                                <td><code>fgets()</code></td>
                                <td>Reads a single line at a time.</td>
                            </tr>
                            <tr>
                                <td><code>fgetcsv()</code></td>
                                <td>Reads a line of comma-separated values.</td>
                            </tr>
							<tr>
                                <td><code>filetype()</code></td>
                                <td>Returns the type of the file.</td>
                            </tr>
							<tr>
                                <td><code>feof()</code></td>
                                <td>Checks whether the end of the file has been reached.</td>
                            </tr>
							<tr>
                                <td><code>is_file()</code></td>
                                <td>Checks whether the file is a regular file.</td>
                            </tr>
							<tr>
                                <td><code>is_dir()</code></td>
                                <td>Checks whether the file is a directory.</td>
                            </tr>
							<tr>
                                <td><code>is_executable()</code></td>
                                <td>Checks whether the file is executable.</td>
                            </tr>
							<tr>
                                <td><code>realpath()</code></td>
                                <td>Returns canonicalized absolute pathname.</td>
                            </tr>
							<tr>
                                <td><code>rmdir()</code></td>
                                <td>Removes an empty directory.</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <p>Please check out the <a href="../php-reference/php-file-system-functions.php">PHP filesystem reference</a> for other useful PHP filesystem functions.</p>
                <!--Bottom Navigation-->
                <div class="bottom-link clearfix">
                    <a href="php-include-files.php" class="previous-page-bottom">Previous Page</a>
                    <a href="php-parsing-directories.php" class="next-page-bottom">Next Page</a>
                </div>
                <!--End:Bottom Navigation-->  
                <!-- InstanceEndEditable -->
                <!--Bottom Ads-->
                <div class="bottom-ad clearfix">
                    <div class="ad-label">Advertisements</div>

<!--Rectangle Left-->
<div class="rectangle-left fl">
    
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Large Rectangle Left -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="8162953958"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
<!--End:Rectangle Left-->


<!--Rectangle Right-->
<div class="rectangle-right fr">

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Large Rectangle Right -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="3324015654"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
<!--End:Rectangle Right-->                </div>
                <!--End:Bottom Ads-->
            </div>
            <!--End:Text Content-->
            <!--Feedback Form-->
			<div class="snippets">
	<a href="/snippets/gallery.php" target="_blank">
    	<img src="/lib/images/bootstrap-code-snippets.png" alt="Bootstrap UI Design Templates" />
	</a>
</div>

<div class="report-error" id="feedback">
    <div class="contact-form clearfix">
        <div class="close"><span class="icon-close"></span></div>
        <form id="feedback-form">
            <h3>Your Feedback:</h3>
            <div class="clearfix">
                <div class="name fl"><label>Your Name (optional) <input type="text" name="user-name" id="user-name" /></label></div>
                <div class="email fr"><label>Your E-mail (optional) <input type="text" name="user-email" id="user-email" /></label></div>
            </div>
            <div><label>Page address <input type="text" name="page-url" id="page-url" class="disabled" disabled="disabled" /></label></div>
            <div><label>Description <textarea name="description" id="description" rows="6"></textarea></label></div>
            <p id="feedback-error">We would love to hear from you, please drop us a line.</p>
            <div><button type="button" class="action-btn" onclick="sendFeedback()"><span class="icon-send"></span> Send</button></div>
        </form>
        <div id="response"></div>
    </div>           
</div>            <!--End:Feedback Form-->
        </div>        
        <div class="sidebar">
            <div class="ad-label">Advertisements</div>

<div class="skyscraper primary">

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Premium Skyscraper -->
<ins class="adsbygoogle"
     style="display:inline-block;width:160px;height:600px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="4376141825"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>

<div class="skyscraper">
    
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Bottom Skyscraper -->
<ins class="adsbygoogle"
     style="display:inline-block;width:160px;height:600px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="3387984471"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>        </div>
    </div>
    <!--Footer-->
	<!--Footer-->
<div class="footer">
    <div class="appeal">
        <div class="wrapper">
            <p>Is this website helpful to you? Please give us a
            <a href="/like.php" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=250,width=600,top=150, left='+((screen.width/2)-300));return false;">like</a>,
            or share your <a href="#feedback" class="feedback">feedback</a><em> to help us improve</em>.
            Connect with us on <a href="https://www.facebook.com/tutorialrepublic" target="_blank">Facebook</a> and <a href="https://twitter.com/tutrepublic" target="_blank">Twitter</a> for the latest updates.</p>               
        </div>
    </div>
    <div class="footer-inner">
        <div class="wrapper clearfix">                
            <div class="link-box">
                <h4>About Us</h4>
                <div class="clearfix">
                    <a href="/about-us.php">Our Story</a>                    
                    <a href="/terms-of-use.php">Terms of Use</a>
                    <a href="/privacy-policy.php">Privacy Policy</a>                    
                </div>
            </div>
            <div class="link-box">
                <h4>Contact</h4>
                <div class="clearfix">
                    <a href="/contact-us.php">Contact Us</a>                    
                    <a href="#feedback" class="feedback">Report Error</a>
                    <a href="/advertise-with-us.php">Advertise</a>                    
                </div>
            </div>
            <div class="tool-box">
                <h4>Interactive Tools</h4>
                <div class="tools-list clearfix" id="tools">
                    <a href="/faq/what-is-the-maximum-length-of-title-and-meta-description-tag.php">Title &amp; Meta Length Calculator</a>                           
                    <a href="/html-formatter.php" target="_blank">HTML Formatter</a>                        
                    <a href="/twitter-bootstrap-button-generator.php" target="_blank">Bootstrap Button Generator</a>
                    <a href="/html-reference/html-color-picker.php">HTML Color Picker</a>
                    <a href="/codelab.php?topic=sql&amp;file=select-all" target="_blank">SQL Playground</a>
                    <a href="/codelab.php?topic=html&amp;file=hello-world" target="_blank">HTML Editor</a>                    
                </div>
            </div>
            <div class="footer-logo">
                <img src="/lib/images/logo.svg" alt="TutorialRepublic" />
            </div>
        </div>
    </div>           
        <div class="bottom-strip">
        <div class="wrapper">
            <div class="notice">Copyright &copy; 2019 Tutorial Republic. All Rights Reserved.</div>
            <div class="social-media">
                <em>Share This:</em>
                <a href="https://facebook.com/sharer.php?u=https://www.tutorialrepublic.com%2Fphp-tutorial%2Fphp-file-system.php" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" title="Facebook"><i class="icon-facebook"></i></a>
                <a href="#" id="tweet-btn" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" title="Twitter"><i class="icon-twitter"></i></a>
                <a href="#" id="email-btn" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" rel="noreferrer" title="Gmail"><i class="icon-mail"></i></a>
            </div>
        </div>            
    </div>
    <script>
        var title = document.title.replace('- Tutorial Republic', '');
        document.getElementById('tweet-btn').href = 'https://twitter.com/share?text=' + title + '- &url=https://www.tutorialrepublic.com%2Fphp-tutorial%2Fphp-file-system.php';
        document.getElementById('email-btn').href = 'https://mail.google.com/mail/?view=cm&fs=1&su=' + title + '&body=https://www.tutorialrepublic.com%2Fphp-tutorial%2Fphp-file-system.php';
    </script>
</div>
<!--End:Footer-->
    
<div class="backdrop mobile-only"></div>

<!-- TutorialRepublic base script -->
<script>
// Adding CSS files
[
	'/lib/styles/extended.new-3.7.css',
	'/lib/icomoon/style.css'
].forEach(function(href) {
	var link = document.createElement('link');
	link.rel = 'stylesheet';
	link.href = href;
	(document.getElementsByTagName('head')[0]).appendChild(link);
});

// Adding JS files
[
	'https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js',
	'/lib/js/prism.js',
	'/lib/js/default.new-2.9.min.js'
].forEach(function(src) {
	var script = document.createElement('script');
	script.async = false; // important
	script.src = src;
	(document.getElementsByTagName('body')[0]).appendChild(script);
});
</script>


    <!--End:Footer-->
</body>
<!-- InstanceEnd --></html>