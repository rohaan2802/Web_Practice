<!DOCTYPE html>
<html lang="en"><!-- InstanceBegin template="/Templates/php.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
	<!-- InstanceBeginEditable name="doctitle" -->
    <title>PHP MySQL CRUD Application - Tutorial Republic</title>
	<meta name="description" content="In this tutorial you will learn how to build a CRUD application to create, read, update and delete records in a MySQL database table with PHP." />
    <!-- InstanceEndEditable -->
    	<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta property="fb:admins" content="100001054961582" />
<meta property="fb:app_id" content="1404574483159557" />
<meta property="og:image" content="/lib/images/signature.png" />
<link type="image/x-icon" href="/favicon.ico" rel="shortcut icon" />
<style>
html,body,h1,h2,h3,h4,h5,h6,p,blockquote,pre,img{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}
html,body{min-height:100%}
p{margin:0 0 12px}
ol,ul{margin:0 0 12px}
a,a:active,a:visited{outline:none;color:#1db79f;text-decoration:none}
a img{border:none;outline:none}
a code{color:inherit;background:none}
p code,table td:last-child code,.content ul li code,code.mark{padding:2px 4px;color:#333;background-color:#f1f1f1;border-radius:4px}
table{border-collapse:collapse;border-spacing:0}
table td{vertical-align:top}
body{min-width:1300px;color:#414141;background:#fafafa;font-family:"Segoe UI","Helvetica Neue",Arial,sans-serif;font-size:17px;line-height:1.7}
input,select,textarea,button,div,span,a{box-sizing:border-box}
h1,h2,h3,h4{color:#262626;font-weight:500;margin:20px 0 10px;line-height:1.5;font-weight:600}
h1{font-size:34px;margin-top:17px}
h2{font-size:28px}
h3{font-size:22px}
.space{margin-bottom:25px!important}
.break{margin-bottom:15px!important}
.text-center{text-align:center!important}
.scroll{height:195px;overflow-y:scroll}
.scroll.large{height:245px}
.scroll.xlarge{height:290px}
.scroll.xxlarge{height:340px}
sup{font-size:13px}
.leaderboard{padding-top:8px;position:relative}
.ad-container{height:90px;overflow:hidden}
.intro-image img{display:block;padding:10px 0 25px;max-width:100%}
.clearfix::after{content:".";display:block;height:0;clear:both;visibility:hidden}
code,.code,.syntax,.green-box,.sky-box,.gray-box,.pink-box,.red-box,.at-rule,.codebox pre,.console-output{font-size:16px;font-family:Consolas,Monaco,Courier,monospace}
.console-output{margin:15px 0}
hr{border:none;border-bottom:1px solid #e7e9ed;height:1px;margin:30px 0}
.summary,.topic{border:1px solid #eaeaea;border-width:1px 0;margin:20px 0;padding:10px 0;color:#8e9aa6;line-height:1.5}
h2.section-title span{display:inline-block;border-bottom:4px solid #c9d7e0;padding:0 50px 12px 0}
.wrapper{width:1300px;padding:0 15px;margin:0 auto}
.header{background:#23384e;padding:16px 0}
input.search{background:#fff;border:0 none;color:#807E7E;float:left;height:38px;line-height:26px;font-size:14px;margin:0 0 0 12px;outline:medium none;padding:6px 14px;width:500px;border-radius:2px;box-shadow:0 0 1px rgba(0,0,0,0.6);font-family:inherit}
.search-btn{color:rgba(0,0,0,.6);background:#ebebeb;border:none;outline:none;cursor:pointer;float:left;height:38px;line-height:46px;width:44px;display:block;margin-left:-2px;border-radius:0 2px 2px 0;box-shadow:0 0 1px rgba(0,0,0,0.7)}
.logo{width:304px}
.logo img{height:44px;margin:-3px 0;display:block}
.site-search{float:left;margin-left:100px}
.menu{background-color:#f5f5f5;box-shadow:0 1px 1px rgba(0,0,0,.15);position:relative;z-index:9}
.menu a{color:#666;display:inline-block;padding:0 10px;text-decoration:none;font-size:14px;font-weight:600;height:48px;line-height:48px}
.menu a:first-child{margin-left:-10px}
.menu a.tool-link{float:right;display:inline-block;border-radius:30px;line-height:28px;position:relative;height:auto;top:9px;padding:0 12px;color:#1ebba3;border:1px double #1ebba3}
.fl,.logo{float:left}
.leftcolumn{width:240px;float:left;font-size:16px;color:#4f4f4f}
.centercolumn{width:850px;float:left}
.content{background:#fff;padding:20px 40px;border:1px solid #dedede;border-top:none;border-radius:1px}
.sidebar{width:160px;float:left;padding-top:28px;margin-left:20px;position:relative}
.leftcolumn .segment{margin:16px 0 12px;position:relative;font-size:18px;font-weight:600;line-height:normal}
.leftcolumn a{color:#4f4f4f;font-size:16px;line-height:26px;display:block;border-bottom:1px solid transparent}
.leftcolumn ul{list-style:none;padding:0}
.segment,.chapters,.chapters a{float:left;clear:both}
h1 code,h2 code,h3 code{font:inherit}
.color-box{margin:15px 0;padding-left:20px}
.note-box,.warning-box,.tip-box{padding:8px 8px 3px 26px}
.info-tab{float:left;margin-left:-23px}
.content ul li{margin-top:7px}
.extra{padding-top:5px}
.green-box,.sky-box,.gray-box,.red-box,.pink-box{color:#000;margin-top:15px;padding:10px;background-color:#f6f8fa;border:1px solid #d7e2ec}
.example{background:#f4f5f6;padding:3px;margin:15px 0}
.codebox{background:#fff;border:1px solid #ddd}
.codebox-title{height:41px;padding-left:12px;border-bottom:1px solid #ddd;background:#f5f5f5}
.codebox-title h4{margin:0;font-size:18px;line-height:40px;float:left;display:inline;font-weight:500}
a.try-btn,a.download-btn{width:140px;height:40px;color:#333;font-size:15px;line-height:41px;font-weight:600;text-align:center;text-decoration:none;float:right;display:block;border-left:1px solid #ddd;background:rgba(27,31,35,0.08);box-sizing:border-box;font-family:Arial,sans-serif}
a.try-btn span{font-size:18px;line-height:normal}
.hide,.code-style,.box-size,.bottom-link,.footer,.code-style,.snippets,.report-error,.badge,.social,.ad-label,.mobile-only{display:none}
.skyscraper{width:160px;height:600px;overflow:hidden;margin-bottom:20px;background:#ebecf0}
.bottom-ad{margin-top:46px;padding:24px;position:relative;background:url(/lib/images/smooth-line.png) no-repeat center #f9f9f9}
.rectangle-left,.rectangle-right{min-width:336px;min-height:280px;overflow:hidden}
.fr,a.previous-page,a.next-page,.rectangle-right,.topic-nav{float:right}
a.previous-page,a.next-page{width:32px;height:32px;line-height:30px}
.shadow{background:#F7F8F9;padding:3px;margin:10px 0}
.syntax{color:#2f4959;padding:13px 18px;background:#F9F9FA;border:1px solid #ddd;font-size:15px}
code[class*="language-"],pre[class*="language-"]{color:#000;background:none;font-family:Consolas,Monaco,'Andale Mono','Ubuntu Mono',monospace;text-align:left;white-space:pre;word-break:normal;word-wrap:normal;line-height:1.5;tab-size:4;hyphens:none}
pre[class*="language-"]{position:relative;margin:.5em 0;overflow:visible;padding:0}
pre[class*="language-"]>code{position:relative;border-left:10px solid #358ccb;box-shadow:-1px 0 0 0 #358ccb,0 0 0 1px #dfdfdf;background-color:#fdfdfd;background-image:linear-gradient(transparent 50%,rgba(69,142,209,0.04) 50%);background-size:3em 3em;background-origin:content-box;background-attachment:local}
code[class*="language"]{max-height:inherit;height:inherit;padding:0 1em;display:block;overflow:auto}
:not(pre) > code[class*="language-"]{position:relative;padding:.2em;border-radius:.3em;color:#c92c2c;border:1px solid rgba(0,0,0,0.1);display:inline;white-space:normal}
pre[class*="language-"].line-numbers{padding-left:0}
pre[class*="language-"].line-numbers code{padding-left:3.8em}
pre[class*="language-"].line-numbers .line-numbers-rows{left:0}
pre[class*="language-"][data-line]{padding-top:0;padding-bottom:0;padding-left:0}
pre[data-line] code{position:relative;padding-left:4em}
pre .line-highlight{margin-top:0}
pre.line-numbers{position:relative;padding-left:3.8em;counter-reset:linenumber;white-space:pre-wrap!important}
pre.line-numbers > code{position:relative;white-space:inherit}
.line-numbers-rows,.codebox pre.inactive{display:none}
.codebox pre.syntax-highlighter{margin:0;padding:0;overflow:auto}
pre.line-numbers .line-numbers-rows{border-right:3px solid #6CE26C}
.codebox pre.syntax-highlighter > code{box-shadow:none!important;padding-left:3.8em;background-image:linear-gradient(transparent 50%,#F8F8F8 50%);font-family:Consolas,Monaco,'Andale Mono','Ubuntu Mono',monospace!important;font-size:16px;line-height:1.5}
.codebox pre.syntax-highlighter,.codebox pre.syntax-highlighter code{border:none;width:100%;box-sizing:border-box}
pre.line-numbers code,pre.line-numbers .line-numbers-rows{padding-top:2px;padding-bottom:2px}
.preview-box{padding:15px;text-align:center;cursor:pointer;overflow:hidden;background:#FFF;border:1px solid #e6e6e6}
.preview-box a,.preview-box img{display:block;margin:0 auto}
.download-box{text-align:center;padding:20px 0;margin:20px 0 10px}
.output-box{border-color:#d4d4d4;border-style:solid;border-width:1px 0;padding:5px 15px;overflow:hidden;background:#fff;margin:10px 0}
.demo-box{margin-top:15px}
.subhead{border-bottom:3px solid #DCE3EB;margin-bottom:15px;padding-bottom:10px}
table.data,table.description{width:100%;font-size:92%}
table.data th{color:#000;padding:8px 7px;text-align:left;font-size:15px;background:#F8F8F8}
table.data td{color:#484848;padding:5px 7px;background:#fff}
table.data th,table.data td{vertical-align:top;border:1px solid #DCE3EB}
table.data tr.section th,table.data td.section{font-size:15px;background:#f0f4f7}
table.no-wrap tr td:first-child{white-space:nowrap}
@media screen and (max-width: 1280px) {
body{min-width:1260px}
.wrapper{width:1260px}
.leftcolumn{width:230px}
.centercolumn{width:820px}
}
@media screen and (max-width: 800px) {
body{min-width:100%;max-width:100%;padding-top:46px}
.wrapper{width:100%;padding:0}
.header{height:46px;padding:5px 0;position:fixed;top:0;left:0;right:0;width:100%;z-index:99}
.logo{width:auto;display:block;padding:6px 0 0 60px;position:absolute;left:0;z-index:100}
.logo img{height:30px}
.menu{width:100%;padding-left:12px;padding-right:12px;overflow-x:auto;white-space:nowrap}
.centercolumn{width:100%;float:none}
.content{padding:10px;border-width:0 0 1px 0}
.content img{max-width:100%;height:auto}
.content pre{max-width:100%;overflow:hidden}
.skyscraper{display:inline-block}
.shadow,.example,.console-output{max-width:100%;overflow-x:auto}
.codebox-title{position:relative}
.codebox.multi-style-mode pre{padding-top:7px;margin-top:36px;border-top:1px solid #ddd}
.bottom-ad{height:auto;background:none;padding:30px 0 0;margin:40px 0 0;text-align:center;position:relative}
.rectangle-left,.rectangle-right{float:none;display:inline-block;margin:10px auto;background:#EDEEF2}
.leftcolumn,.footer,.social,.site-search,.code-style,.menu a.tool-link,.backdrop{display:none}
.summary,.topic{padding:5px 0;margin:10px 0}
.leftcolumn,.centercolumn,.sidebar{float:none}
.header,.menu,.centercolumn,.footer,.appeal-text{width:100%}
a.try-btn,a.download-btn{width:130px}
.native-unit{margin-bottom:30px}
.sidebar{margin: 25px auto 0}
.overview{padding-right:0}
.scroll-pane{overflow-x:auto}
table.data{min-width:480px}
table.data pre{display:inline;white-space:normal}
table tr th,table tr td{width:auto!important}
.preview-box{padding:6px}
.leaderboard{margin:20px 0}
h1{font-size:30px}
h2{font-size:24px}
h3{font-size:20px}
.codebox pre.syntax-highlighter{overflow-x:auto}
.codebox pre.syntax-highlighter > code{width:614px;height:auto;overflow-x:hidden}
}
@media screen and (min-width: 801px) {
.site-search,.leftcolumn,.social{display:block!important}
.backdrop{display:none!important}
.hide-scroll{overflow-x:hidden!important}
}</style>    
    <!-- InstanceBeginEditable name="head" -->
    <!-- InstanceEndEditable -->
    
    <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-40117907-1', 'auto');
  ga('send', 'pageview');
</script></head>
<body>
    <!--Header-->
    
<div class="header">
    <div class="wrapper clearfix">
        <button type="button" class="open-menu mobile-only"><i class="icon-menu"></i></button>
        <div class="logo">
            <a href="https://www.tutorialrepublic.com/"><img src="/lib/images/logo.svg" alt="TutorialRepublic" /></a>
        </div>
        <div class="site-search">
            <form action="https://www.google.com/search" method="get" target="_blank" class="clearfix">
                <input type="hidden" value="www.tutorialrepublic.com" name="sitesearch" />
                <input type="text" name="q" placeholder="Search topics, tutorials, questions and answers..." id="searchInput" class="search" />
                <button type="submit" class="search-btn"><span class="icon-search"></span></button>
            </form>
        </div>
        <div class="social">                
            <a href="https://www.facebook.com/tutorialrepublic" target="_blank" title="Join us on Facebook"><i class="icon-facebook"></i></a>
            <a href="https://twitter.com/tutrepublic" target="_blank" title="Follow us on Twitter"><i class="icon-twitter"></i></a>
            <a href="/contact-us.php" target="_blank" title="Send us an Email"><i class="icon-mail"></i></a>
        </div>
        <button type="button" class="open-search mobile-only">
            <i class="icon-search"></i>
        </button>
    </div>    
</div>
<div class="menu">
    <div class="wrapper">
        <a href="//www.tutorialrepublic.com" title="Home Page">HOME</a>
        <a href="/html-tutorial/" title="HTML Tutorial">HTML5</a>            
        <a href="/css-tutorial/" title="CSS Tutorial">CSS3</a>
        <a href="/javascript-tutorial/" title="JavaScript Tutorial">JAVASCRIPT</a>
        <a href="/jquery-tutorial/" title="jQuery Tutorial">JQUERY</a>
        <a href="/twitter-bootstrap-tutorial/" title="Bootstrap Tutorial">BOOTSTRAP4</a>
        <a href="/php-tutorial/" title="PHP Tutorial">PHP7</a> 
        <a href="/sql-tutorial/" title="SQL Tutorial">SQL</a>
        <a href="/references.php" title="Web References">REFERENCES</a>
        <a href="/practice-examples.php" title="Practice Examples and Demos">EXAMPLES</a>
        <a href="/faq.php" title="Frequently Asked Questions and Answers">FAQ</a>
        <a href="/snippets/gallery.php" title="Bootstrap Code Snippets" target="_blank">SNIPPETS</a>
        <a href="/codelab.php" class="tool-link" target="_blank">Online HTML Editor</a>
    </div>        
</div>    <!--End:Header-->
    <div class="wrapper clearfix">
        <div class="leftcolumn" id="myNav">
		
        <div class="segment"><span>PHP</span> BASIC</div>
<div class="chapters">
    <a href="/php-tutorial/">PHP Introduction</a>
    <a href="/php-tutorial/php-get-started.php">PHP Getting Started</a>
    <a href="/php-tutorial/php-syntax.php">PHP Syntax</a>
    <a href="/php-tutorial/php-variables.php">PHP Variables</a>
	<a href="/php-tutorial/php-constants.php">PHP Constants</a>
    <a href="/php-tutorial/php-echo-and-print-statements.php">PHP Echo and Print</a>
	<a href="/php-tutorial/php-data-types.php">PHP Data Types</a>
    <a href="/php-tutorial/php-strings.php">PHP Strings</a>
    <a href="/php-tutorial/php-operators.php">PHP Operators</a>
    <a href="/php-tutorial/php-if-else-statements.php">PHP If&hellip;Else</a>
    <a href="/php-tutorial/php-switch-case-statements.php">PHP Switch&hellip;Case</a>
    <a href="/php-tutorial/php-arrays.php">PHP Arrays</a>
    <a href="/php-tutorial/php-sorting-arrays.php">PHP Sorting Arrays</a>    
    <a href="/php-tutorial/php-loops.php">PHP Loops</a>
    <a href="/php-tutorial/php-functions.php">PHP Functions</a>
	<a href="/php-tutorial/php-math-operations.php">PHP Math Operations</a>
    <a href="/php-tutorial/php-get-and-post.php">PHP GET and POST</a>
</div>
<div class="segment"><span>PHP</span> ADVANCED</div>
<div class="chapters">
    <a href="/php-tutorial/php-date-and-time.php">PHP Date and Time</a>
    <a href="/php-tutorial/php-include-files.php">PHP Include Files</a>
    <a href="/php-tutorial/php-file-system.php">PHP File system</a>
	<a href="/php-tutorial/php-parsing-directories.php">PHP Parsing Directories</a>
    <a href="/php-tutorial/php-file-upload.php">PHP File Upload</a>
	<a href="/php-tutorial/php-file-download.php">PHP File Download</a>
    <a href="/php-tutorial/php-cookies.php">PHP Cookies</a> 
    <a href="/php-tutorial/php-sessions.php">PHP Sessions</a>       
    <a href="/php-tutorial/php-send-email.php">PHP Send Email</a>
    <a href="/php-tutorial/php-form-handling.php">PHP Form Handling</a>
    <a href="/php-tutorial/php-form-validation.php">PHP Form Validation</a>
	<a href="/php-tutorial/php-filters.php">PHP Filters</a>
    <a href="/php-tutorial/php-error-handling.php">PHP Error Handling</a>
	<a href="/php-tutorial/php-classes-and-objects.php">PHP Classes and Objects</a>
	<a href="/php-tutorial/php-magic-constants.php">PHP Magic Constants</a>
	<a href="/php-tutorial/php-json-parsing.php">PHP JSON Parsing</a>
	<a href="/php-tutorial/php-regular-expressions.php">PHP Regular Expressions</a>
	<a href="/php-tutorial/php-exception-handling.php">PHP Exception Handling</a>
</div>
<div class="segment"><span>PHP</span> &amp; MySQL DATABASE</div>
<div class="chapters">
    <a href="/php-tutorial/php-mysql-introduction.php">PHP MySQL Introduction</a>
    <a href="/php-tutorial/php-mysql-connect.php">PHP MySQL Connect</a>
    <a href="/php-tutorial/php-mysql-create-database.php">PHP MySQL Create Database</a>
	<a href="/php-tutorial/php-mysql-create-table.php">PHP MySQL Create Table</a>
    <a href="/php-tutorial/php-mysql-insert-query.php">PHP MySQL Insert</a>	
	<a href="/php-tutorial/php-mysql-prepared-statements.php">PHP MySQL Prepared</a>
	<a href="/php-tutorial/php-mysql-last-inserted-id.php">PHP MySQL Last Inserted ID</a>
    <a href="/php-tutorial/php-mysql-select-query.php">PHP MySQL Select</a>
    <a href="/php-tutorial/php-mysql-where-clause.php">PHP MySQL Where</a>
	<a href="/php-tutorial/php-mysql-limit-clause.php">PHP MySQL Limit</a>        
    <a href="/php-tutorial/php-mysql-order-by-clause.php">PHP MySQL Order By</a>
    <a href="/php-tutorial/php-mysql-update-query.php">PHP MySQL Update</a>
    <a href="/php-tutorial/php-mysql-delete-query.php">PHP MySQL Delete</a>
	<a href="/php-tutorial/php-mysql-crud-application.php">PHP&thinsp;MySQL&thinsp;CRUD Application</a>
	<a href="/php-tutorial/php-mysql-ajax-live-search.php">PHP MySQL Ajax Search</a>
	<a href="/php-tutorial/php-mysql-login-system.php">PHP MySQL Login System</a>
</div>
<div class="segment"><span>PHP</span> EXAMPLES</div>
<div class="chapters">
    <a href="/php-examples.php">PHP Practice Examples</a>
	<a href="/faq.php#php-mysql">PHP FAQ's Answers</a>
</div>
<div class="segment"><span>PHP</span> REFERENCE</div>
<div class="chapters">
    <a href="/php-reference/php-string-functions.php">PHP String Functions</a>
    <a href="/php-reference/php-array-functions.php">PHP Array Functions</a>
    <a href="/php-reference/php-file-system-functions.php">PHP File System Functions</a>
    <a href="/php-reference/php-date-and-time-functions.php">PHP Date/Time Functions</a>
    <a href="/php-reference/php-calendar-functions.php">PHP Calendar Functions</a>
    <a href="/php-reference/php-mysqli-functions.php">PHP MySQLi Functions</a>
    <a href="/php-reference/php-filters.php">PHP Filters</a>
    <a href="/php-reference/php-error-levels.php">PHP Error Levels</a>
</div>        
                </div>
        <div class="centercolumn">
            <!--Text Content-->
            <div class="content">
                <div class="leaderboard">
                    
<div class="ad-label">Advertisements</div>
<div class="ad-container">
    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <!-- Responsive Leaderboard -->
    <ins class="adsbygoogle"
            style="display:inline-block;max-width:728px;width:100%;height:90px"
            data-ad-client="ca-pub-9107540490929984"
            data-ad-slot="4302666817"></ins>
    <script>
    (adsbygoogle = window.adsbygoogle || []).push({});
    </script>
</div>                </div>
                <!-- InstanceBeginEditable name="main_content" -->
                <a href="php-mysql-delete-query.php" class="previous-page" title="Go to Previous Page"></a>
                <a href="php-mysql-ajax-live-search.php" class="next-page" title="Go to Next Page"></a>
                <h1>PHP MySQL <span>CRUD Application</span></h1>
                <p class="summary">In this tutorial you'll learn how to build a CRUD application with PHP and MySQL.</p>
                <h2>What is CRUD</h2>				
                <p>CRUD is an acronym for <b>C</b>reate, <b>R</b>ead, <b>U</b>pdate, and <b>D</b>elete. CRUD operations are basic data manipulation for database. We've already learned how to perform create (i.e. insert), read (i.e. select), update and delete operations in previous chapters. In this tutorial we'll create a simple PHP application to perform all these operations on a MySQL database table at one place.</p>
				<p class="space">Well, let's start by creating the table which we'll use in all of our example.</p>
				<h2>Creating the Database Table</h2>
				<p>Execute the following SQL query to create a table named <i>employees</i> inside your MySQL database. We will use this table for all of our future operations.</p>
				<!--Code box-->
                <div class="codebox-wrapper space">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../examples/downloads/employees-table.zip" target="_top" class="download-btn" title="Download Countries Table"><span>Download</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-sql">CREATE TABLE employees (
    id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    address VARCHAR(255) NOT NULL,
    salary INT(10) NOT NULL
);</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<hr />
				<h2>Creating the Config File</h2>
				<p>After creating the table, we need create a PHP script in order to connect to the MySQL database server. Let's create a file named "config.php" and put the following code inside it.</p>
				<p>We'll later include this config file in other pages using the PHP <code>require_once()</code> function.</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox multi-style-mode">
                        <div class="codebox-title">
                        	<h4>Example</h4>
                            <div class="code-style">
                            	<span class="active" data-target="0" data-url="config" title="Show Example Code in MySQLi Procedural Style">Procedural</span> 
                                <span data-target="1" data-url="config-oo-format" title="Show Example Code in MySQLi Object Oriented Style">Object Oriented</span> 
                                <span data-target="2" data-url="config-pdo-format" title="Show Example Code in PDO Style">PDO</span>
                            </div>
                        	<a href="../examples/bin/download-source.php?topic=php&amp;file=config" target="_top" class="download-btn" title="Download Source Code"><span>Download</span></a>
                            <span class="box-size"><i title="Maximize"></i></span>
                        </div>
						<pre class="syntax-highlighter line-numbers scroll large"><code class="language-php">&lt;?php
/* Database credentials. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'demo');
 
/* Attempt to connect to MySQL database */
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
?&gt;</code></pre>
						<pre class="syntax-highlighter line-numbers scroll large hide"><code class="language-php">&lt;?php
/* Database credentials. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'demo');
 
/* Attempt to connect to MySQL database */
$mysqli = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
// Check connection
if($mysqli === false){
    die("ERROR: Could not connect. " . $mysqli->connect_error);
}
?&gt;</code></pre>
						<pre class="syntax-highlighter line-numbers scroll large hide"><code class="language-php">&lt;?php
/* Database credentials. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'demo');
 
/* Attempt to connect to MySQL database */
try{
    $pdo = new PDO("mysql:host=" . DB_SERVER . ";dbname=" . DB_NAME, DB_USERNAME, DB_PASSWORD);
    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e){
    die("ERROR: Could not connect. " . $e->getMessage());
}
?&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<p>If you've downloaded the Object Oriented or PDO code examples using the download button, please remove the text "-oo-format" or "-pdo-format" from file names before testing the code.</p>
				<!--Note box-->
				<div class="color-box">
					<div class="shadow">
						<div class="info-tab note-icon" title="Important Notes"><i></i></div>
						<div class="note-box">
							<p><strong>Note:</strong> Replace the credentials according to your MySQL server setting before testing this code, for example, replace the database name 'demo' with your own database name, replace username 'root' with your own database username, specify database password if there's any.</p>
						</div>
					</div>
				</div>
				<!--End:Note box-->
				<hr />
				<h2>Creating the Landing Page</h2>
				<p>First we will create a landing page for our CRUD application that contains a data grid showing the records from the <i>employees</i> database table. It also has action icons for each record displayed in the grid, that you may choose to view its details, update it, or delete it.</p>
				<p>We'll also add a create button on the top of the data grid that can be used for creating new records in the <i>employees</i> table. Create a file named "index.php" and put the following code in it:</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox multi-style-mode">
                        <div class="codebox-title">
                        	<h4>Example</h4>
                            <div class="code-style">
                            	<span class="active" data-target="0" data-url="index" title="Show Example Code in MySQLi Procedural Style">Procedural</span> 
                                <span data-target="1" data-url="index-oo-format" title="Show Example Code in MySQLi Object Oriented Style">Object Oriented</span> 
                                <span data-target="2" data-url="index-pdo-format" title="Show Example Code in PDO Style">PDO</span>
                            </div>
                        	<a href="../examples/bin/download-source.php?topic=php&amp;file=index" target="_top" class="download-btn" title="Download Source Code"><span>Download</span></a>
                            <span class="box-size"><i title="Maximize"></i></span>
                        </div>
                        <pre class="syntax-highlighter line-numbers scroll xlarge"><code class="language-php hide-scroll">&lt;!DOCTYPE html&gt;
&lt;html lang="en"&gt;
&lt;head&gt;
    &lt;meta charset="UTF-8"&gt;
    &lt;title&gt;Dashboard&lt;/title&gt;
    &lt;link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css"&gt;
    &lt;script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"&gt;&lt;/script&gt;
    &lt;script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"&gt;&lt;/script&gt;
    &lt;style type="text/css"&gt;
        .wrapper{
            width: 650px;
            margin: 0 auto;
        }
        .page-header h2{
            margin-top: 0;
        }
        table tr td:last-child a{
            margin-right: 15px;
        }
    &lt;/style&gt;
    &lt;script type="text/javascript"&gt;
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();   
        });
    &lt;/script&gt;
&lt;/head&gt;
&lt;body&gt;
    &lt;div class="wrapper"&gt;
        &lt;div class="container-fluid"&gt;
            &lt;div class="row"&gt;
                &lt;div class="col-md-12"&gt;
                    &lt;div class="page-header clearfix"&gt;
                        &lt;h2 class="pull-left"&gt;Employees Details&lt;/h2&gt;
                        &lt;a href="create.php" class="btn btn-success pull-right"&gt;Add New Employee&lt;/a&gt;
                    &lt;/div&gt;
                    &lt;?php
                    // Include config file
                    require_once "config.php";
                    
                    // Attempt select query execution
                    $sql = "SELECT * FROM employees";
                    if($result = mysqli_query($link, $sql)){
                        if(mysqli_num_rows($result) &gt; 0){
                            echo "&lt;table class='table table-bordered table-striped'&gt;";
                                echo "&lt;thead&gt;";
                                    echo "&lt;tr&gt;";
                                        echo "&lt;th&gt;#&lt;/th&gt;";
                                        echo "&lt;th&gt;Name&lt;/th&gt;";
                                        echo "&lt;th&gt;Address&lt;/th&gt;";
                                        echo "&lt;th&gt;Salary&lt;/th&gt;";
                                        echo "&lt;th&gt;Action&lt;/th&gt;";
                                    echo "&lt;/tr&gt;";
                                echo "&lt;/thead&gt;";
                                echo "&lt;tbody&gt;";
                                while($row = mysqli_fetch_array($result)){
                                    echo "&lt;tr&gt;";
                                        echo "&lt;td&gt;" . $row['id'] . "&lt;/td&gt;";
                                        echo "&lt;td&gt;" . $row['name'] . "&lt;/td&gt;";
                                        echo "&lt;td&gt;" . $row['address'] . "&lt;/td&gt;";
                                        echo "&lt;td&gt;" . $row['salary'] . "&lt;/td&gt;";
                                        echo "&lt;td&gt;";
                                            echo "&lt;a href='read.php?id=". $row['id'] ."' title='View Record' data-toggle='tooltip'&gt;&lt;span class='glyphicon glyphicon-eye-open'&gt;&lt;/span&gt;&lt;/a&gt;";
                                            echo "&lt;a href='update.php?id=". $row['id'] ."' title='Update Record' data-toggle='tooltip'&gt;&lt;span class='glyphicon glyphicon-pencil'&gt;&lt;/span&gt;&lt;/a&gt;";
                                            echo "&lt;a href='delete.php?id=". $row['id'] ."' title='Delete Record' data-toggle='tooltip'&gt;&lt;span class='glyphicon glyphicon-trash'&gt;&lt;/span&gt;&lt;/a&gt;";
                                        echo "&lt;/td&gt;";
                                    echo "&lt;/tr&gt;";
                                }
                                echo "&lt;/tbody&gt;";                            
                            echo "&lt;/table&gt;";
                            // Free result set
                            mysqli_free_result($result);
                        } else{
                            echo "&lt;p class='lead'&gt;&lt;em&gt;No records were found.&lt;/em&gt;&lt;/p&gt;";
                        }
                    } else{
                        echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
                    }
 
                    // Close connection
                    mysqli_close($link);
                    ?&gt;
                &lt;/div&gt;
            &lt;/div&gt;        
        &lt;/div&gt;
    &lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;</code></pre>
						<pre class="syntax-highlighter line-numbers scroll xlarge hide"><code class="language-php hide-scroll">&lt;!DOCTYPE html&gt;
&lt;html lang="en"&gt;
&lt;head&gt;
    &lt;meta charset="UTF-8"&gt;
    &lt;title&gt;Dashboard&lt;/title&gt;
    &lt;link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css"&gt;
    &lt;script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"&gt;&lt;/script&gt;
    &lt;script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"&gt;&lt;/script&gt;
    &lt;style type="text/css"&gt;
        .wrapper{
            width: 650px;
            margin: 0 auto;
        }
        .page-header h2{
            margin-top: 0;
        }
        table tr td:last-child a{
            margin-right: 15px;
        }
    &lt;/style&gt;
    &lt;script type="text/javascript"&gt;
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();   
        });
    &lt;/script&gt;
&lt;/head&gt;
&lt;body&gt;
    &lt;div class="wrapper"&gt;
        &lt;div class="container-fluid"&gt;
            &lt;div class="row"&gt;
                &lt;div class="col-md-12"&gt;
                    &lt;div class="page-header clearfix"&gt;
                        &lt;h2 class="pull-left"&gt;Employees Details&lt;/h2&gt;
                        &lt;a href="create.php" class="btn btn-success pull-right"&gt;Add New Employee&lt;/a&gt;
                    &lt;/div&gt;
                    &lt;?php
                    // Include config file
                    require_once "config.php";
                    
                    // Attempt select query execution
                    $sql = "SELECT * FROM employees";
                    if($result = $mysqli-&gt;query($sql)){
                        if($result-&gt;num_rows &gt; 0){
                            echo "&lt;table class='table table-bordered table-striped'&gt;";
                                echo "&lt;thead&gt;";
                                    echo "&lt;tr&gt;";
                                        echo "&lt;th&gt;#&lt;/th&gt;";
                                        echo "&lt;th&gt;Name&lt;/th&gt;";
                                        echo "&lt;th&gt;Address&lt;/th&gt;";
                                        echo "&lt;th&gt;Salary&lt;/th&gt;";
                                        echo "&lt;th&gt;Action&lt;/th&gt;";
                                    echo "&lt;/tr&gt;";
                                echo "&lt;/thead&gt;";
                                echo "&lt;tbody&gt;";
                                while($row = $result-&gt;fetch_array()){
                                    echo "&lt;tr&gt;";
                                        echo "&lt;td&gt;" . $row['id'] . "&lt;/td&gt;";
                                        echo "&lt;td&gt;" . $row['name'] . "&lt;/td&gt;";
                                        echo "&lt;td&gt;" . $row['address'] . "&lt;/td&gt;";
                                        echo "&lt;td&gt;" . $row['salary'] . "&lt;/td&gt;";
                                        echo "&lt;td&gt;";
                                            echo "&lt;a href='read.php?id=". $row['id'] ."' title='View Record' data-toggle='tooltip'&gt;&lt;span class='glyphicon glyphicon-eye-open'&gt;&lt;/span&gt;&lt;/a&gt;";
                                            echo "&lt;a href='update.php?id=". $row['id'] ."' title='Update Record' data-toggle='tooltip'&gt;&lt;span class='glyphicon glyphicon-pencil'&gt;&lt;/span&gt;&lt;/a&gt;";
                                            echo "&lt;a href='delete.php?id=". $row['id'] ."' title='Delete Record' data-toggle='tooltip'&gt;&lt;span class='glyphicon glyphicon-trash'&gt;&lt;/span&gt;&lt;/a&gt;";
                                        echo "&lt;/td&gt;";
                                    echo "&lt;/tr&gt;";
                                }
                                echo "&lt;/tbody&gt;";                            
                            echo "&lt;/table&gt;";
                            // Free result set
                            $result-&gt;free();
                        } else{
                            echo "&lt;p class='lead'&gt;&lt;em&gt;No records were found.&lt;/em&gt;&lt;/p&gt;";
                        }
                    } else{
                        echo "ERROR: Could not able to execute $sql. " . $mysqli-&gt;error;
                    }
                    
                    // Close connection
                    $mysqli-&gt;close();
                    ?&gt;
                &lt;/div&gt;
            &lt;/div&gt;        
        &lt;/div&gt;
    &lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;</code></pre>
						<pre class="syntax-highlighter line-numbers scroll xlarge hide"><code class="language-php hide-scroll">&lt;!DOCTYPE html&gt;
&lt;html lang="en"&gt;
&lt;head&gt;
    &lt;meta charset="UTF-8"&gt;
    &lt;title&gt;Dashboard&lt;/title&gt;
    &lt;link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css"&gt;
    &lt;script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"&gt;&lt;/script&gt;
    &lt;script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"&gt;&lt;/script&gt;
    &lt;style type="text/css"&gt;
        .wrapper{
            width: 650px;
            margin: 0 auto;
        }
        .page-header h2{
            margin-top: 0;
        }
        table tr td:last-child a{
            margin-right: 15px;
        }
    &lt;/style&gt;
    &lt;script type="text/javascript"&gt;
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();   
        });
    &lt;/script&gt;
&lt;/head&gt;
&lt;body&gt;
    &lt;div class="wrapper"&gt;
        &lt;div class="container-fluid"&gt;
            &lt;div class="row"&gt;
                &lt;div class="col-md-12"&gt;
                    &lt;div class="page-header clearfix"&gt;
                        &lt;h2 class="pull-left"&gt;Employees Details&lt;/h2&gt;
                        &lt;a href="create.php" class="btn btn-success pull-right"&gt;Add New Employee&lt;/a&gt;
                    &lt;/div&gt;
                    &lt;?php
                    // Include config file
                    require_once "config.php";
                    
                    // Attempt select query execution
                    $sql = "SELECT * FROM employees";
                    if($result = $pdo-&gt;query($sql)){
                        if($result-&gt;rowCount() &gt; 0){
                            echo "&lt;table class='table table-bordered table-striped'&gt;";
                                echo "&lt;thead&gt;";
                                    echo "&lt;tr&gt;";
                                        echo "&lt;th&gt;#&lt;/th&gt;";
                                        echo "&lt;th&gt;Name&lt;/th&gt;";
                                        echo "&lt;th&gt;Address&lt;/th&gt;";
                                        echo "&lt;th&gt;Salary&lt;/th&gt;";
                                        echo "&lt;th&gt;Action&lt;/th&gt;";
                                    echo "&lt;/tr&gt;";
                                echo "&lt;/thead&gt;";
                                echo "&lt;tbody&gt;";
                                while($row = $result-&gt;fetch()){
                                    echo "&lt;tr&gt;";
                                        echo "&lt;td&gt;" . $row['id'] . "&lt;/td&gt;";
                                        echo "&lt;td&gt;" . $row['name'] . "&lt;/td&gt;";
                                        echo "&lt;td&gt;" . $row['address'] . "&lt;/td&gt;";
                                        echo "&lt;td&gt;" . $row['salary'] . "&lt;/td&gt;";
                                        echo "&lt;td&gt;";
                                            echo "&lt;a href='read.php?id=". $row['id'] ."' title='View Record' data-toggle='tooltip'&gt;&lt;span class='glyphicon glyphicon-eye-open'&gt;&lt;/span&gt;&lt;/a&gt;";
                                            echo "&lt;a href='update.php?id=". $row['id'] ."' title='Update Record' data-toggle='tooltip'&gt;&lt;span class='glyphicon glyphicon-pencil'&gt;&lt;/span&gt;&lt;/a&gt;";
                                            echo "&lt;a href='delete.php?id=". $row['id'] ."' title='Delete Record' data-toggle='tooltip'&gt;&lt;span class='glyphicon glyphicon-trash'&gt;&lt;/span&gt;&lt;/a&gt;";
                                        echo "&lt;/td&gt;";
                                    echo "&lt;/tr&gt;";
                                }
                                echo "&lt;/tbody&gt;";                            
                            echo "&lt;/table&gt;";
                            // Free result set
                            unset($result);
                        } else{
                            echo "&lt;p class='lead'&gt;&lt;em&gt;No records were found.&lt;/em&gt;&lt;/p&gt;";
                        }
                    } else{
                        echo "ERROR: Could not able to execute $sql. " . $mysqli-&gt;error;
                    }
                    
                    // Close connection
                    unset($pdo);
                    ?&gt;
                &lt;/div&gt;
            &lt;/div&gt;        
        &lt;/div&gt;
    &lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<p>Once <i>employees</i> table is populated with some records the landing page i.e. the CRUD data grid may look something like the picture shown below:</p>				
				<div class="shadow">
                    <div class="preview-box">
                        <a href="#" target="_blank">
                            <img src="../lib/images/php-mysql-crud-grid.png" width="730" height="223" alt="PHP MySQL CRUD Grid" />
                        </a>
                    </div>
                </div>
				<!--Tip Box-->
				<div class="color-box">
					<div class="shadow">
						<div class="info-tab tip-icon" title="Useful Tips"><i></i></div>
						<div class="tip-box">
							<p><strong>Tip:</strong> We've used the Bootstrap framework to make this CRUD application layout quickly and beautifully. Bootstrap is the most popular and powerful front-end framework for faster and easier responsive web development. Please, checkout the <a href="/twitter-bootstrap-tutorial/">Bootstrap tutorial</a> section to learn more about this framework.</p>
						</div>
					</div>
				</div>
				<!--End:Tip Box-->
				<hr />
				<h2>Creating the Create Page</h2>
				<p>In this section we'll build the <b>C</b>reate functionality of our CRUD application.</p>
				<p>Let's create a file named "create.php" and put the following code inside it. It will generate a web form that can be used to insert records in the <i>employees</i> table.</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox multi-style-mode">
                        <div class="codebox-title">
                        	<h4>Example</h4>
                            <div class="code-style">
                            	<span class="active" data-target="0" data-url="create" title="Show Example Code in MySQLi Procedural Style">Procedural</span> 
                                <span data-target="1" data-url="create-oo-format" title="Show Example Code in MySQLi Object Oriented Style">Object Oriented</span> 
                                <span data-target="2" data-url="create-pdo-format" title="Show Example Code in PDO Style">PDO</span>
                            </div>
                        	<a href="../examples/bin/download-source.php?topic=php&amp;file=create" target="_top" class="download-btn" title="Download Source Code"><span>Download</span></a>
                            <span class="box-size"><i title="Maximize"></i></span>
                        </div>
                        <pre class="syntax-highlighter line-numbers scroll xlarge"><code class="language-php">&lt;?php
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$name = $address = $salary = "";
$name_err = $address_err = $salary_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Validate name
    $input_name = trim($_POST["name"]);
    if(empty($input_name)){
        $name_err = "Please enter a name.";
    } elseif(!filter_var($input_name, FILTER_VALIDATE_REGEXP, array("options"=&gt;array("regexp"=&gt;"/^[a-zA-Z\s]+$/")))){
        $name_err = "Please enter a valid name.";
    } else{
        $name = $input_name;
    }
    
    // Validate address
    $input_address = trim($_POST["address"]);
    if(empty($input_address)){
        $address_err = "Please enter an address.";     
    } else{
        $address = $input_address;
    }
    
    // Validate salary
    $input_salary = trim($_POST["salary"]);
    if(empty($input_salary)){
        $salary_err = "Please enter the salary amount.";     
    } elseif(!ctype_digit($input_salary)){
        $salary_err = "Please enter a positive integer value.";
    } else{
        $salary = $input_salary;
    }
    
    // Check input errors before inserting in database
    if(empty($name_err) && empty($address_err) && empty($salary_err)){
        // Prepare an insert statement
        $sql = "INSERT INTO employees (name, address, salary) VALUES (?, ?, ?)";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "sss", $param_name, $param_address, $param_salary);
            
            // Set parameters
            $param_name = $name;
            $param_address = $address;
            $param_salary = $salary;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records created successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($link);
}
?&gt;
 
&lt;!DOCTYPE html&gt;
&lt;html lang="en"&gt;
&lt;head&gt;
    &lt;meta charset="UTF-8"&gt;
    &lt;title&gt;Create Record&lt;/title&gt;
    &lt;link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css"&gt;
    &lt;style type="text/css"&gt;
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    &lt;/style&gt;
&lt;/head&gt;
&lt;body&gt;
    &lt;div class="wrapper"&gt;
        &lt;div class="container-fluid"&gt;
            &lt;div class="row"&gt;
                &lt;div class="col-md-12"&gt;
                    &lt;div class="page-header"&gt;
                        &lt;h2&gt;Create Record&lt;/h2&gt;
                    &lt;/div&gt;
                    &lt;p&gt;Please fill this form and submit to add employee record to the database.&lt;/p&gt;
                    &lt;form action="&lt;?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?&gt;" method="post"&gt;
                        &lt;div class="form-group &lt;?php echo (!empty($name_err)) ? 'has-error' : ''; ?&gt;"&gt;
                            &lt;label&gt;Name&lt;/label&gt;
                            &lt;input type="text" name="name" class="form-control" value="&lt;?php echo $name; ?&gt;"&gt;
                            &lt;span class="help-block"&gt;&lt;?php echo $name_err;?&gt;&lt;/span&gt;
                        &lt;/div&gt;
                        &lt;div class="form-group &lt;?php echo (!empty($address_err)) ? 'has-error' : ''; ?&gt;"&gt;
                            &lt;label&gt;Address&lt;/label&gt;
                            &lt;textarea name="address" class="form-control"&gt;&lt;?php echo $address; ?&gt;&lt;/textarea&gt;
                            &lt;span class="help-block"&gt;&lt;?php echo $address_err;?&gt;&lt;/span&gt;
                        &lt;/div&gt;
                        &lt;div class="form-group &lt;?php echo (!empty($salary_err)) ? 'has-error' : ''; ?&gt;"&gt;
                            &lt;label&gt;Salary&lt;/label&gt;
                            &lt;input type="text" name="salary" class="form-control" value="&lt;?php echo $salary; ?&gt;"&gt;
                            &lt;span class="help-block"&gt;&lt;?php echo $salary_err;?&gt;&lt;/span&gt;
                        &lt;/div&gt;
                        &lt;input type="submit" class="btn btn-primary" value="Submit"&gt;
                        &lt;a href="index.php" class="btn btn-default"&gt;Cancel&lt;/a&gt;
                    &lt;/form&gt;
                &lt;/div&gt;
            &lt;/div&gt;        
        &lt;/div&gt;
    &lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;</code></pre>
						<pre class="syntax-highlighter line-numbers scroll xlarge hide"><code class="language-php">&lt;?php
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$name = $address = $salary = "";
$name_err = $address_err = $salary_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Validate name
    $input_name = trim($_POST["name"]);
    if(empty($input_name)){
        $name_err = "Please enter a name.";
    } elseif(!filter_var($input_name, FILTER_VALIDATE_REGEXP, array("options"=&gt;array("regexp"=&gt;"/^[a-zA-Z\s]+$/")))){
        $name_err = "Please enter a valid name.";
    } else{
        $name = $input_name;
    }
    
    // Validate address
    $input_address = trim($_POST["address"]);
    if(empty($input_address)){
        $address_err = "Please enter an address.";     
    } else{
        $address = $input_address;
    }
    
    // Validate salary
    $input_salary = trim($_POST["salary"]);
    if(empty($input_salary)){
        $salary_err = "Please enter the salary amount.";     
    } elseif(!ctype_digit($input_salary)){
        $salary_err = "Please enter a positive integer value.";
    } else{
        $salary = $input_salary;
    }
    
    // Check input errors before inserting in database
    if(empty($name_err) && empty($address_err) && empty($salary_err)){
        // Prepare an insert statement
        $sql = "INSERT INTO employees (name, address, salary) VALUES (?, ?, ?)";
 
        if($stmt = $mysqli-&gt;prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt-&gt;bind_param("sss", $param_name, $param_address, $param_salary);
            
            // Set parameters
            $param_name = $name;
            $param_address = $address;
            $param_salary = $salary;
            
            // Attempt to execute the prepared statement
            if($stmt-&gt;execute()){
                // Records created successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        $stmt-&gt;close();
    }
    
    // Close connection
    $mysqli-&gt;close();
}
?&gt;
 
&lt;!DOCTYPE html&gt;
&lt;html lang="en"&gt;
&lt;head&gt;
    &lt;meta charset="UTF-8"&gt;
    &lt;title&gt;Create Record&lt;/title&gt;
    &lt;link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css"&gt;
    &lt;style type="text/css"&gt;
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    &lt;/style&gt;
&lt;/head&gt;
&lt;body&gt;
    &lt;div class="wrapper"&gt;
        &lt;div class="container-fluid"&gt;
            &lt;div class="row"&gt;
                &lt;div class="col-md-12"&gt;
                    &lt;div class="page-header"&gt;
                        &lt;h2&gt;Create Record&lt;/h2&gt;
                    &lt;/div&gt;
                    &lt;p&gt;Please fill this form and submit to add employee record to the database.&lt;/p&gt;
                    &lt;form action="&lt;?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?&gt;" method="post"&gt;
                        &lt;div class="form-group &lt;?php echo (!empty($name_err)) ? 'has-error' : ''; ?&gt;"&gt;
                            &lt;label&gt;Name&lt;/label&gt;
                            &lt;input type="text" name="name" class="form-control" value="&lt;?php echo $name; ?&gt;"&gt;
                            &lt;span class="help-block"&gt;&lt;?php echo $name_err;?&gt;&lt;/span&gt;
                        &lt;/div&gt;
                        &lt;div class="form-group &lt;?php echo (!empty($address_err)) ? 'has-error' : ''; ?&gt;"&gt;
                            &lt;label&gt;Address&lt;/label&gt;
                            &lt;textarea name="address" class="form-control"&gt;&lt;?php echo $address; ?&gt;&lt;/textarea&gt;
                            &lt;span class="help-block"&gt;&lt;?php echo $address_err;?&gt;&lt;/span&gt;
                        &lt;/div&gt;
                        &lt;div class="form-group &lt;?php echo (!empty($salary_err)) ? 'has-error' : ''; ?&gt;"&gt;
                            &lt;label&gt;Salary&lt;/label&gt;
                            &lt;input type="text" name="salary" class="form-control" value="&lt;?php echo $salary; ?&gt;"&gt;
                            &lt;span class="help-block"&gt;&lt;?php echo $salary_err;?&gt;&lt;/span&gt;
                        &lt;/div&gt;
                        &lt;input type="submit" class="btn btn-primary" value="Submit"&gt;
                        &lt;a href="index.php" class="btn btn-default"&gt;Cancel&lt;/a&gt;
                    &lt;/form&gt;
                &lt;/div&gt;
            &lt;/div&gt;        
        &lt;/div&gt;
    &lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;</code></pre>
						<pre class="syntax-highlighter line-numbers scroll xlarge hide"><code class="language-php">&lt;?php
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$name = $address = $salary = "";
$name_err = $address_err = $salary_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Validate name
    $input_name = trim($_POST["name"]);
    if(empty($input_name)){
        $name_err = "Please enter a name.";
    } elseif(!filter_var($input_name, FILTER_VALIDATE_REGEXP, array("options"=&gt;array("regexp"=&gt;"/^[a-zA-Z\s]+$/")))){
        $name_err = "Please enter a valid name.";
    } else{
        $name = $input_name;
    }
    
    // Validate address
    $input_address = trim($_POST["address"]);
    if(empty($input_address)){
        $address_err = "Please enter an address.";     
    } else{
        $address = $input_address;
    }
    
    // Validate salary
    $input_salary = trim($_POST["salary"]);
    if(empty($input_salary)){
        $salary_err = "Please enter the salary amount.";     
    } elseif(!ctype_digit($input_salary)){
        $salary_err = "Please enter a positive integer value.";
    } else{
        $salary = $input_salary;
    }
    
    // Check input errors before inserting in database
    if(empty($name_err) && empty($address_err) && empty($salary_err)){
        // Prepare an insert statement
        $sql = "INSERT INTO employees (name, address, salary) VALUES (:name, :address, :salary)";
 
        if($stmt = $pdo-&gt;prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt-&gt;bindParam(":name", $param_name);
            $stmt-&gt;bindParam(":address", $param_address);
            $stmt-&gt;bindParam(":salary", $param_salary);
            
            // Set parameters
            $param_name = $name;
            $param_address = $address;
            $param_salary = $salary;
            
            // Attempt to execute the prepared statement
            if($stmt-&gt;execute()){
                // Records created successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        unset($stmt);
    }
    
    // Close connection
    unset($pdo);
}
?&gt;
 
&lt;!DOCTYPE html&gt;
&lt;html lang="en"&gt;
&lt;head&gt;
    &lt;meta charset="UTF-8"&gt;
    &lt;title&gt;Create Record&lt;/title&gt;
    &lt;link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css"&gt;
    &lt;style type="text/css"&gt;
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    &lt;/style&gt;
&lt;/head&gt;
&lt;body&gt;
    &lt;div class="wrapper"&gt;
        &lt;div class="container-fluid"&gt;
            &lt;div class="row"&gt;
                &lt;div class="col-md-12"&gt;
                    &lt;div class="page-header"&gt;
                        &lt;h2&gt;Create Record&lt;/h2&gt;
                    &lt;/div&gt;
                    &lt;p&gt;Please fill this form and submit to add employee record to the database.&lt;/p&gt;
                    &lt;form action="&lt;?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?&gt;" method="post"&gt;
                        &lt;div class="form-group &lt;?php echo (!empty($name_err)) ? 'has-error' : ''; ?&gt;"&gt;
                            &lt;label&gt;Name&lt;/label&gt;
                            &lt;input type="text" name="name" class="form-control" value="&lt;?php echo $name; ?&gt;"&gt;
                            &lt;span class="help-block"&gt;&lt;?php echo $name_err;?&gt;&lt;/span&gt;
                        &lt;/div&gt;
                        &lt;div class="form-group &lt;?php echo (!empty($address_err)) ? 'has-error' : ''; ?&gt;"&gt;
                            &lt;label&gt;Address&lt;/label&gt;
                            &lt;textarea name="address" class="form-control"&gt;&lt;?php echo $address; ?&gt;&lt;/textarea&gt;
                            &lt;span class="help-block"&gt;&lt;?php echo $address_err;?&gt;&lt;/span&gt;
                        &lt;/div&gt;
                        &lt;div class="form-group &lt;?php echo (!empty($salary_err)) ? 'has-error' : ''; ?&gt;"&gt;
                            &lt;label&gt;Salary&lt;/label&gt;
                            &lt;input type="text" name="salary" class="form-control" value="&lt;?php echo $salary; ?&gt;"&gt;
                            &lt;span class="help-block"&gt;&lt;?php echo $salary_err;?&gt;&lt;/span&gt;
                        &lt;/div&gt;
                        &lt;input type="submit" class="btn btn-primary" value="Submit"&gt;
                        &lt;a href="index.php" class="btn btn-default"&gt;Cancel&lt;/a&gt;
                    &lt;/form&gt;
                &lt;/div&gt;
            &lt;/div&gt;        
        &lt;/div&gt;
    &lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<p>The same "create.php" file will display the HTML form and process the submitted form data. It will also perform basic validation on user inputs (<i>line no-11 to 37</i>) before saving the data.</p>
				<hr />
				<h2>Creating the Read Page</h2>
				<p>Now it's time to build the <b>R</b>ead functionality of our CRUD application.</p>
				<p>Let's create a file named "create.php" and put the following code inside it. It will simply retrieve the records from the <i>employees</i> table based the id attribute of the employee.</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox multi-style-mode">
                        <div class="codebox-title">
                        	<h4>Example</h4>
                            <div class="code-style">
                            	<span class="active" data-target="0" data-url="read" title="Show Example Code in MySQLi Procedural Style">Procedural</span> 
                                <span data-target="1" data-url="read-oo-format" title="Show Example Code in MySQLi Object Oriented Style">Object Oriented</span> 
                                <span data-target="2" data-url="read-pdo-format" title="Show Example Code in PDO Style">PDO</span>
                            </div>
                        	<a href="../examples/bin/download-source.php?topic=php&amp;file=read" target="_top" class="download-btn" title="Download Source Code"><span>Download</span></a>
                            <span class="box-size"><i title="Maximize"></i></span>
                        </div>
                        <pre class="syntax-highlighter line-numbers scroll xlarge"><code class="language-php">&lt;?php
// Check existence of id parameter before processing further
if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
    // Include config file
    require_once "config.php";
    
    // Prepare a select statement
    $sql = "SELECT * FROM employees WHERE id = ?";
    
    if($stmt = mysqli_prepare($link, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "i", $param_id);
        
        // Set parameters
        $param_id = trim($_GET["id"]);
        
        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){
            $result = mysqli_stmt_get_result($stmt);
    
            if(mysqli_num_rows($result) == 1){
                /* Fetch result row as an associative array. Since the result set contains only one row, we don't need to use while loop */
                $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                
                // Retrieve individual field value
                $name = $row["name"];
                $address = $row["address"];
                $salary = $row["salary"];
            } else{
                // URL doesn't contain valid id parameter. Redirect to error page
                header("location: error.php");
                exit();
            }
            
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }
    }
     
    // Close statement
    mysqli_stmt_close($stmt);
    
    // Close connection
    mysqli_close($link);
} else{
    // URL doesn't contain id parameter. Redirect to error page
    header("location: error.php");
    exit();
}
?&gt;
&lt;!DOCTYPE html&gt;
&lt;html lang="en"&gt;
&lt;head&gt;
    &lt;meta charset="UTF-8"&gt;
    &lt;title&gt;View Record&lt;/title&gt;
    &lt;link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css"&gt;
    &lt;style type="text/css"&gt;
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    &lt;/style&gt;
&lt;/head&gt;
&lt;body&gt;
    &lt;div class="wrapper"&gt;
        &lt;div class="container-fluid"&gt;
            &lt;div class="row"&gt;
                &lt;div class="col-md-12"&gt;
                    &lt;div class="page-header"&gt;
                        &lt;h1&gt;View Record&lt;/h1&gt;
                    &lt;/div&gt;
                    &lt;div class="form-group"&gt;
                        &lt;label&gt;Name&lt;/label&gt;
                        &lt;p class="form-control-static"&gt;&lt;?php echo $row["name"]; ?&gt;&lt;/p&gt;
                    &lt;/div&gt;
                    &lt;div class="form-group"&gt;
                        &lt;label&gt;Address&lt;/label&gt;
                        &lt;p class="form-control-static"&gt;&lt;?php echo $row["address"]; ?&gt;&lt;/p&gt;
                    &lt;/div&gt;
                    &lt;div class="form-group"&gt;
                        &lt;label&gt;Salary&lt;/label&gt;
                        &lt;p class="form-control-static"&gt;&lt;?php echo $row["salary"]; ?&gt;&lt;/p&gt;
                    &lt;/div&gt;
                    &lt;p&gt;&lt;a href="index.php" class="btn btn-primary"&gt;Back&lt;/a&gt;&lt;/p&gt;
                &lt;/div&gt;
            &lt;/div&gt;        
        &lt;/div&gt;
    &lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;</code></pre>
						<pre class="syntax-highlighter line-numbers scroll xlarge hide"><code class="language-php">&lt;?php
// Check existence of id parameter before processing further
if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
    // Include config file
    require_once "config.php";
    
    // Prepare a select statement
    $sql = "SELECT * FROM employees WHERE id = ?";
    
    if($stmt = $mysqli-&gt;prepare($sql)){
        // Bind variables to the prepared statement as parameters
        $stmt-&gt;bind_param("i", $param_id);
        
        // Set parameters
        $param_id = trim($_GET["id"]);
        
        // Attempt to execute the prepared statement
        if($stmt-&gt;execute()){
            $result = $stmt-&gt;get_result();
            
            if($result-&gt;num_rows == 1){
                /* Fetch result row as an associative array. Since the result set contains only one row, we don't need to use while loop */
                $row = $result-&gt;fetch_array(MYSQLI_ASSOC);
                
                // Retrieve individual field value
                $name = $row["name"];
                $address = $row["address"];
                $salary = $row["salary"];
            } else{
                // URL doesn't contain valid id parameter. Redirect to error page
                header("location: error.php");
                exit();
            }
            
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }
    }
     
    // Close statement
    $stmt-&gt;close();
    
    // Close connection
    $mysqli-&gt;close();
} else{
    // URL doesn't contain id parameter. Redirect to error page
    header("location: error.php");
    exit();
}
?&gt;
&lt;!DOCTYPE html&gt;
&lt;html lang="en"&gt;
&lt;head&gt;
    &lt;meta charset="UTF-8"&gt;
    &lt;title&gt;View Record&lt;/title&gt;
    &lt;link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css"&gt;
    &lt;style type="text/css"&gt;
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    &lt;/style&gt;
&lt;/head&gt;
&lt;body&gt;
    &lt;div class="wrapper"&gt;
        &lt;div class="container-fluid"&gt;
            &lt;div class="row"&gt;
                &lt;div class="col-md-12"&gt;
                    &lt;div class="page-header"&gt;
                        &lt;h1&gt;View Record&lt;/h1&gt;
                    &lt;/div&gt;
                    &lt;div class="form-group"&gt;
                        &lt;label&gt;Name&lt;/label&gt;
                        &lt;p class="form-control-static"&gt;&lt;?php echo $row["name"]; ?&gt;&lt;/p&gt;
                    &lt;/div&gt;
                    &lt;div class="form-group"&gt;
                        &lt;label&gt;Address&lt;/label&gt;
                        &lt;p class="form-control-static"&gt;&lt;?php echo $row["address"]; ?&gt;&lt;/p&gt;
                    &lt;/div&gt;
                    &lt;div class="form-group"&gt;
                        &lt;label&gt;Salary&lt;/label&gt;
                        &lt;p class="form-control-static"&gt;&lt;?php echo $row["salary"]; ?&gt;&lt;/p&gt;
                    &lt;/div&gt;
                    &lt;p&gt;&lt;a href="index.php" class="btn btn-primary"&gt;Back&lt;/a&gt;&lt;/p&gt;
                &lt;/div&gt;
            &lt;/div&gt;        
        &lt;/div&gt;
    &lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;</code></pre>
						<pre class="syntax-highlighter line-numbers scroll xlarge hide"><code class="language-php">&lt;?php
// Check existence of id parameter before processing further
if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
    // Include config file
    require_once "config.php";
    
    // Prepare a select statement
    $sql = "SELECT * FROM employees WHERE id = :id";
    
    if($stmt = $pdo-&gt;prepare($sql)){
        // Bind variables to the prepared statement as parameters
        $stmt-&gt;bindParam(":id", $param_id);
        
        // Set parameters
        $param_id = trim($_GET["id"]);
        
        // Attempt to execute the prepared statement
        if($stmt-&gt;execute()){
            if($stmt-&gt;rowCount() == 1){
                /* Fetch result row as an associative array. Since the result set contains only one row, we don't need to use while loop */
                $row = $stmt-&gt;fetch(PDO::FETCH_ASSOC);
                
                // Retrieve individual field value
                $name = $row["name"];
                $address = $row["address"];
                $salary = $row["salary"];
            } else{
                // URL doesn't contain valid id parameter. Redirect to error page
                header("location: error.php");
                exit();
            }
            
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }
    }
     
    // Close statement
    unset($stmt);
    
    // Close connection
    unset($pdo);
} else{
    // URL doesn't contain id parameter. Redirect to error page
    header("location: error.php");
    exit();
}
?&gt;
&lt;!DOCTYPE html&gt;
&lt;html lang="en"&gt;
&lt;head&gt;
    &lt;meta charset="UTF-8"&gt;
    &lt;title&gt;View Record&lt;/title&gt;
    &lt;link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css"&gt;
    &lt;style type="text/css"&gt;
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    &lt;/style&gt;
&lt;/head&gt;
&lt;body&gt;
    &lt;div class="wrapper"&gt;
        &lt;div class="container-fluid"&gt;
            &lt;div class="row"&gt;
                &lt;div class="col-md-12"&gt;
                    &lt;div class="page-header"&gt;
                        &lt;h1&gt;View Record&lt;/h1&gt;
                    &lt;/div&gt;
                    &lt;div class="form-group"&gt;
                        &lt;label&gt;Name&lt;/label&gt;
                        &lt;p class="form-control-static"&gt;&lt;?php echo $row["name"]; ?&gt;&lt;/p&gt;
                    &lt;/div&gt;
                    &lt;div class="form-group"&gt;
                        &lt;label&gt;Address&lt;/label&gt;
                        &lt;p class="form-control-static"&gt;&lt;?php echo $row["address"]; ?&gt;&lt;/p&gt;
                    &lt;/div&gt;
                    &lt;div class="form-group"&gt;
                        &lt;label&gt;Salary&lt;/label&gt;
                        &lt;p class="form-control-static"&gt;&lt;?php echo $row["salary"]; ?&gt;&lt;/p&gt;
                    &lt;/div&gt;
                    &lt;p&gt;&lt;a href="index.php" class="btn btn-primary"&gt;Back&lt;/a&gt;&lt;/p&gt;
                &lt;/div&gt;
            &lt;/div&gt;        
        &lt;/div&gt;
    &lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<hr />
				<h2>Creating the Update Page</h2>
				<p>Similarly, we can build the <b>U</b>pdate functionality of our CRUD application.</p>
				<p>Let's create a file named "update.php" and put the following code inside it. It will update the existing records in the <i>employees</i> table based the id attribute of the employee.</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox multi-style-mode">
                        <div class="codebox-title">
                        	<h4>Example</h4>
                            <div class="code-style">
                            	<span class="active" data-target="0" data-url="update" title="Show Example Code in MySQLi Procedural Style">Procedural</span> 
                                <span data-target="1" data-url="update-oo-format" title="Show Example Code in MySQLi Object Oriented Style">Object Oriented</span> 
                                <span data-target="2" data-url="update-pdo-format" title="Show Example Code in PDO Style">PDO</span>
                            </div>
                        	<a href="../examples/bin/download-source.php?topic=php&amp;file=update" target="_top" class="download-btn" title="Download Source Code"><span>Download</span></a>
                            <span class="box-size"><i title="Maximize"></i></span>
                        </div>
                        <pre class="syntax-highlighter line-numbers scroll xlarge"><code class="language-php">&lt;?php
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$name = $address = $salary = "";
$name_err = $address_err = $salary_err = "";
 
// Processing form data when form is submitted
if(isset($_POST["id"]) && !empty($_POST["id"])){
    // Get hidden input value
    $id = $_POST["id"];
    
    // Validate name
    $input_name = trim($_POST["name"]);
    if(empty($input_name)){
        $name_err = "Please enter a name.";
    } elseif(!filter_var($input_name, FILTER_VALIDATE_REGEXP, array("options"=&gt;array("regexp"=&gt;"/^[a-zA-Z\s]+$/")))){
        $name_err = "Please enter a valid name.";
    } else{
        $name = $input_name;
    }
    
    // Validate address address
    $input_address = trim($_POST["address"]);
    if(empty($input_address)){
        $address_err = "Please enter an address.";     
    } else{
        $address = $input_address;
    }
    
    // Validate salary
    $input_salary = trim($_POST["salary"]);
    if(empty($input_salary)){
        $salary_err = "Please enter the salary amount.";     
    } elseif(!ctype_digit($input_salary)){
        $salary_err = "Please enter a positive integer value.";
    } else{
        $salary = $input_salary;
    }
    
    // Check input errors before inserting in database
    if(empty($name_err) && empty($address_err) && empty($salary_err)){
        // Prepare an update statement
        $sql = "UPDATE employees SET name=?, address=?, salary=? WHERE id=?";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "sssi", $param_name, $param_address, $param_salary, $param_id);
            
            // Set parameters
            $param_name = $name;
            $param_address = $address;
            $param_salary = $salary;
            $param_id = $id;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records updated successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($link);
} else{
    // Check existence of id parameter before processing further
    if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
        // Get URL parameter
        $id =  trim($_GET["id"]);
        
        // Prepare a select statement
        $sql = "SELECT * FROM employees WHERE id = ?";
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "i", $param_id);
            
            // Set parameters
            $param_id = $id;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                $result = mysqli_stmt_get_result($stmt);
    
                if(mysqli_num_rows($result) == 1){
                    /* Fetch result row as an associative array. Since the result set contains only one row, we don't need to use while loop */
                    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                    
                    // Retrieve individual field value
                    $name = $row["name"];
                    $address = $row["address"];
                    $salary = $row["salary"];
                } else{
                    // URL doesn't contain valid id. Redirect to error page
                    header("location: error.php");
                    exit();
                }
                
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
        
        // Close statement
        mysqli_stmt_close($stmt);
        
        // Close connection
        mysqli_close($link);
    }  else{
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}
?&gt;
 
&lt;!DOCTYPE html&gt;
&lt;html lang="en"&gt;
&lt;head&gt;
    &lt;meta charset="UTF-8"&gt;
    &lt;title&gt;Update Record&lt;/title&gt;
    &lt;link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css"&gt;
    &lt;style type="text/css"&gt;
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    &lt;/style&gt;
&lt;/head&gt;
&lt;body&gt;
    &lt;div class="wrapper"&gt;
        &lt;div class="container-fluid"&gt;
            &lt;div class="row"&gt;
                &lt;div class="col-md-12"&gt;
                    &lt;div class="page-header"&gt;
                        &lt;h2&gt;Update Record&lt;/h2&gt;
                    &lt;/div&gt;
                    &lt;p&gt;Please edit the input values and submit to update the record.&lt;/p&gt;
                    &lt;form action="&lt;?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?&gt;" method="post"&gt;
                        &lt;div class="form-group &lt;?php echo (!empty($name_err)) ? 'has-error' : ''; ?&gt;"&gt;
                            &lt;label&gt;Name&lt;/label&gt;
                            &lt;input type="text" name="name" class="form-control" value="&lt;?php echo $name; ?&gt;"&gt;
                            &lt;span class="help-block"&gt;&lt;?php echo $name_err;?&gt;&lt;/span&gt;
                        &lt;/div&gt;
                        &lt;div class="form-group &lt;?php echo (!empty($address_err)) ? 'has-error' : ''; ?&gt;"&gt;
                            &lt;label&gt;Address&lt;/label&gt;
                            &lt;textarea name="address" class="form-control"&gt;&lt;?php echo $address; ?&gt;&lt;/textarea&gt;
                            &lt;span class="help-block"&gt;&lt;?php echo $address_err;?&gt;&lt;/span&gt;
                        &lt;/div&gt;
                        &lt;div class="form-group &lt;?php echo (!empty($salary_err)) ? 'has-error' : ''; ?&gt;"&gt;
                            &lt;label&gt;Salary&lt;/label&gt;
                            &lt;input type="text" name="salary" class="form-control" value="&lt;?php echo $salary; ?&gt;"&gt;
                            &lt;span class="help-block"&gt;&lt;?php echo $salary_err;?&gt;&lt;/span&gt;
                        &lt;/div&gt;
                        &lt;input type="hidden" name="id" value="&lt;?php echo $id; ?&gt;"/&gt;
                        &lt;input type="submit" class="btn btn-primary" value="Submit"&gt;
                        &lt;a href="index.php" class="btn btn-default"&gt;Cancel&lt;/a&gt;
                    &lt;/form&gt;
                &lt;/div&gt;
            &lt;/div&gt;        
        &lt;/div&gt;
    &lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;</code></pre>
						<pre class="syntax-highlighter line-numbers scroll xlarge hide"><code class="language-php">&lt;?php
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$name = $address = $salary = "";
$name_err = $address_err = $salary_err = "";
 
// Processing form data when form is submitted
if(isset($_POST["id"]) && !empty($_POST["id"])){
    // Get hidden input value
    $id = $_POST["id"];
    
    // Validate name
    $input_name = trim($_POST["name"]);
    if(empty($input_name)){
        $name_err = "Please enter a name.";
    } elseif(!filter_var($input_name, FILTER_VALIDATE_REGEXP, array("options"=&gt;array("regexp"=&gt;"/^[a-zA-Z\s]+$/")))){
        $name_err = "Please enter a valid name.";
    } else{
        $name = $input_name;
    }
    
    // Validate address address
    $input_address = trim($_POST["address"]);
    if(empty($input_address)){
        $address_err = "Please enter an address.";     
    } else{
        $address = $input_address;
    }
    
    // Validate salary
    $input_salary = trim($_POST["salary"]);
    if(empty($input_salary)){
        $salary_err = "Please enter the salary amount.";     
    } elseif(!ctype_digit($input_salary)){
        $salary_err = "Please enter a positive integer value.";
    } else{
        $salary = $input_salary;
    }
    
    // Check input errors before inserting in database
    if(empty($name_err) && empty($address_err) && empty($salary_err)){
        // Prepare an update statement
        $sql = "UPDATE employees SET name=?, address=?, salary=? WHERE id=?";
 
        if($stmt = $mysqli-&gt;prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt-&gt;bind_param("sssi", $param_name, $param_address, $param_salary, $param_id);
            
            // Set parameters
            $param_name = $name;
            $param_address = $address;
            $param_salary = $salary;
            $param_id = $id;
            
            // Attempt to execute the prepared statement
            if($stmt-&gt;execute()){
                // Records updated successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        $stmt-&gt;close();
    }
    
    // Close connection
    $mysqli-&gt;close();
} else{
    // Check existence of id parameter before processing further
    if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
        // Get URL parameter
        $id =  trim($_GET["id"]);
        
        // Prepare a select statement
        $sql = "SELECT * FROM employees WHERE id = ?";
        if($stmt = $mysqli-&gt;prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt-&gt;bind_param("i", $param_id);
            
            // Set parameters
            $param_id = $id;
            
            // Attempt to execute the prepared statement
            if($stmt-&gt;execute()){
                $result = $stmt-&gt;get_result();
                
                if($result-&gt;num_rows == 1){
                    /* Fetch result row as an associative array. Since the result set contains only one row, we don't need to use while loop */
                    $row = $result-&gt;fetch_array(MYSQLI_ASSOC);
                    
                    // Retrieve individual field value
                    $name = $row["name"];
                    $address = $row["address"];
                    $salary = $row["salary"];
                } else{
                    // URL doesn't contain valid id. Redirect to error page
                    header("location: error.php");
                    exit();
                }
                
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
        
        // Close statement
        $stmt-&gt;close();
        
        // Close connection
        $mysqli-&gt;close();
    }  else{
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}
?&gt;
 
&lt;!DOCTYPE html&gt;
&lt;html lang="en"&gt;
&lt;head&gt;
    &lt;meta charset="UTF-8"&gt;
    &lt;title&gt;Update Record&lt;/title&gt;
    &lt;link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css"&gt;
    &lt;style type="text/css"&gt;
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    &lt;/style&gt;
&lt;/head&gt;
&lt;body&gt;
    &lt;div class="wrapper"&gt;
        &lt;div class="container-fluid"&gt;
            &lt;div class="row"&gt;
                &lt;div class="col-md-12"&gt;
                    &lt;div class="page-header"&gt;
                        &lt;h2&gt;Update Record&lt;/h2&gt;
                    &lt;/div&gt;
                    &lt;p&gt;Please edit the input values and submit to update the record.&lt;/p&gt;
                    &lt;form action="&lt;?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?&gt;" method="post"&gt;
                        &lt;div class="form-group &lt;?php echo (!empty($name_err)) ? 'has-error' : ''; ?&gt;"&gt;
                            &lt;label&gt;Name&lt;/label&gt;
                            &lt;input type="text" name="name" class="form-control" value="&lt;?php echo $name; ?&gt;"&gt;
                            &lt;span class="help-block"&gt;&lt;?php echo $name_err;?&gt;&lt;/span&gt;
                        &lt;/div&gt;
                        &lt;div class="form-group &lt;?php echo (!empty($address_err)) ? 'has-error' : ''; ?&gt;"&gt;
                            &lt;label&gt;Address&lt;/label&gt;
                            &lt;textarea name="address" class="form-control"&gt;&lt;?php echo $address; ?&gt;&lt;/textarea&gt;
                            &lt;span class="help-block"&gt;&lt;?php echo $address_err;?&gt;&lt;/span&gt;
                        &lt;/div&gt;
                        &lt;div class="form-group &lt;?php echo (!empty($salary_err)) ? 'has-error' : ''; ?&gt;"&gt;
                            &lt;label&gt;Salary&lt;/label&gt;
                            &lt;input type="text" name="salary" class="form-control" value="&lt;?php echo $salary; ?&gt;"&gt;
                            &lt;span class="help-block"&gt;&lt;?php echo $salary_err;?&gt;&lt;/span&gt;
                        &lt;/div&gt;
                        &lt;input type="hidden" name="id" value="&lt;?php echo $id; ?&gt;"/&gt;
                        &lt;input type="submit" class="btn btn-primary" value="Submit"&gt;
                        &lt;a href="index.php" class="btn btn-default"&gt;Cancel&lt;/a&gt;
                    &lt;/form&gt;
                &lt;/div&gt;
            &lt;/div&gt;        
        &lt;/div&gt;
    &lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;</code></pre>
						<pre class="syntax-highlighter line-numbers scroll xlarge hide"><code class="language-php">&lt;?php
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$name = $address = $salary = "";
$name_err = $address_err = $salary_err = "";
 
// Processing form data when form is submitted
if(isset($_POST["id"]) && !empty($_POST["id"])){
    // Get hidden input value
    $id = $_POST["id"];
    
    // Validate name
    $input_name = trim($_POST["name"]);
    if(empty($input_name)){
        $name_err = "Please enter a name.";
    } elseif(!filter_var($input_name, FILTER_VALIDATE_REGEXP, array("options"=&gt;array("regexp"=&gt;"/^[a-zA-Z\s]+$/")))){
        $name_err = "Please enter a valid name.";
    } else{
        $name = $input_name;
    }
    
    // Validate address address
    $input_address = trim($_POST["address"]);
    if(empty($input_address)){
        $address_err = "Please enter an address.";     
    } else{
        $address = $input_address;
    }
    
    // Validate salary
    $input_salary = trim($_POST["salary"]);
    if(empty($input_salary)){
        $salary_err = "Please enter the salary amount.";     
    } elseif(!ctype_digit($input_salary)){
        $salary_err = "Please enter a positive integer value.";
    } else{
        $salary = $input_salary;
    }
    
    // Check input errors before inserting in database
    if(empty($name_err) && empty($address_err) && empty($salary_err)){
        // Prepare an update statement
        $sql = "UPDATE employees SET name=:name, address=:address, salary=:salary WHERE id=:id";
 
        if($stmt = $pdo-&gt;prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt-&gt;bindParam(":name", $param_name);
            $stmt-&gt;bindParam(":address", $param_address);
            $stmt-&gt;bindParam(":salary", $param_salary);
            $stmt-&gt;bindParam(":id", $param_id);
            
            // Set parameters
            $param_name = $name;
            $param_address = $address;
            $param_salary = $salary;
            $param_id = $id;
            
            // Attempt to execute the prepared statement
            if($stmt-&gt;execute()){
                // Records updated successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        unset($stmt);
    }
    
    // Close connection
    unset($pdo);
} else{
    // Check existence of id parameter before processing further
    if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
        // Get URL parameter
        $id =  trim($_GET["id"]);
        
        // Prepare a select statement
        $sql = "SELECT * FROM employees WHERE id = :id";
        if($stmt = $pdo-&gt;prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt-&gt;bindParam(":id", $param_id);
            
            // Set parameters
            $param_id = $id;
            
            // Attempt to execute the prepared statement
            if($stmt-&gt;execute()){
                if($stmt-&gt;rowCount() == 1){
                    /* Fetch result row as an associative array. Since the result set contains only one row, we don't need to use while loop */
                    $row = $stmt-&gt;fetch(PDO::FETCH_ASSOC);
                
                    // Retrieve individual field value
                    $name = $row["name"];
                    $address = $row["address"];
                    $salary = $row["salary"];
                } else{
                    // URL doesn't contain valid id. Redirect to error page
                    header("location: error.php");
                    exit();
                }
                
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
        
        // Close statement
        unset($stmt);
        
        // Close connection
        unset($pdo);
    }  else{
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}
?&gt;
 
&lt;!DOCTYPE html&gt;
&lt;html lang="en"&gt;
&lt;head&gt;
    &lt;meta charset="UTF-8"&gt;
    &lt;title&gt;Update Record&lt;/title&gt;
    &lt;link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css"&gt;
    &lt;style type="text/css"&gt;
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    &lt;/style&gt;
&lt;/head&gt;
&lt;body&gt;
    &lt;div class="wrapper"&gt;
        &lt;div class="container-fluid"&gt;
            &lt;div class="row"&gt;
                &lt;div class="col-md-12"&gt;
                    &lt;div class="page-header"&gt;
                        &lt;h2&gt;Update Record&lt;/h2&gt;
                    &lt;/div&gt;
                    &lt;p&gt;Please edit the input values and submit to update the record.&lt;/p&gt;
                    &lt;form action="&lt;?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?&gt;" method="post"&gt;
                        &lt;div class="form-group &lt;?php echo (!empty($name_err)) ? 'has-error' : ''; ?&gt;"&gt;
                            &lt;label&gt;Name&lt;/label&gt;
                            &lt;input type="text" name="name" class="form-control" value="&lt;?php echo $name; ?&gt;"&gt;
                            &lt;span class="help-block"&gt;&lt;?php echo $name_err;?&gt;&lt;/span&gt;
                        &lt;/div&gt;
                        &lt;div class="form-group &lt;?php echo (!empty($address_err)) ? 'has-error' : ''; ?&gt;"&gt;
                            &lt;label&gt;Address&lt;/label&gt;
                            &lt;textarea name="address" class="form-control"&gt;&lt;?php echo $address; ?&gt;&lt;/textarea&gt;
                            &lt;span class="help-block"&gt;&lt;?php echo $address_err;?&gt;&lt;/span&gt;
                        &lt;/div&gt;
                        &lt;div class="form-group &lt;?php echo (!empty($salary_err)) ? 'has-error' : ''; ?&gt;"&gt;
                            &lt;label&gt;Salary&lt;/label&gt;
                            &lt;input type="text" name="salary" class="form-control" value="&lt;?php echo $salary; ?&gt;"&gt;
                            &lt;span class="help-block"&gt;&lt;?php echo $salary_err;?&gt;&lt;/span&gt;
                        &lt;/div&gt;
                        &lt;input type="hidden" name="id" value="&lt;?php echo $id; ?&gt;"/&gt;
                        &lt;input type="submit" class="btn btn-primary" value="Submit"&gt;
                        &lt;a href="index.php" class="btn btn-default"&gt;Cancel&lt;/a&gt;
                    &lt;/form&gt;
                &lt;/div&gt;
            &lt;/div&gt;        
        &lt;/div&gt;
    &lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<hr />
				<h2>Creating the Delete Page</h2>
				<p>Finally, we will build the <b>D</b>elete functionality of our CRUD application.</p>
				<p>Let's create a file named "delete.php" and put the following code inside it. It will delete the existing records from the <i>employees</i> table based the id attribute of the employee.</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox multi-style-mode">
                        <div class="codebox-title">
                        	<h4>Example</h4>
                            <div class="code-style">
                            	<span class="active" data-target="0" data-url="delete" title="Show Example Code in MySQLi Procedural Style">Procedural</span> 
                                <span data-target="1" data-url="delete-oo-format" title="Show Example Code in MySQLi Object Oriented Style">Object Oriented</span> 
                                <span data-target="2" data-url="delete-pdo-format" title="Show Example Code in PDO Style">PDO</span>
                            </div>
                        	<a href="../examples/bin/download-source.php?topic=php&amp;file=delete" target="_top" class="download-btn" title="Download Source Code"><span>Download</span></a>
                            <span class="box-size"><i title="Maximize"></i></span>
                        </div>
                        <pre class="syntax-highlighter line-numbers scroll xlarge"><code class="language-php">&lt;?php
// Process delete operation after confirmation
if(isset($_POST["id"]) && !empty($_POST["id"])){
    // Include config file
    require_once "config.php";
    
    // Prepare a delete statement
    $sql = "DELETE FROM employees WHERE id = ?";
    
    if($stmt = mysqli_prepare($link, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "i", $param_id);
        
        // Set parameters
        $param_id = trim($_POST["id"]);
        
        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){
            // Records deleted successfully. Redirect to landing page
            header("location: index.php");
            exit();
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }
    }
     
    // Close statement
    mysqli_stmt_close($stmt);
    
    // Close connection
    mysqli_close($link);
} else{
    // Check existence of id parameter
    if(empty(trim($_GET["id"]))){
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}
?&gt;
&lt;!DOCTYPE html&gt;
&lt;html lang="en"&gt;
&lt;head&gt;
    &lt;meta charset="UTF-8"&gt;
    &lt;title&gt;View Record&lt;/title&gt;
    &lt;link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css"&gt;
    &lt;style type="text/css"&gt;
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    &lt;/style&gt;
&lt;/head&gt;
&lt;body&gt;
    &lt;div class="wrapper"&gt;
        &lt;div class="container-fluid"&gt;
            &lt;div class="row"&gt;
                &lt;div class="col-md-12"&gt;
                    &lt;div class="page-header"&gt;
                        &lt;h1&gt;Delete Record&lt;/h1&gt;
                    &lt;/div&gt;
                    &lt;form action="&lt;?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?&gt;" method="post"&gt;
                        &lt;div class="alert alert-danger fade in"&gt;
                            &lt;input type="hidden" name="id" value="&lt;?php echo trim($_GET["id"]); ?&gt;"/&gt;
                            &lt;p&gt;Are you sure you want to delete this record?&lt;/p&gt;&lt;br&gt;
                            &lt;p&gt;
                                &lt;input type="submit" value="Yes" class="btn btn-danger"&gt;
                                &lt;a href="index.php" class="btn btn-default"&gt;No&lt;/a&gt;
                            &lt;/p&gt;
                        &lt;/div&gt;
                    &lt;/form&gt;
                &lt;/div&gt;
            &lt;/div&gt;        
        &lt;/div&gt;
    &lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;</code></pre>
						<pre class="syntax-highlighter line-numbers scroll xlarge hide"><code class="language-php">&lt;?php
// Process delete operation after confirmation
if(isset($_POST["id"]) && !empty($_POST["id"])){
    // Include config file
    require_once "config.php";
    
    // Prepare a delete statement
    $sql = "DELETE FROM employees WHERE id = ?";
    
    if($stmt = $mysqli-&gt;prepare($sql)){
        // Bind variables to the prepared statement as parameters
        $stmt-&gt;bind_param("i", $param_id);
        
        // Set parameters
        $param_id = trim($_POST["id"]);
        
        // Attempt to execute the prepared statement
        if($stmt-&gt;execute()){
            // Records deleted successfully. Redirect to landing page
            header("location: index.php");
            exit();
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }
    }
     
    // Close statement
    $stmt-&gt;close();
    
    // Close connection
    $mysqli-&gt;close();
} else{
    // Check existence of id parameter
    if(empty(trim($_GET["id"]))){
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}
?&gt;
&lt;!DOCTYPE html&gt;
&lt;html lang="en"&gt;
&lt;head&gt;
    &lt;meta charset="UTF-8"&gt;
    &lt;title&gt;View Record&lt;/title&gt;
    &lt;link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css"&gt;
    &lt;style type="text/css"&gt;
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    &lt;/style&gt;
&lt;/head&gt;
&lt;body&gt;
    &lt;div class="wrapper"&gt;
        &lt;div class="container-fluid"&gt;
            &lt;div class="row"&gt;
                &lt;div class="col-md-12"&gt;
                    &lt;div class="page-header"&gt;
                        &lt;h1&gt;Delete Record&lt;/h1&gt;
                    &lt;/div&gt;
                    &lt;form action="&lt;?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?&gt;" method="post"&gt;
                        &lt;div class="alert alert-danger fade in"&gt;
                            &lt;input type="hidden" name="id" value="&lt;?php echo trim($_GET["id"]); ?&gt;"/&gt;
                            &lt;p&gt;Are you sure you want to delete this record?&lt;/p&gt;&lt;br&gt;
                            &lt;p&gt;
                                &lt;input type="submit" value="Yes" class="btn btn-danger"&gt;
                                &lt;a href="index.php" class="btn btn-default"&gt;No&lt;/a&gt;
                            &lt;/p&gt;
                        &lt;/div&gt;
                    &lt;/form&gt;
                &lt;/div&gt;
            &lt;/div&gt;        
        &lt;/div&gt;
    &lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;</code></pre>
						<pre class="syntax-highlighter line-numbers scroll xlarge hide"><code class="language-php">&lt;?php
// Process delete operation after confirmation
if(isset($_POST["id"]) && !empty($_POST["id"])){
    // Include config file
    require_once "config.php";
    
    // Prepare a delete statement
    $sql = "DELETE FROM employees WHERE id = :id";
    
    if($stmt = $pdo-&gt;prepare($sql)){
        // Bind variables to the prepared statement as parameters
        $stmt-&gt;bindParam(":id", $param_id);
        
        // Set parameters
        $param_id = trim($_POST["id"]);
        
        // Attempt to execute the prepared statement
        if($stmt-&gt;execute()){
            // Records deleted successfully. Redirect to landing page
            header("location: index.php");
            exit();
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }
    }
     
    // Close statement
    unset($stmt);
    
    // Close connection
    unset($pdo);
} else{
    // Check existence of id parameter
    if(empty(trim($_GET["id"]))){
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}
?&gt;
&lt;!DOCTYPE html&gt;
&lt;html lang="en"&gt;
&lt;head&gt;
    &lt;meta charset="UTF-8"&gt;
    &lt;title&gt;View Record&lt;/title&gt;
    &lt;link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css"&gt;
    &lt;style type="text/css"&gt;
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    &lt;/style&gt;
&lt;/head&gt;
&lt;body&gt;
    &lt;div class="wrapper"&gt;
        &lt;div class="container-fluid"&gt;
            &lt;div class="row"&gt;
                &lt;div class="col-md-12"&gt;
                    &lt;div class="page-header"&gt;
                        &lt;h1&gt;Delete Record&lt;/h1&gt;
                    &lt;/div&gt;
                    &lt;form action="&lt;?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?&gt;" method="post"&gt;
                        &lt;div class="alert alert-danger fade in"&gt;
                            &lt;input type="hidden" name="id" value="&lt;?php echo trim($_GET["id"]); ?&gt;"/&gt;
                            &lt;p&gt;Are you sure you want to delete this record?&lt;/p&gt;&lt;br&gt;
                            &lt;p&gt;
                                &lt;input type="submit" value="Yes" class="btn btn-danger"&gt;
                                &lt;a href="index.php" class="btn btn-default"&gt;No&lt;/a&gt;
                            &lt;/p&gt;
                        &lt;/div&gt;
                    &lt;/form&gt;
                &lt;/div&gt;
            &lt;/div&gt;        
        &lt;/div&gt;
    &lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<hr />				
				<h2>Creating the Error Page</h2>
				<p>At the end, let's create one more file "error.php". This page will be displayed if request is invalid i.e. if id parameter is missing from the URL query string or it is not valid.</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../examples/bin/download-source.php?topic=php&amp;file=error" target="_top" class="download-btn" title="Download Source Code"><span>Download</span></a><span class="box-size"><i title="Maximize"></i></span></div>
                        <pre class="syntax-highlighter line-numbers scroll xlarge"><code class="language-markup">&lt;!DOCTYPE html&gt;
&lt;html lang="en"&gt;
&lt;head&gt;
    &lt;meta charset="UTF-8"&gt;
    &lt;title&gt;Error&lt;/title&gt;
    &lt;link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css"&gt;
    &lt;style type="text/css"&gt;
        .wrapper{
            width: 750px;
            margin: 0 auto;
        }
    &lt;/style&gt;
&lt;/head&gt;
&lt;body&gt;
    &lt;div class="wrapper"&gt;
        &lt;div class="container-fluid"&gt;
            &lt;div class="row"&gt;
                &lt;div class="col-md-12"&gt;
                    &lt;div class="page-header"&gt;
                        &lt;h1&gt;Invalid Request&lt;/h1&gt;
                    &lt;/div&gt;
                    &lt;div class="alert alert-danger fade in"&gt;
                        &lt;p&gt;Sorry, you've made an invalid request. Please &lt;a href="index.php" class="alert-link"&gt;go back&lt;/a&gt; and try again.&lt;/p&gt;
                    &lt;/div&gt;
                &lt;/div&gt;
            &lt;/div&gt;        
        &lt;/div&gt;
    &lt;/div&gt;
&lt;/body&gt;
&lt;/html&gt;</code></pre>                    
					</div>
                </div>
                <!--End:Code box-->
				<p>After a long journey finally we've finished our CRUD application with PHP and MySQL. We recommend you to check out <a href="php-mysql-introduction.php">PHP &amp; MySQL database</a> tutorial section from the beginning, if you haven't already covered, for a better understanding of each and every part of this tutorial.</p>
				<!--Bottom Navigation-->
                <div class="bottom-link clearfix">
                    <a href="php-mysql-delete-query.php" class="previous-page-bottom">Previous Page</a>
                    <a href="php-mysql-ajax-live-search.php" class="next-page-bottom">Next Page</a>
                </div>
                <!--End:Bottom Navigation-->  
                <!-- InstanceEndEditable -->
                <!--Bottom Ads-->
                <div class="bottom-ad clearfix">
                    <div class="ad-label">Advertisements</div>

<!--Rectangle Left-->
<div class="rectangle-left fl">
    
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Large Rectangle Left -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="8162953958"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
<!--End:Rectangle Left-->


<!--Rectangle Right-->
<div class="rectangle-right fr">

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Large Rectangle Right -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="3324015654"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
<!--End:Rectangle Right-->                </div>
                <!--End:Bottom Ads-->
            </div>
            <!--End:Text Content-->
            <!--Feedback Form-->
			<div class="snippets">
	<a href="/snippets/gallery.php" target="_blank">
    	<img src="/lib/images/bootstrap-code-snippets.png" alt="Bootstrap UI Design Templates" />
	</a>
</div>

<div class="report-error" id="feedback">
    <div class="contact-form clearfix">
        <div class="close"><span class="icon-close"></span></div>
        <form id="feedback-form">
            <h3>Your Feedback:</h3>
            <div class="clearfix">
                <div class="name fl"><label>Your Name (optional) <input type="text" name="user-name" id="user-name" /></label></div>
                <div class="email fr"><label>Your E-mail (optional) <input type="text" name="user-email" id="user-email" /></label></div>
            </div>
            <div><label>Page address <input type="text" name="page-url" id="page-url" class="disabled" disabled="disabled" /></label></div>
            <div><label>Description <textarea name="description" id="description" rows="6"></textarea></label></div>
            <p id="feedback-error">We would love to hear from you, please drop us a line.</p>
            <div><button type="button" class="action-btn" onclick="sendFeedback()"><span class="icon-send"></span> Send</button></div>
        </form>
        <div id="response"></div>
    </div>           
</div>            <!--End:Feedback Form-->
        </div>        
        <div class="sidebar">
            <div class="ad-label">Advertisements</div>

<div class="skyscraper primary">

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Premium Skyscraper -->
<ins class="adsbygoogle"
     style="display:inline-block;width:160px;height:600px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="4376141825"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>

<div class="skyscraper">
    
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Bottom Skyscraper -->
<ins class="adsbygoogle"
     style="display:inline-block;width:160px;height:600px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="3387984471"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>        </div>
    </div>
    <!--Footer-->
	<!--Footer-->
<div class="footer">
    <div class="appeal">
        <div class="wrapper">
            <p>Is this website helpful to you? Please give us a
            <a href="/like.php" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=250,width=600,top=150, left='+((screen.width/2)-300));return false;">like</a>,
            or share your <a href="#feedback" class="feedback">feedback</a><em> to help us improve</em>.
            Connect with us on <a href="https://www.facebook.com/tutorialrepublic" target="_blank">Facebook</a> and <a href="https://twitter.com/tutrepublic" target="_blank">Twitter</a> for the latest updates.</p>               
        </div>
    </div>
    <div class="footer-inner">
        <div class="wrapper clearfix">                
            <div class="link-box">
                <h4>About Us</h4>
                <div class="clearfix">
                    <a href="/about-us.php">Our Story</a>                    
                    <a href="/terms-of-use.php">Terms of Use</a>
                    <a href="/privacy-policy.php">Privacy Policy</a>                    
                </div>
            </div>
            <div class="link-box">
                <h4>Contact</h4>
                <div class="clearfix">
                    <a href="/contact-us.php">Contact Us</a>                    
                    <a href="#feedback" class="feedback">Report Error</a>
                    <a href="/advertise-with-us.php">Advertise</a>                    
                </div>
            </div>
            <div class="tool-box">
                <h4>Interactive Tools</h4>
                <div class="tools-list clearfix" id="tools">
                    <a href="/faq/what-is-the-maximum-length-of-title-and-meta-description-tag.php">Title &amp; Meta Length Calculator</a>                           
                    <a href="/html-formatter.php" target="_blank">HTML Formatter</a>                        
                    <a href="/twitter-bootstrap-button-generator.php" target="_blank">Bootstrap Button Generator</a>
                    <a href="/html-reference/html-color-picker.php">HTML Color Picker</a>
                    <a href="/codelab.php?topic=sql&amp;file=select-all" target="_blank">SQL Playground</a>
                    <a href="/codelab.php?topic=html&amp;file=hello-world" target="_blank">HTML Editor</a>                    
                </div>
            </div>
            <div class="footer-logo">
                <img src="/lib/images/logo.svg" alt="TutorialRepublic" />
            </div>
        </div>
    </div>           
        <div class="bottom-strip">
        <div class="wrapper">
            <div class="notice">Copyright &copy; 2019 Tutorial Republic. All Rights Reserved.</div>
            <div class="social-media">
                <em>Share This:</em>
                <a href="https://facebook.com/sharer.php?u=https://www.tutorialrepublic.com%2Fphp-tutorial%2Fphp-mysql-crud-application.php" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" title="Facebook"><i class="icon-facebook"></i></a>
                <a href="#" id="tweet-btn" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" title="Twitter"><i class="icon-twitter"></i></a>
                <a href="#" id="email-btn" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" rel="noreferrer" title="Gmail"><i class="icon-mail"></i></a>
            </div>
        </div>            
    </div>
    <script>
        var title = document.title.replace('- Tutorial Republic', '');
        document.getElementById('tweet-btn').href = 'https://twitter.com/share?text=' + title + '- &url=https://www.tutorialrepublic.com%2Fphp-tutorial%2Fphp-mysql-crud-application.php';
        document.getElementById('email-btn').href = 'https://mail.google.com/mail/?view=cm&fs=1&su=' + title + '&body=https://www.tutorialrepublic.com%2Fphp-tutorial%2Fphp-mysql-crud-application.php';
    </script>
</div>
<!--End:Footer-->
    
<div class="backdrop mobile-only"></div>

<!-- TutorialRepublic base script -->
<script>
// Adding CSS files
[
	'/lib/styles/extended.new-3.7.css',
	'/lib/icomoon/style.css'
].forEach(function(href) {
	var link = document.createElement('link');
	link.rel = 'stylesheet';
	link.href = href;
	(document.getElementsByTagName('head')[0]).appendChild(link);
});

// Adding JS files
[
	'https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js',
	'/lib/js/prism.js',
	'/lib/js/default.new-2.9.min.js'
].forEach(function(src) {
	var script = document.createElement('script');
	script.async = false; // important
	script.src = src;
	(document.getElementsByTagName('body')[0]).appendChild(script);
});
</script>


    <!--End:Footer-->
</body>
<!-- InstanceEnd --></html>