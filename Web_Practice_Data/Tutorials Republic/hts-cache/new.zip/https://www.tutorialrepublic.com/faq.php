<!DOCTYPE html>
<html lang="en"><!-- InstanceBegin template="/Templates/basic.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
	<!-- InstanceBeginEditable name="doctitle" -->
    <title>Frequently Asked Questions | Tutorial Republic</title>
        <!-- InstanceEndEditable -->
    	<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta property="fb:admins" content="100001054961582" />
<meta property="fb:app_id" content="1404574483159557" />
<meta property="og:image" content="/lib/images/signature.png" />
<link type="image/x-icon" href="/favicon.ico" rel="shortcut icon" />
<style>
html,body,h1,h2,h3,h4,h5,h6,p,blockquote,pre,img{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}
html,body{min-height:100%}
p{margin:0 0 12px}
ol,ul{margin:0 0 12px}
a,a:active,a:visited{outline:none;color:#1db79f;text-decoration:none}
a code{color:inherit}
a img{border:none;outline:none}
code{color:#000}
table{border-collapse:collapse;border-spacing:0}
table td{vertical-align:top}
body{min-width:1300px;color:#414141;background:#fafafa;font-family:"Segoe UI","Helvetica Neue",Arial,sans-serif;font-size:17px;line-height:1.7}
input,select,textarea,button,div,span,a{box-sizing:border-box}
h1,h2,h3,h4{color:#262626;font-weight:500;margin:20px 0 10px;line-height:1.5;font-weight:600}
h1{font-size:34px;margin-top:17px}
h2{font-size:28px}
h3{font-size:22px}
.space{margin-bottom:25px!important}
.break{margin-bottom:15px!important}
.text-center{text-align:center!important}
.scroll{height:195px;overflow-y:scroll}
.scroll.large{height:245px}
.scroll.xlarge{height:290px}
.scroll.xxlarge{height:340px}
sup{font-size:13px}
pre{background:none;border-radius:0}
.leaderboard{padding-top:8px;position:relative}
.ad-container{height:90px;overflow:hidden}
.intro-image img{display:block;padding:10px 0 25px;max-width:100%}
.clearfix::after{content:".";display:block;height:0;clear:both;visibility:hidden}
code,.code,.syntax,.green-box,.sky-box,.gray-box,.pink-box,.red-box,.at-rule,.codebox ul,.console-output{font-size:16px;font-family:Consolas,Monaco,Courier,monospace}
p code,table.data td:last-child code,.content ul li code,code.mark{padding:2px 4px;color:#333;background-color:#f1f1f1;border-radius:4px}
p code a,table.data td:last-child code a, .content ul li code a{padding:2px 0;background:#fff;margin:0 -4px;font-size:16px}
.console-output{margin:15px 0}
hr{border:none;border-bottom:1px solid #e7e9ed;height:1px;margin:30px 0}
.summary,.topic{border:1px solid #eaeaea;border-width:1px 0;margin:20px 0;padding:10px 0;color:#8e9aa6;line-height:1.5}
h2.section-title span{display:inline-block;border-bottom:4px solid #c9d7e0;padding:0 50px 12px 0}
.wrapper{width:1300px;padding:0 15px;margin:0 auto}
.header{background:#23384e;padding:16px 0}
input.search{background:#fff;border:0 none;color:#807E7E;float:left;height:38px;line-height:26px;font-size:14px;margin:0 0 0 12px;outline:medium none;padding:6px 14px;width:500px;border-radius:2px;box-shadow:0 0 1px rgba(0,0,0,0.6);font-family:inherit}
.search-btn{color:rgba(0,0,0,.6);background:#ebebeb;border:none;outline:none;cursor:pointer;float:left;height:38px;line-height:46px;width:44px;display:block;margin-left:-2px;border-radius:0 2px 2px 0;box-shadow:0 0 1px rgba(0,0,0,0.7)}
.logo{width:304px}
.logo img{height:44px;margin:-3px 0;display:block}
.site-search{float:left;margin-left:100px}
.menu{background-color:#f5f5f5;box-shadow:0 1px 1px rgba(0,0,0,.15);position:relative;z-index:9}
.menu a{color:#666;display:inline-block;padding:0 10px;text-decoration:none;font-size:14px;font-weight:600;height:48px;line-height:48px}
.menu a:first-child{margin-left:-10px}
.menu a.tool-link{float:right;display:inline-block;border-radius:30px;line-height:28px;position:relative;height:auto;top:9px;padding:0 12px;color:#1ebba3;border:1px double #1ebba3}
.fl,.logo{float:left}
.leftcolumn{width:240px;float:left;font-size:16px;color:#4f4f4f}
.centercolumn{width:850px;float:left}
.content{background:#fff;padding:20px 40px;border:1px solid #dedede;border-top:none;border-radius:1px}
.sidebar{float:left;padding-top:28px;width:160px;margin-left:20px;position:relative}
.leftcolumn .segment{margin:16px 0 12px;position:relative;font-size:18px;font-weight:600;display:inline-block;line-height:normal}
.leftcolumn a{color:#4f4f4f;font-size:16px;line-height:26px;display:block;border-bottom:1px solid transparent}
.leftcolumn ul{list-style:none;padding:0}
.segment,.chapters,.chapters a,.toggle-tree-menu{float:left;clear:both}
ul.tree-menu li.tree{margin-left:-12px;float:left;width:100%}
ul.tree-menu li a,ul.tree-menu li code{color:#4f4f4f;font-size:15.4px}
ul.chapters.tree-menu li a{font-size:16px}
h1 code,h2 code,h3 code{font:inherit}
.color-box{margin:15px 0;padding-left:20px}
.note-box,.warning-box,.tip-box{padding:8px 8px 3px 26px}
.info-tab{float:left;margin-left:-23px}
.content ul li{margin-top:7px}
.extra{padding-top:5px}
.green-box,.sky-box,.gray-box,.red-box,.pink-box{color:#000;margin-top:15px;padding:10px;background-color:#f6f8fa;border:1px solid #d7e2ec}
.example{background:#f4f5f6;padding:3px;margin:15px 0}
.codebox{background:#fff;border:1px solid #ddd}
.codebox-title{height:41px;padding-left:12px;border-bottom:1px solid #ddd;background:#f5f5f5}
.codebox-title h4{margin:0;font-size:18px;line-height:38px;float:left;display:inline;font-weight:500}
a.try-btn,a.download-btn{width:140px;height:40px;color:#333;font-size:15px;line-height:41px;font-weight:600;text-align:center;text-decoration:none;float:right;display:block;border-left:1px solid #ddd;background:rgba(27,31,35,0.08);box-sizing:border-box;font-family:Arial,sans-serif}
a.try-btn span{font-size:18px;line-height:normal}
.hide,.code-style,.box-size,.bottom-link,.footer,.code-style,.snippets,.report-error,.badge,.social,.ad-label,.mobile-only{display:none}
.skyscraper{width:160px;height:600px;overflow:hidden;margin-bottom:20px;background:#ebecf0}
.bottom-ad{margin-top:46px;padding:24px;position:relative;background:url(/lib/images/smooth-line.png) no-repeat center #f9f9f9}
.rectangle-left,.rectangle-right{min-width:336px;min-height:280px;overflow:hidden}
.fr,a.previous-page,a.next-page,.topic-nav{float:right}
a.previous-page,a.next-page{width:32px;height:32px;line-height:30px}
.shadow{background:#F7F8F9;padding:3px;margin:10px 0}
.syntax{color:#2f4959;padding:13px 18px;background:#F9F9FA;border:1px solid #ddd;font-size:15px}
.codebox ul{font-size:14px;padding:7px;list-style:decimal inside none}
.codebox ul.lead-zero,.codebox ul.lead-double-zero{list-style-type:decimal-leading-zero}
.codebox ul li{padding:0 9px;color:#AFAFAF;background-image:none;margin:0}
.codebox ul pre,.codebox ul li,.codebox ul li code{line-height:1.6;vertical-align:top}
.codebox ul pre,.codebox ul code{width:90%;font-size:16px;color:#222;display:inline-block;padding-left:10px;border-left:3px solid #6CE26C;white-space:pre-wrap;word-break:normal}
.codebox ul.lead-double-zero li{text-align:right}
.codebox ul.lead-double-zero li pre{text-align:left}
.codebox ul.sql.single-line pre{line-height:26px}
.content .codebox ul li code{color:#222;padding:0 0 0 10px}
.preview-box{padding:15px;text-align:center;cursor:pointer;overflow:hidden;background:#FFF;border:1px solid #e6e6e6}
.preview-box a,.preview-box img{display:block;margin:0 auto}
.topic a:first-of-type{margin-left:2px}
.topic-nav{padding-right:5px;color:#d0d0d0}
.topic-nav a{padding:0 15px;margin:0 0 0 5px;position:relative;display:inline-block}
.topic-nav a::after{font-size:24px;position:absolute;line-height:normal;top:-6px}
.topic-nav a:first-child{margin:0 5px 0 0}
.topic-nav a:first-child::after{content:'\00AB';left:-5px}
.topic-nav a:last-child::after{content:'\00BB';right:-5px}
.download-box{text-align:center;padding:20px 0;margin:20px 0 10px}
.output-box{border-color:#d4d4d4;border-style:solid;border-width:1px 0;padding:5px 15px;overflow:hidden;background:#fff;margin:10px 0}
.demo-box{margin-top:15px}
.subhead{border-bottom:3px solid #DCE3EB;margin-bottom:15px;padding-bottom:10px}
table.data,table.description{width:100%;font-size:92%}
table.data th{color:#000;padding:8px 7px;text-align:left;font-size:15px;background:#F8F8F8}
table.data td{color:#484848;padding:5px 7px;background:#fff}
table.data th,table.data td{vertical-align:top;border:1px solid #DCE3EB}
table.data tr.section th,table.data td.section{font-size:15px;background:#f0f4f7}
table.description th{width:150px;padding:7px;vertical-align: middle}
table.no-wrap tr td:first-child{white-space:nowrap}
.overview{padding-right:202px}
.overview .intro-image{float:right;margin-right:-202px;text-align:right}
.overview .intro-image + p{padding-top:0}
.support{background:#F8F8F8;border:1px solid #ccc;color:#2F4959;padding:15px}
.support table td:first-child{width:200px;padding:0 25px 0 10px;border-right:1px dashed #D0D0D0}
.support h2{color:#2F4959;font-size:16px;padding:0 0 0 30px;margin-top:0}
.support ul{margin-left:10px}
.support ul li{margin-top:4px}
h1 sup{background:#ec0000;border-radius:3px;padding:5px 10px;font-size:15px;color:#fff;position:relative;top:5px}
@media screen and (max-width: 1280px) {
body{min-width:1260px}
.wrapper{width:1260px}
.leftcolumn{width:230px}
.centercolumn{width:820px}
}
@media screen and (max-width: 800px) {
body{min-width:100%;max-width:100%;padding-top:46px}
.wrapper{width:100%;padding:0}
.header{height:46px;padding:5px 0;position:fixed;top:0;left:0;right:0;width:100%;z-index:99}
.logo{width:auto;display:block;padding:6px 0 0 60px;position:absolute;left:0;z-index:100}
.logo img{height:30px}
.menu{width:100%;padding-left:12px;padding-right:12px;overflow-x:auto;white-space:nowrap}
.centercolumn{width:100%;float:none}
.content{padding:10px;border-width:0 0 1px 0}
.sidebar{margin: 25px auto 0}
.skyscraper{display:inline-block}
.shadow,.example{max-width:100%;overflow-x:auto}
.codebox-title{position:relative}
.codebox.multi-style-mode ul{padding-top:7px;margin-top:36px;border-top:1px solid #ddd}
.codebox ul,.codebox ul.scroll{overflow-x:auto}
.rectangle-left,.rectangle-right{float:none;display:inline-block;margin:10px auto;background:#EDEEF2}
.leftcolumn,.footer,.header .social,.header .site-search,.overview .intro-image,.toggle-tree-menu,.code-style,.support table td:first-child,ul.tree-menu code.shorthand,.menu a.tool-link,.backdrop{display:none}
.summary,.topic{padding:5px 0;margin:10px 0}
.leftcolumn,.centercolumn,.sidebar{float:none}
.header,.menu,.container,.footer,.appeal-text{width:100%;box-sizing:border-box}
.centercolumn{width:100%}
.content img{max-width:100%;height:auto}
.codebox ul li{width:614px}
.codebox ul.scroll li{width:597px}
.codebox ul,.codebox ul.scroll{overflow-x:auto}
a.try-btn,a.download-btn{width:130px}
.bottom-ad{height:auto;background:none;padding:30px 0 0;margin:40px 0 0;text-align:center;position:relative}
.native-unit{margin-bottom:30px}
.overview{padding-right:0}
.scroll-pane{overflow-x:auto}
table.data{min-width:480px}
table.data pre{display:inline;white-space:normal}
table tr th,table tr td{width:auto!important}
.support h2,.support ul{padding-left:0}
p.topic{vertical-align:top}
p.topic > a{word-wrap:break-word;display:inline-block}
.example-list ul li,ul.faq-list li{padding-bottom:3px}
.preview-box{padding:6px}
.topic-nav{float:none;display:block;padding:6px 0 0 5px}
.codebox.multi-style-mode ul{padding-top:7px;margin-top:34px;border-top:1px solid #ccc}
.content pre{max-width:100%;overflow:hidden}
.shadow,.content pre.console-output{max-width:100%;overflow-x:auto}
ul.tree-menu li.tree{margin-left:0}
.support ul{margin-left:20px}
.leaderboard{margin:20px 0}
h1{font-size:28px}
h2{font-size:24px}
h3{font-size:20px}
}
@media screen and (min-width: 801px) {
.site-search,.leftcolumn,.social{display:block!important}
.backdrop{display:none!important}
}</style>    
    <!-- InstanceBeginEditable name="head" -->
	<style>
    ul.faq-list{padding:0;list-style:none}
	ul.faq-list li a{color:#4f4f4f}
	ul.faq-list li a:hover{color:#222;text-decoration:underline}
    ul.faq-list li{padding-left:0;background-image:none}
    ul.faq-list li:before{content:"Q: ";color:#4f4f4f}
    </style>
    <!-- InstanceEndEditable -->
    
    <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-40117907-1', 'auto');
  ga('send', 'pageview');
</script></head>
<body>
    <!--Header-->
    
<div class="header">
    <div class="wrapper clearfix">
        <button type="button" class="open-menu mobile-only"><i class="icon-menu"></i></button>
        <div class="logo">
            <a href="https://www.tutorialrepublic.com/"><img src="/lib/images/logo.svg" alt="TutorialRepublic" /></a>
        </div>
        <div class="site-search">
            <form action="https://www.google.com/search" method="get" target="_blank" class="clearfix">
                <input type="hidden" value="www.tutorialrepublic.com" name="sitesearch" />
                <input type="text" name="q" placeholder="Search topics, tutorials, questions and answers..." id="searchInput" class="search" />
                <button type="submit" class="search-btn"><span class="icon-search"></span></button>
            </form>
        </div>
        <div class="social">                
            <a href="https://www.facebook.com/tutorialrepublic" target="_blank" title="Join us on Facebook"><i class="icon-facebook"></i></a>
            <a href="https://twitter.com/tutrepublic" target="_blank" title="Follow us on Twitter"><i class="icon-twitter"></i></a>
            <a href="/contact-us.php" target="_blank" title="Send us an Email"><i class="icon-mail"></i></a>
        </div>
        <button type="button" class="open-search mobile-only">
            <i class="icon-search"></i>
        </button>
    </div>    
</div>
<div class="menu">
    <div class="wrapper">
        <a href="//www.tutorialrepublic.com" title="Home Page">HOME</a>
        <a href="/html-tutorial/" title="HTML Tutorial">HTML5</a>            
        <a href="/css-tutorial/" title="CSS Tutorial">CSS3</a>
        <a href="/javascript-tutorial/" title="JavaScript Tutorial">JAVASCRIPT</a>
        <a href="/jquery-tutorial/" title="jQuery Tutorial">JQUERY</a>
        <a href="/twitter-bootstrap-tutorial/" title="Bootstrap Tutorial">BOOTSTRAP4</a>
        <a href="/php-tutorial/" title="PHP Tutorial">PHP7</a> 
        <a href="/sql-tutorial/" title="SQL Tutorial">SQL</a>
        <a href="/references.php" title="Web References">REFERENCES</a>
        <a href="/practice-examples.php" title="Practice Examples and Demos">EXAMPLES</a>
        <a href="/faq.php" title="Frequently Asked Questions and Answers">FAQ</a>
        <a href="/snippets/gallery.php" title="Bootstrap Code Snippets" target="_blank">SNIPPETS</a>
        <a href="/codelab.php" class="tool-link" target="_blank">Online HTML Editor</a>
    </div>        
</div>    <!--End:Header-->
    <div class="wrapper clearfix">
        <div class="leftcolumn" id="myNav">
		
        <div class="segment"><span>WEB</span> TUTORIALS</div>
<div class="chapters">
    <a href="/html-tutorial/">HTML Tutorial</a>    
    <a href="/css-tutorial/">CSS Tutorial</a>
	<a href="/javascript-tutorial/">JavaScript Tutorial</a>
	<a href="/jquery-tutorial/">jQuery Tutorial</a>
    <a href="/twitter-bootstrap-tutorial/">Bootstrap Tutorial</a>
	<a href="/php-tutorial/">PHP Tutorial</a>
	<a href="/sql-tutorial/">SQL Tutorial</a>
</div>
<div class="segment"><span>PRACTICE</span>&thinsp;EXAMPLES</div>
<div class="chapters">
    <a href="/html-examples.php">HTML Examples</a>
    <a href="/css-examples.php">CSS Examples</a>
	<a href="/javascript-examples.php">JavaScript Examples</a>
	<a href="/jquery-examples.php">jQuery Examples</a>
    <a href="/twitter-bootstrap-examples.php">Bootstrap Examples</a>
	<a href="/php-examples.php">PHP Examples</a>
</div>
<div class="segment"><span>HTML</span> REFERENCES</div>
<div class="chapters">
    <a href="/html-reference/html5-tags.php">HTML Tags/Elements</a>
	<a href="/html-reference/html5-global-attributes.php">HTML Global Attributes</a>
    <a href="/html-reference/html5-event-attributes.php">HTML Event Attributes</a>             
    <a href="/html-reference/html-color-picker.php">HTML Color Picker</a>
    <a href="/html-reference/html-language-codes.php">HTML Language Codes</a>
    <a href="/html-reference/html-character-entities.php">HTML Character Entities</a>
    <a href="/html-reference/http-status-codes.php">HTTP Status Codes</a>
</div>
<div class="segment"><span>CSS</span> REFERENCES</div>
<div class="chapters">
    <a href="/css-reference/css-at-rules.php">CSS At-rules</a>
    <a href="/css-reference/css3-properties.php">CSS Properties</a>
	<a href="/css-reference/css-animatable-properties.php">CSS Animatable Properties</a>
    <a href="/css-reference/css-color-values.php">CSS Color Values</a>
    <a href="/css-reference/css-color-names.php">CSS Color Names</a>
    <a href="/css-reference/css-web-safe-fonts.php">CSS Web Safe Fonts</a>
    <a href="/css-reference/css-aural-properties.php">CSS Aural Properties</a>
</div>
<div class="segment"><span>PHP</span> REFERENCES</div>
<div class="chapters">
	<a href="/php-reference/php-string-functions.php">PHP String Functions</a>
    <a href="/php-reference/php-array-functions.php">PHP Array Functions</a>
    <a href="/php-reference/php-file-system-functions.php">PHP File System Functions</a>
    <a href="/php-reference/php-date-and-time-functions.php">PHP Date/Time Functions</a>
    <a href="/php-reference/php-calendar-functions.php">PHP Calendar Functions</a>
    <a href="/php-reference/php-mysqli-functions.php">PHP MySQLi Functions</a>
    <a href="/php-reference/php-filters.php">PHP Filters</a>
    <a href="/php-reference/php-error-levels.php">PHP Error Levels</a>
</div>        
                </div>
        <div class="centercolumn">
            <!--Text Content-->
            <div class="content">
                <div class="leaderboard">
                    
<div class="ad-label">Advertisements</div>
<div class="ad-container">
    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <!-- Responsive Leaderboard -->
    <ins class="adsbygoogle"
            style="display:inline-block;max-width:728px;width:100%;height:90px"
            data-ad-client="ca-pub-9107540490929984"
            data-ad-slot="4302666817"></ins>
    <script>
    (adsbygoogle = window.adsbygoogle || []).push({});
    </script>
</div>                </div>
                <!-- InstanceBeginEditable name="main_content" -->
                <a class="previous-page disabled" title="Go to Previous Page : Disabled" href="javascript:void(0);"></a>
				<a class="next-page disabled" title="Go to Next Page : Disabled" href="javascript:void(0);"></a>
                <h1>Frequently Asked <span>Questions</span></h1>
        		<p class="summary">The idea behind creating this section is to provide you quick and working solutions for the common tasks and issues related to web design and development.</p>
                <div id="html-css">
					<h2>HTML&thinsp;/&thinsp;CSS</h2>
					<p class="subhead">This section contains a collection of frequently asked questions related to HTML and CSS</p>
					<ul class="faq-list">
						<li><a href="faq/how-to-write-comments-in-html.php">How to write comments in HTML</a></li>
						<li><a href="faq/how-to-write-comments-in-css.php">How to write comments in CSS</a></li>
						<li><a href="faq/how-to-remove-dotted-line-around-links-using-css.php">How to remove dotted line around the links using CSS</a></li>
						<li><a href="faq/how-to-align-text-vertically-center-in-a-div-using-css.php">How to align text vertically center in a DIV element using CSS</a></li>
						<li><a href="faq/how-to-set-a-div-height-to-100-percent-using-css.php">How to set the height of a DIV to 100% using CSS</a></li>
						<li><a href="faq/how-to-align-a-div-horizontally-center-using-css.php">How to align a DIV horizontally center using CSS</a></li>
						<li><a href="faq/css-background-opacity-without-effecting-the-child-elements.php">How to change the background transparency without affecting the child elements</a></li>
						<li><a href="faq/how-to-define-style-sheet-only-for-internet-explorer.php">How to define style sheet only for Internet Explorer</a></li>
						<li><a href="faq/show-hide-dropdown-menu-on-mouse-hover-using-css.php">How to show hide dropdown menu on mouse hover using CSS</a></li>
						<li><a href="faq/how-to-remove-white-space-under-an-image-using-css.php">How to remove white space underneath an image using CSS</a></li>
						<li><a href="faq/what-is-the-maximum-length-of-title-and-meta-description-tag.php">What is the maximum length of title and meta description tag in HTML</a></li>
						<li><a href="faq/how-to-highlight-alternate-table-row-using-css.php">How to highlight alternate table row using CSS</a></li>
						<li><a href="faq/how-to-fix-css-collapsing-parent-having-floating-children.php">How to fix CSS collapsing parent issue</a></li>
						<li><a href="faq/how-to-create-custom-cursor-using-css.php">How to create custom cursor using CSS</a></li>
						<li><a href="faq/how-to-apply-the-shadow-effect-on-elements-using-css.php">How to apply shadow effect on elements using CSS</a></li>
						<li><a href="faq/how-to-apply-shadow-effect-on-text-using-css.php">How to apply shadow effect on text using CSS</a></li>
						<li><a href="faq/how-to-disable-spell-checking-in-html-forms.php">How to disable spell checking in HTML forms</a></li>
						<li><a href="faq/how-to-create-drop-caps-effect-using-css.php">How to create drop caps effect using CSS</a></li>
						<li><a href="faq/how-to-center-align-absolutely-positioned-div-using-css.php">How center align absolute positioned DIV horizontally using CSS</a></li>
						<li><a href="faq/apply-border-on-mouse-hover-without-affecting-the-layout-in-css.php">How to add border to an element on mouse hover without affecting the layout in CSS</a></li>
						<li><a href="faq/how-to-apply-css-opacity-in-internet-explorer.php">How to apply CSS opacity in IE7 and IE8 browsers</a></li>
						<li><a href="faq/how-to-create-3d-flipping-effect-on-mouse-hover-using-css.php">How to create 3D flipping effect on mouse hover using CSS</a></li>
						<li><a href="faq/how-to-animate-text-color-on-mouse-hover-using-css.php">How to animate text color on mouse hover using CSS</a></li>
						<li><a href="faq/how-to-animate-background-color-on-mouse-hover-using-css.php">How to animate background-color of an element on mouse hover using CSS</a></li>
						<li><a href="faq/how-to-transform-image-size-on-mouse-hover-without-affecting-the-layout-in-css.php">How to transform image size on mouse hover without affecting the layout in CSS</a></li>
						<li><a href="faq/how-to-make-a-div-element-editable-in-html.php">How to make a DIV element editable in HTML</a></li>
						<li><a href="faq/how-to-disable-resizable-property-of-textarea-using-css.php">How to disable resizable property of textarea using CSS</a></li>
						<li><a href="faq/how-to-expand-select-box-to-its-default-width-on-focus-using-css.php">How to expand select box to its default width on focus using CSS</a></li>                    
						<li><a href="faq/how-to-change-the-default-text-selection-color-in-the-browsers-using-css.php">How to change the default text selection color in the browsers using CSS</a></li>
						<li><a href="faq/how-to-remove-the-space-between-inline-block-elements-in-css.php">How to remove the space between inline-block elements in CSS</a></li>                 
						<li><a href="faq/how-to-disable-text-selection-highlighting-in-the-browsers-using-css.php">How to disable text selection highlighting in the browsers using CSS</a></li>
						<li><a href="faq/how-to-change-input-field-placeholder-text-color-using-css.php">How to change input field or textarea placeholder text color using CSS</a></li>
						<li><a href="faq/how-to-truncate-long-string-with-ellipsis-using-css.php">How to truncate long string with ellipsis using CSS</a></li>
						<li><a href="faq/how-to-create-triangle-or-caret-icons-using-css.php">How to create triangle or caret icons using CSS</a></li>
						<li><a href="faq/how-to-remove-outline-around-text-input-boxes-in-chrome-using-css.php">How to remove outline around text input boxes in chrome using CSS</a></li>
						<li><a href="faq/how-to-apply-multiple-background-images-to-an-element-using-css.php">How to apply multiple background images to an element using CSS</a></li>
						<li><a href="faq/how-to-create-fixed-header-or-footer-using-css.php">How to create fixed header or footer using CSS</a></li>
						<li><a href="faq/how-to-create-two-divs-with-same-height-side-by-side-in-css.php">How to create two DIV elements with same height side by side in CSS</a></li>
						<li><a href="faq/how-to-set-table-cellpadding-and-cellspacing-using-css.php">How to set table cellpadding and cellspacing in CSS</a></li>
						<li><a href="faq/how-to-remove-cellspacing-form-tables-using-css.php">How to remove cellspacing from tables using CSS</a></li>
						<li><a href="faq/how-to-place-border-inside-of-div-element-using-css.php">How to place border inside of a DIV element using CSS</a></li>
						<li><a href="faq/how-to-change-image-on-hover-with-css.php">How to change image on hover with CSS</a></li>
						<li><a href="faq/how-to-position-text-over-an-image-using-css.php">How to position text over an image using CSS</a></li>
						<li><a href="faq/how-to-create-an-html-button-that-acts-like-a-link.php">How to create an HTML button that acts like a link</a></li>
						<li><a href="faq/how-to-create-a-vertical-line-in-html.php">How to create a vertical line in HTML</a></li>
    					<li><a href="faq/how-to-change-the-cursor-into-a-hand-pointer-on-hover-using-css.php">How to change the cursor into a hand pointer on hover using CSS</a></li>
    					<li><a href="faq/how-to-make-a-div-not-larger-than-its-contents-using-css.php">How to make a DIV not larger than its contents CSS</a></li>
    					<li><a href="faq/how-to-auto-resize-an-image-to-fit-into-a-div-container-using-css.php">How to auto resize an image to fit into a DIV container using CSS</a></li>
    					<li><a href="faq/how-to-change-the-color-of-an-hr-element-using-css.php">How to change the color of an HR element using CSS</a></li>
    					<li><a href="faq/how-to-create-an-unordered-list-without-any-bullets-in-html.php">How to create an unordered list without any bullets in HTML</a></li>
    					<li><a href="faq/how-to-overlay-one-div-over-another-div-using-css.php">How to overlay one div over another DIV using CSS</a></li>
    					<li><a href="faq/how-to-stretch-and-scale-an-image-in-the-background-with-css.php">How to stretch and scale an image in the background with CSS</a></li>
    					<li><a href="faq/how-to-disable-a-link-using-only-css.php">How to disable a link using only CSS</a></li>
    					<li><a href="faq/how-to-vertically-align-an-image-inside-a-div-using-css.php">How to vertically align an image inside a DIV using CSS</a></li>
					</ul>
				</div>
                <hr />
				<div id="javascript-jquery">
					<h2>JavaScript&thinsp;/&thinsp;jQuery</h2>
					<p class="subhead">This section contains a collection of frequently asked questions related to JavaScript and jQuery</p>
					<ul class="faq-list">
						<li><a href="faq/how-to-write-comments-in-javascript.php">How to write comments in JavaScript</a></li>
						<li><a href="faq/show-hide-divs-based-on-radio-button-selection-in-jquery.php">How to show and hide DIV elements based on the selection of radio buttons in jQuery</a></li>
						<li><a href="faq/show-hide-divs-based-on-checkbox-selection-in-jquery.php">How to show and hide DIV elements based on the click of checkboxes in jQuery</a></li>
						<li><a href="faq/show-hide-divs-based-on-dropdown-selection-in-jquery.php">How to show and hide DIV elements based on dropdown selection in jQuery</a></li>
						<li><a href="faq/how-to-define-a-function-in-jquery.php">How to define a function in jQuery</a></li>
						<li><a href="faq/how-to-define-a-function-in-javascript.php">How to define a function in JavaScript</a></li>
						<li><a href="faq/call-a-function-after-some-time-in-jquery.php">How to call a function after waiting for some time in jQuery</a></li>
						<li><a href="faq/how-to-add-css-properties-to-an-element-dynamically-using-jquery.php">How to add CSS properties to an element dynamically using jQuery</a></li>
						<li><a href="faq/how-to-add-attribute-to-an-html-element-in-jquery.php">How to add attribute to an HTML element in jQuery</a></li>
						<li><a href="faq/how-to-remove-attribute-from-an-html-element-in-jquery.php">How to remove attribute from an HTML element in jQuery</a></li>
						<li><a href="faq/how-to-add-element-to-dom-in-jquery.php">How to add elements to DOM in jQuery</a></li>
						<li><a href="faq/how-to-remove-elements-from-dom-in-jquery.php">How to remove elements from DOM in jQuery</a></li>
						<li><a href="faq/how-to-remove-white-spaces-from-a-string-in-jquery.php">How to remove white space from a string using jQuery</a></li>
						<li><a href="faq/how-to-find-number-of-characters-in-a-string-using-jquery.php">How to find number of characters in a string using jQuery</a></li>
						<li><a href="faq/how-to-remove-clickable-behavior-from-a-disabled-link-using-jquery.php">How to remove the clickable behavior from a disabled link using jQuery</a></li>
						<li><a href="faq/how-to-create-custom-radio-buttons-using-css-and-jquery.php">How to create custom radio buttons using CSS and jQuery</a></li>
						<li><a href="faq/how-to-create-custom-checkboxes-using-css-and-jquery.php">How to create custom checkboxes using CSS and jQuery</a></li>
						<li><a href="faq/how-to-create-custom-select-boxes-using-css-and-jquery.php">How to create custom select boxes using CSS and jQuery</a></li>
						<li><a href="faq/how-to-check-a-checkbox-is-checked-or-not-using-jquery.php">How to check a checkbox is checked or not using jQuery</a></li>
						<li><a href="faq/how-to-create-a-string-by-joining-the-elements-of-an-array-in-javascript.php">How to create a string by joining the elements of an array in JavaScript</a></li>
						<li><a href="faq/how-to-get-the-value-of-selected-radio-button-using-jquery.php">How to get value of selected radio button using jQuery</a></li>
						<li><a href="faq/how-to-get-the-values-of-selected-checkboxes-in-a-group-using-jquery.php">How to get the values of selected checkboxes in a group using jQuery</a></li>
						<li><a href="faq/how-to-bind-click-event-to-dynamically-added-elements-in-jquery.php">How to bind click event to dynamically added HTML elements in jQuery</a></li>
						<li><a href="faq/how-to-set-the-width-of-a-div-element-using-jquery.php">How to set the width of a DIV element dynamically using jQuery</a></li>
						<li><a href="faq/how-to-set-the-height-of-a-div-element-using-jquery.php">How to set the height of a DIV element dynamically using jQuery</a></li>
						<li><a href="faq/how-to-remove-wrapper-element-but-keep-the-text-content-intact-using-jquery.php">How to remove wrapper element but keep the text content intact using jQuery</a></li>
						<li><a href="faq/how-to-animate-div-height-based-on-content-using-jquery.php">How to animate a DIV height based on the content using jQuery</a></li>                      
						<li><a href="faq/how-to-highlight-alternate-table-row-using-jquery.php">How to highlight alternate table row using jQuery</a></li> 
						<li><a href="faq/how-to-get-the-current-page-url-using-jquery.php">How to get the current page url using jQuery</a></li>
						<li><a href="faq/how-to-calculate-number-of-words-in-a-string-using-jquery.php">How to calculate the number of words in a string using jQuery</a></li>  
						<li><a href="faq/how-to-find-substring-between-the-two-words-using-jquery.php">How to find substring between the two words using jQuery</a></li>
						<li><a href="faq/how-to-get-the-value-of-selected-option-in-a-select-box-using-jquery.php">How to get the value of selected option in a select box using jQuery</a></li>
						<li><a href="faq/how-to-get-the-text-inside-an-element-using-jquery.php">How to get the text inside an element using jQuery</a></li>
						<li><a href="faq/how-to-check-an-element-is-visible-or-not-using-jquery.php">How to check an element is visible or not using jQuery</a></li>
						<li><a href="faq/populate-state-dropdown-based-on-selection-in-country-dropdown-using-jquery.php">How&thinsp;to populate state dropdown based on selection in country dropdown using jQuery</a></li>
						<li><a href="faq/how-to-get-the-position-of-an-element-relative-to-the-document-using-jquery.php">How to get the position of an element relative to the document using jQuery</a></li>
						<li><a href="faq/how-to-get-the-position-of-an-element-relative-to-the-parent-using-jquery.php">How to get the position of an element relative to the parent using jQuery</a></li>
						<li><a href="faq/how-to-find-mouse-position-relative-to-the-document-using-jquery.php">How to find mouse position relative to the document using jQuery</a></li>
						<li><a href="faq/how-to-find-mouse-position-relative-to-an-element-using-jquery.php">How to find mouse position relative to an element using jQuery</a></li>
						<li><a href="faq/how-to-get-substring-from-a-string-using-jquery.php">How to get substring from a string using jQuery</a></li> 					
						<li><a href="faq/show-read-more-link-if-the-text-exceeds-a-certain-length-using-jquery.php">How to show read more link if the text exceeds a certain length using jQuery</a></li>
						<li><a href="faq/how-to-get-current-image-size-in-javascript.php">How to get current image size in JavaScript</a></li>
						<li><a href="faq/how-to-get-original-image-size-in-javascript.php">How to get original image size in JavaScript</a></li>
						<li><a href="faq/how-to-increase-and-decrease-image-size-using-javascript.php">How to increase and decrease image size using JavaScript</a></li>
						<li><a href="faq/how-to-create-jquery-slide-up-and-down-toggle-effect.php">How to create jQuery slide up and down toggle effect</a></li>
						<li><a href="faq/how-to-create-jquery-slide-left-and-right-toggle-effect.php">How to create jQuery slide left and right toggle effect</a></li>
						<li><a href="faq/how-to-animate-div-height-on-mouse-hover-using-jquery.php">How to animate DIV height on mouse hover using jQuery</a></li>	
						<li><a href="faq/how-to-animate-div-width-on-mouse-hover-using-jquery.php">How to animate DIV width on mouse hover using jQuery</a></li>
						<li><a href="faq/how-to-play-and-stop-css-animation-using-jquery.php">How to play and stop CSS animation using jQuery</a></li>
						<li><a href="faq/how-to-disable-or-enable-a-form-element-using-jquery.php">How to disable or enable a form element using jQuery</a></li>
						<li><a href="faq/how-to-disable-all-input-controls-inside-a-form-using-jquery.php">How to disable all input controls inside a form using  jQuery</a></li>
						<li><a href="faq/how-to-check-or-uncheck-radio-button-dynamically-using-jquery.php">How to check or uncheck radio button dynamically using jQuery</a></li>
						<li><a href="faq/how-to-check-or-uncheck-a-checkbox-dynamically-using-jquery.php">How to check or uncheck a checkbox dynamically using jQuery</a></li>
						<li><a href="faq/how-to-remove-first-character-from-a-string-in-jquery.php">How to remove first character from a string in jQuery</a></li>
						<li><a href="faq/how-to-stop-firing-event-until-an-effect-is-finished-in-jquery.php">How to stop firing event until an effect is finished in jQuery</a></li>
						<li><a href="faq/how-to-check-if-an-element-exists-in-jquery.php">How to check if an element exists in jQuery</a></li>
						<li><a href="faq/move-an-element-to-left-right-up-and-down-using-arrow-keys-in-jquery.php">How to move an element to left, right, up and down using arrow keys in jQuery</a></li>	 	  		
						<li><a href="faq/how-to-animate-opacity-of-an-element-on-mouse-hover-using-jquery.php">How to animate opacity of an element on mouse hover using jQuery</a></li>
						<li><a href="faq/hide-dropdown-menu-on-click-outside-of-the-element-in-jquery.php">How to hide dropdown menu on click outside of the element in jQuery</a></li>
						<li><a href="faq/how-to-toggle-text-inside-an-element-on-click-using-jquery.php">How to toggle text inside an element on click using jQuery</a></li>
						<li><a href="faq/how-to-customize-file-input-type-using-css-and-jquery.php">How to customize file input type box using CSS and jQuery</a></li>
						<li><a href="faq/how-to-fire-event-on-file-select-in-jquery.php">How to fire event on file select in jQuery</a></li>
						<li><a href="faq/how-to-get-selected-file-name-from-input-type-file-using-jquery.php">How to get selected file name from input type file using jQuery</a></li>
						<li><a href="faq/auto-update-div-content-while-typing-in-textarea-using-jquery.php">How to update DIV content automatically while typing in textarea using jQuery</a></li>
						<li><a href="faq/how-to-insert-html-content-into-an-iframe-using-jquery.php">How to insert HTML content into an iFrame using jQuery</a></li>
						<li><a href="faq/how-to-call-a-function-repeatedly-after-fixed-time-interval-in-jquery.php">How to call a function repeatedly after fixed time interval in jQuery</a></li>
						<li><a href="faq/how-to-redirect-to-another-web-page-using-jquery.php">How to redirect to another web page using jQuery</a></li>
						<li><a href="faq/how-to-check-if-an-element-is-hidden-using-jquery.php">How to check if an element is hidden using jQuery</a></li>
						<li><a href="faq/how-to-select-all-visible-or-hidden-elements-in-a-page-using-jquery.php">How to select all visible or hidden elements in a page using jQuery</a></li>
						<li><a href="faq/how-to-add-remove-table-rows-dynamically-using-jquery.php">How to add or remove rows inside a table dynamically using jQuery</a></li>
						<li><a href="faq/how-to-move-an-element-into-another-element-using-jquery.php">How to move an element into another element using jQuery</a></li>
						<li><a href="faq/how-to-change-href-attribute-of-a-hyperlink-using-jquery.php">How to change href attribute of a hyperlink using jQuery</a></li>
						<li><a href="faq/how-to-refresh-a-page-with-jquery.php">How to refresh a page with jQuery</a></li>
						<li><a href="faq/how-to-select-an-element-with-multiple-classes-with-jquery.php">How to select an element with multiple classes with jQuery</a></li>
						<li><a href="faq/how-to-loop-through-an-array-in-javascript.php">How to loop through an array in JavaScript</a></li>
						<li><a href="faq/how-to-replace-character-inside-a-string-in-javascript.php">How to replace character inside a string in JavaScript</a></li>
						<li><a href="faq/how-to-explode-a-string-in-javascript.php">How to explode or split a string in JavaScript</a></li>
						<li><a href="faq/how-to-assign-block-of-html-code-to-a-javascript-variable.php">How to assign block of HTML code to a JavaScript variable</a></li>
						<li><a href="faq/how-to-display-all-items-in-array-using-loop-in-jquery.php">How to display all items or values in an array using loop in jQuery</a></li>
						<li><a href="faq/how-to-get-number-of-elements-in-a-div-using-jquery.php">How to get number of elements in a DIV using jQuery</a></li>
						<li><a href="faq/how-to-replace-all-occurrences-of-a-string-in-javascript.php">How to replace all occurrences of a string in JavaScript</a></li>
						<li><a href="faq/how-to-check-whether-a-value-is-numeric-or-not-in-jquery.php">How to check whether a value is numeric or not in jQuery</a></li>
						<li><a href="faq/how-to-replace-multiple-spaces-with-single-space-in-javascript.php">How to replace multiple spaces with single space in JavaScript</a></li>
						<li><a href="faq/how-to-detect-click-inside-iframe-using-javascript.php">How to detect click inside iframe using JavaScript</a></li>
						<li><a href="faq/how-to-determine-if-variable-is-undefined-or-null-in-javascript.php">How to determine if variable is undefined or null in JavaScript</a></li>
						<li><a href="faq/how-to-get-element-by-class-name-in-javascript.php">How to get element by class name in JavaScript</a></li>
						<li><a href="faq/how-to-detect-enter-key-press-on-keyboard-using-jquery.php">How to detect enter key press on keyboard using jQuery</a></li>
						<li><a href="faq/how-to-detect-the-enter-key-press-in-a-text-input-field-using-jquery.php">How to detect the enter key press in a text input field using jQuery</a></li>
						<li><a href="faq/how-to-change-the-background-color-of-a-web-page-using-javascript.php">How to change the background color of a web page using JavaScript</a></li>
						<li><a href="faq/how-to-check-if-a-variable-exists-or-defined-in-javascript.php">How to check if a variable exists or defined in JavaScript</a></li>
						<li><a href="faq/how-to-get-the-value-of-a-textarea-in-jquery.php">How to get the value of a textarea in jQuery</a></li>
						<li><a href="faq/how-to-make-the-first-letter-of-a-string-uppercase-in-javascript.php">How to make the first letter of a string uppercase in JavaScript</a></li>
						<li><a href="faq/how-to-create-multiline-strings-in-javascript.php">How to create multiline strings in JavaScript</a></li>
						<li><a href="faq/how-to-check-whether-a-string-contains-a-substring-in-javascript.php">How to check whether a string contains a substring in JavaScript</a></li>
						<li><a href="faq/how-to-encode-url-in-javascript.php">How to encode URL in JavaScript</a></li>
						<li><a href="faq/how-to-remove-duplicate-values-from-a-javascript-array.php">How to remove duplicate values from a JavaScript array</a></li>
						<li><a href="faq/how-to-remove-a-property-from-a-javascript-object.php">How to remove a property from a JavaScript object</a></li>
						<li><a href="faq/how-to-check-if-a-value-exists-in-an-array-in-javascript.php">How to check if a value exists in an array in JavaScript</a></li>
						<li><a href="faq/how-to-get-day-month-and-year-from-a-date-object-in-javascript.php">How to get day, month and year from a date object in JavaScript</a></li>
						<li><a href="faq/how-to-remove-a-particular-element-from-an-array-in-javascript.php">How to remove a particular element from an array in JavaScript</a></li>
						<li><a href="faq/how-to-change-the-class-of-an-element-using-javascript.php">How to change the class of an element using JavaScript</a></li>
						<li><a href="faq/how-to-convert-comma-separated-string-into-an-array-in-javascript.php">How to convert comma separated string into an array in JavaScript</a></li>
						<li><a href="faq/how-to-get-the-class-name-of-an-object-in-javascript.php">How to get the class name of an object in JavaScript</a></li>
						<li><a href="faq/how-to-check-for-an-empty-string-in-javascript.php">How to check for an empty string in JavaScript</a></li>
						<li><a href="faq/how-to-sort-an-array-of-integers-correctly-in-javascript.php">How to sort an array of integers correctly in JavaScript</a></li>
						<li><a href="faq/how-to-return-multiple-values-from-a-function-in-javascript.php">How to return multiple values from a function in JavaScript</a></li>
						<li><a href="faq/how-to-get-the-current-url-with-javascript.php">How to get the current URL with JavaScript</a></li>
						<li><a href="faq/how-to-include-a-javascript-file-in-another-javascript-file.php">How to include a JavaScript file in another JavaScript file</a></li>
						<li><a href="faq/how-to-detect-screen-resolution-with-javascript.php">How to detect screen resolution with JavaScript</a></li>
						<li><a href="faq/how-to-parse-json-in-javascript.php">How to parse JSON in JavaScript</a></li>
						<li><a href="faq/how-to-split-a-string-into-an-array-of-characters-in-javascript.php">How to split a string into an array of characters in JavaScript</a></li>
						<li><a href="faq/how-to-dynamically-access-object-property-using-variable-in-javascript.php">How to dynamically access object property using variable in JavaScript</a></li>
						<li><a href="faq/how-to-append-values-to-an-array-in-javascript.php">How to append values to an array in JavaScript</a></li>
						<li><a href="faq/how-to-generate-a-timestamp-in-javascript.php">How to generate a timestamp in JavaScript</a></li>
						<li><a href="faq/how-to-convert-js-object-to-json-string.php">How to convert JavaScript object to JSON string</a></li>
						<li><a href="faq/how-to-add-new-elements-at-the-beginning-of-an-array-in-javascript.php">How to add new elements at the beginning of an array in JavaScript</a></li>
						<li><a href="faq/how-to-get-the-value-of-text-input-field-using-javascript.php">How to get the value of text input field using JavaScript</a></li>
						<li><a href="faq/automatically-adjust-iframe-height-according-to-its-contents-using-javascript.php">How to adjust iFrame height automatically according to its contents using JavaScript</a></li>
						<li><a href="faq/how-to-call-multiple-javascript-functions-in-a-single-onclick-event.php">How to call multiple JavaScript functions in a single onclick event </a></li>
						<li><a href="faq/how-to-store-javascript-objects-in-html5-localstorage.php">How to store JavaScript objects in HTML5 localStorage </a></li>
						<li><a href="faq/how-to-get-portion-of-url-path-in-javascript.php">How to get portion of URL path in JavaScript</a></li>
						<li><a href="faq/how-to-add-a-class-to-a-given-element-in-javascript.php">How to add a class to a given element in JavaScript</a></li>
						<li><a href="faq/how-to-find-the-max-and-min-values-of-an-array-in-javascript.php">How to find the max and min values of an array in JavaScript</a></li>
						<li><a href="faq/how-to-check-if-an-object-property-is-undefined-in-javascript.php">How to check if an object property is undefined in JavaScript</a></li>
						<li><a href="faq/how-to-capture-browser-window-resize-event-in-javascript.php">How to capture browser window resize event in JavaScript</a></li>
						<li><a href="faq/how-to-reset-a-form-using-jquery.php">How to reset a form using jQuery</a></li>
						<li><a href="faq/how-to-detect-a-click-outside-of-an-element-with-jquery.php">How to detect a click outside of an element with jQuery</a></li>
						<li><a href="faq/how-to-detect-change-in-a-text-input-box-in-jquery.php">How to detect change in a text input box in jQuery</a></li>
						<li><a href="faq/how-to-foreach-over-an-array-in-javascript.php">How to foreach over an array in JavaScript</a></li>
						<li><a href="faq/how-to-check-if-an-input-field-is-empty-using-jquery.php">How to check if an input field is empty using jQuery</a></li>
						<li><a href="faq/how-to-get-the-children-of-the-this-selector-in-jquery.php">How to get the children of the this selector in jQuery</a></li>    
						<li><a href="faq/how-to-check-if-the-mouse-is-over-an-element-in-jquery.php">How to check if the mouse is over an element in jQuery</a></li>
						<li><a href="faq/how-to-scroll-to-the-top-of-the-page-using-jquery.php">How to scroll to the top of the page using jQuery</a></li>
						<li><a href="faq/how-to-insert-an-item-into-an-array-at-a-specific-index-in-javascript.php">How to insert an item into an array at a specific index in JavaScript</a></li>    
						<li><a href="faq/how-to-get-the-id-of-the-element-that-fired-an-event-in-jquery.php">How to get the id of the element that fired an event in jQuery</a></li>
						<li><a href="faq/how-to-find-the-sum-of-an-array-of-numbers-in-javascript.php">How to find the sum of an array of numbers in JavaScript</a></li>
						<li><a href="faq/how-to-check-if-an-array-includes-an-object-in-javascript.php">How to check if an array includes an object in JavaScript</a></li>
						<li><a href="faq/how-to-submit-a-form-using-jquery.php">How to submit a form using jQuery</a></li>
						<li><a href="faq/how-to-create-a-div-element-in-jquery.php">How to create a DIV element in jQuery</a></li>   
						<li><a href="faq/how-to-convert-a-js-object-to-an-array-using-jquery.php">How to convert a JS object to an array using jQuery</a></li>
						<li><a href="faq/how-to-change-the-image-source-using-jquery.php">How to change the image source using jQuery</a></li>
						<li><a href="faq/how-to-select-an-element-by-name-in-jquery.php">How to select an element by name in jQuery</a></li>
						<li><a href="faq/how-to-find-an-element-based-on-a-data-attribute-value-in-jquery.php">How to find an element based on a data-attribute value in jQuery</a></li>
						<li><a href="faq/how-to-set-css-background-image-property-using-jquery.php">How to set CSS background-image property using jQuery</a></li>
						<li><a href="faq/how-to-detect-a-mobile-device-in-jquery.php">How to detect a mobile device in jQuery</a></li>
						<li><a href="faq/how-to-get-the-data-id-attribute-of-an-element-using-jquery.php">How to get the data-id attribute of an element using jQuery</a></li>
						<li><a href="faq/how-to-check-if-object-is-an-array-in-javascript.php">How to check if object is an array in JavaScript</a></li>
						<li><a href="faq/how-to-remove-an-event-handler-in-jquery.php">How to remove an event handler in jQuery</a></li>
						<li><a href="faq/how-to-get-the-id-of-an-element-using-jquery.php">How to get the id of an element using jQuery</a></li>
						<li><a href="faq/how-to-add-options-to-a-select-box-from-a-js-object-using-jquery.php">How to add options to a select box from a JS object using jQuery</a></li>
						<li><a href="faq/how-to-replace-innerhtml-of-a-div-using-jquery.php">How to replace innerHTML of a div using jQuery</a></li>
						<li><a href="faq/how-to-add-li-in-an-existing-ul-using-jquery.php">How to add LI in an existing UL using jQuery</a></li>
						<li><a href="faq/how-to-get-the-value-in-an-input-text-box-using-jquery.php">How to get the value in an input text box using jQuery</a></li>
						<li><a href="faq/how-to-change-css-display-property-to-none-or-block-using-jquery.php">How to change CSS display property to none or block using jQuery</a></li>
						<li><a href="faq/how-to-set-the-value-of-input-text-box-using-jquery.php">How to set the value of input text box using jQuery</a></li>
						<li><a href="faq/how-to-change-the-text-of-a-button-using-jquery.php">How to change the text of a button using jQuery</a></li>
						<li><a href="faq/how-to-loop-through-elements-with-the-same-class-in-jquery.php">How to loop through elements with the same class in jQuery</a></li>
					</ul>
				</div>
				<hr />
				<div id="bootstrap-less">
					<h2>BOOTSTRAP&thinsp;/&thinsp;SASS</h2>
					<p class="subhead">This section contains a collection of frequently asked questions related to Bootstrap framework</p>
					<ul class="faq-list">
						<li><a href="faq/how-to-open-bootstrap-dropdown-menu-on-hover-rather-than-click.php">How to open Bootstrap dropdown menu on hover rather than click</a></li>
						<li><a href="faq/how-to-add-bootstrap-tooltip-to-an-icon.php">How to add bootstrap tooltip to an icon</a></li>
						<li><a href="faq/how-to-add-icons-to-input-submit-button-in-bootstrap.php">How to add icons to input submit button in Bootstrap</a></li>
						<li><a href="faq/how-to-align-bootstrap-modal-vertically-center.php">How to align Bootstrap modal vertically center</a></li>
						<li><a href="faq/how-to-embed-youtube-video-inside-bootstrap-modal.php">How to embed YouTube video inside Bootstrap modal</a></li>
						<li><a href="faq/how-to-change-the-default-width-of-bootstrap-modal-box.php">How to change the default width of Bootstrap modal box</a></li>
						<li><a href="faq/how-to-insert-close-button-in-bootstrap-popover.php">How to insert close button in Bootstrap popover</a></li>
						<li><a href="faq/how-to-make-bootstrap-popover-appear-disappear-on-hover-instead-of-click.php">How to make Bootstrap popover appear/disappear on hover instead of click</a></li>
						<li><a href="faq/how-to-insert-image-inside-bootstrap-popover.php">How to insert image inside Bootstrap popover</a></li>
						<li><a href="faq/how-to-disable-tabs-in-bootstrap.php">How to disable tabs in Bootstrap</a></li>
						<li><a href="faq/how-to-keep-the-current-tab-active-on-page-reload-in-bootstrap.php">How to keep the current tab active on page reload in Bootstrap</a></li>
						<li><a href="faq/how-to-launch-bootstrap-modal-on-page-load.php">How to launch Bootstrap modal on page load</a></li>
						<li><a href="faq/how-to-prevent-bootstrap-modal-from-closing-when-clicking-outside.php">How to prevent Bootstrap modal from closing when clicking outside</a></li>
						<li><a href="faq/how-to-remove-slide-down-effect-from-bootstrap-modal.php">How to remove slide down effect from Bootstrap modal</a></li>
						<li><a href="faq/how-to-set-focus-on-input-field-or-textarea-inside-a-bootstrap-modal.php">How to set focus on input field or textarea inside a Bootstrap modal on activation</a></li>
						<li><a href="faq/how-to-change-bootstrap-default-input-focus-glow-style.php">How to change Bootstrap default input focus glow style</a></li>
						<li><a href="faq/autoplay-youtube-video-inside-bootstrap-modal.php">Autoplay YouTube video inside Bootstrap modal</a></li>
					</ul>
				</div>
				<hr />
				<div id="php-mysql">
					<h2>PHP&thinsp;/&thinsp;MySQL</h2>
					<p class="subhead">This section contains a collection of frequently asked questions related to PHP and MySQL database</p>
					<ul class="faq-list">
						<li><a href="faq/how-to-write-comments-in-php.php">How to write comments in PHP</a></li>
						<li><a href="faq/how-to-remove-white-space-from-a-string-in-php.php">How to remove white space from a string in PHP</a></li>
						<li><a href="faq/how-to-find-number-of-characters-in-a-string-in-php.php">How to find number of characters in a string in PHP</a></li>
						<li><a href="faq/how-to-find-number-of-words-in-a-string-in-php.php">How to find number of words in a string in PHP</a></li>
						<li><a href="faq/how-to-remove-special-characters-from-a-string-in-php.php">How to remove special characters from a string in PHP</a></li>
						<li><a href="faq/how-to-replace-a-word-inside-a-string-in-php.php">How to replace a word inside a string in PHP</a></li>
						<li><a href="faq/how-to-prepend-a-string-in-php.php">How to prepend a string in PHP</a></li>
						<li><a href="faq/how-to-append-a-string-in-php.php">How append a string in PHP</a></li>
						<li><a href="faq/how-to-extract-substring-from-a-string-in-php.php">How to extract substring from a string in PHP</a></li>
						<li><a href="faq/how-to-compare-two-strings-in-php.php">How to compare two strings in PHP</a></li>
						<li><a href="faq/how-to-get-current-page-url-in-php.php">How to get current page URL in PHP</a></li>
						<li><a href="faq/how-to-create-a-string-by-joining-the-values-of-an-array-in-php.php">How to create a string by joining the values of an array in PHP</a></li>
						<li><a href="faq/how-to-split-a-string-into-an-array-in-php.php">How to split a string into an array in PHP</a></li>
						<li><a href="faq/how-to-combine-two-strings-in-php.php">How to combine two strings in PHP</a></li>
						<li><a href="faq/how-to-convert-a-string-to-lowercase-in-php.php">How to convert a string to lowercase in PHP</a></li>
						<li><a href="faq/how-to-convert-a-string-to-uppercase-in-php.php">How to convert a string to uppercase in PHP</a></li>
						<li><a href="faq/how-to-convert-the-first-letter-of-a-string-to-uppercase-in-php.php">How to convert the first letter of a string to uppercase in PHP</a></li>
						<li><a href="faq/how-to-convert-special-html-entities-back-to-characters-in-php.php">How to convert special HTML entities back to characters in PHP</a></li>
						<li><a href="faq/how-to-remove-white-space-from-the-beginning-of-a-string-in-php.php">How to remove white space from the beginning of a string in PHP</a></li>
						<li><a href="faq/how-to-remove-white-space-from-the-end-of-a-string-in-php.php">How to remove white space from the end of a string in PHP</a></li>
						<li><a href="faq/how-to-create-a-new-line-in-php.php">How to create a new line in PHP</a></li>
						<li><a href="faq/how-to-find-string-length-in-php.php">How to find string length in PHP</a></li>
						<li><a href="faq/how-to-check-whether-a-variable-is-set-or-not-in-php.php">How to check whether a variable is set or not in PHP</a></li>
						<li><a href="faq/how-to-check-whether-a-variable-is-empty-in-php.php">How to check whether a variable is empty in PHP</a></li>
						<li><a href="faq/how-to-check-whether-a-variable-is-null-in-php.php">How to check whether a variable is null in PHP</a></li>
						<li><a href="faq/how-to-reverse-a-string-in-php.php">How to reverse a string in PHP</a></li>
						<li><a href="faq/how-to-replace-the-part-of-a-string-with-another-string-in-php.php">How to replace the part of a string with another string in PHP</a></li>
						<li><a href="faq/counts-how-many-times-a-substring-occurs-in-a-string-in-php.php">How to count how many times a substring occurs in a string in PHP</a></li>
						<li><a href="faq/how-to-count-all-elements-in-an-array-in-php.php">How to count all elements in an array in PHP</a></li>
						<li><a href="faq/how-to-print-or-echo-all-the-values-of-an-array-in-php.php">How to print or echo all the values of an array in PHP</a></li>
						<li><a href="faq/how-to-display-array-structure-and-values-in-php.php">How to display array structure and values in PHP</a></li>
						<li><a href="faq/how-to-reverse-the-order-of-an-array-in-php.php">How to reverse the order of an array in PHP</a></li>
						<li><a href="faq/how-to-check-if-a-value-exists-in-an-array-in-php.php">How to check if a value exists in an array in PHP</a></li>
						<li><a href="faq/how-to-check-if-a-key-exists-in-an-array-in-php.php">How to check if a key exists in an array in PHP</a></li>
						<li><a href="faq/how-to-remove-the-last-element-from-an-array-in-php.php">How to remove the last element from an array in PHP</a></li>
						<li><a href="faq/how-to-remove-the-first-element-from-an-array-in-php.php">How to remove the first element from an array in PHP</a></li>
						<li><a href="faq/how-to-add-elements-to-the-beginning-of-an-array-in-php.php">How to add elements to the beginning of an array in PHP</a></li>
						<li><a href="faq/how-to-add-elements-to-the-end-of-an-array-in-php.php">How to add elements to the end of an array in PHP</a></li>
						<li><a href="faq/how-to-merge-two-or-more-arrays-into-one-array-in-php.php">How to merge two or more arrays into one array in PHP</a></li>
						<li><a href="faq/how-to-sort-an-array-values-alphabetically-in-php.php">How to sort an array values alphabetically in PHP</a></li>
						<li><a href="faq/how-to-remove-duplicate-values-from-an-array-in-php.php">How to remove duplicate values from an array in PHP</a></li>
						<li><a href="faq/how-to-randomize-the-order-of-an-array-in-php.php">How to randomize the order of an array in PHP</a></li>
						<li><a href="faq/how-to-compare-two-array-values-in-php.php">How to compare two array values in PHP</a></li>
						<li><a href="faq/how-to-calculate-the-sum-of-values-in-an-array-in-php.php">How to calculate the sum of values in an array in PHP</a></li>
						<li><a href="faq/how-to-remove-empty-values-from-an-array-in-php.php">How to remove empty values from an array in PHP</a></li>
						<li><a href="faq/how-to-populate-dropdown-list-with-array-values-in-php.php">How to populate dropdown list with array values in PHP</a></li>
						<li><a href="faq/how-to-get-all-the-keys-of-an-associative-array-in-php.php">How to get all the keys of an associative array in PHP</a></li>
						<li><a href="faq/how-to-get-all-the-values-from-an-associative-array-in-php.php">How to get all the values from an associative array in PHP</a></li>
						<li><a href="faq/how-to-sort-an-associative-array-by-key-in-php.php">How to sort an associative array by key in PHP</a></li>
						<li><a href="faq/how-to-sort-an-associative-array-by-value-in-php.php">How to sort an associative array by value in PHP</a></li>
						<li><a href="faq/how-to-get-single-value-from-an-array-in-php.php">How to get single value from an array in PHP</a></li>
						<li><a href="faq/foreach-loop-through-multidimensional-array-in-php.php">How to loop through multidimensional array in PHP</a></li>
						<li><a href="faq/how-to-delete-an-element-from-an-array-in-php.php">How to delete an element from an array in PHP</a></li>
						<li><a href="faq/how-to-check-if-a-string-contains-a-specific-word-in-php.php">How to check if a string contains a specific word in PHP</a></li>
						<li><a href="faq/how-to-get-the-current-date-and-time-in-php.php">How to get the current date and time in PHP</a></li>
						<li><a href="faq/how-to-make-a-redirect-in-php.php">How to make a redirect in PHP</a></li>
						<li><a href="faq/how-to-strip-all-spaces-out-of-a-string-in-php.php">How to strip all spaces out of a string in PHP</a></li>
						<li><a href="faq/how-to-get-the-current-year-using-php.php">How to get the current year using PHP</a></li>
						<li><a href="faq/how-to-convert-a-date-from-yyyy-mm-dd-to-dd-mm-yyyy-format-in-php.php">How to convert a date from yyyy-mm-dd to dd-mm-yyyy format in PHP</a></li>
						<li><a href="faq/how-to-convert-a-string-to-a-number-in-php.php">How to convert a string to a number in PHP</a></li>
						<li><a href="faq/how-to-get-the-first-element-of-an-array-in-php.php">How to get the first element of an array in PHP</a></li>
						<li><a href="faq/how-to-convert-a-date-to-timestamp-in-php.php">How to convert a date to timestamp in PHP</a></li>
					</ul>
				</div>
                <!--Bottom Navigation-->
                <div class="bottom-link clearfix">
                    <a href="javascript:void(0);" class="previous-page-bottom disabled" title="Disabled">Previous Page</a>
                    <a href="javascript:void(0);" class="next-page-bottom disabled" title="Disabled">Next Page</a>
                </div>
                <!--End:Bottom Navigation-->
                <!-- InstanceEndEditable -->
                <!--Bottom Ads-->
                <div class="bottom-ad clearfix">
                    <div class="ad-label">Advertisements</div>

<!--Rectangle Left-->
<div class="rectangle-left fl">
    
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Large Rectangle Left -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="8162953958"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
<!--End:Rectangle Left-->


<!--Rectangle Right-->
<div class="rectangle-right fr">

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Large Rectangle Right -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="3324015654"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
<!--End:Rectangle Right-->                </div>
                <!--End:Bottom Ads-->
            </div>
            <!--End:Text Content-->
            <!--Feedback Form-->
			<div class="snippets">
	<a href="/snippets/gallery.php" target="_blank">
    	<img src="/lib/images/bootstrap-code-snippets.png" alt="Bootstrap UI Design Templates" />
	</a>
</div>

<div class="report-error" id="feedback">
    <div class="contact-form clearfix">
        <div class="close"><span class="icon-close"></span></div>
        <form id="feedback-form">
            <h3>Your Feedback:</h3>
            <div class="clearfix">
                <div class="name fl"><label>Your Name (optional) <input type="text" name="user-name" id="user-name" /></label></div>
                <div class="email fr"><label>Your E-mail (optional) <input type="text" name="user-email" id="user-email" /></label></div>
            </div>
            <div><label>Page address <input type="text" name="page-url" id="page-url" class="disabled" disabled="disabled" /></label></div>
            <div><label>Description <textarea name="description" id="description" rows="6"></textarea></label></div>
            <p id="feedback-error">We would love to hear from you, please drop us a line.</p>
            <div><button type="button" class="action-btn" onclick="sendFeedback()"><span class="icon-send"></span> Send</button></div>
        </form>
        <div id="response"></div>
    </div>           
</div>            <!--End:Feedback Form-->
        </div>        
        <div class="sidebar">
            <div class="ad-label">Advertisements</div>

<div class="skyscraper primary">

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Premium Skyscraper -->
<ins class="adsbygoogle"
     style="display:inline-block;width:160px;height:600px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="4376141825"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>

<div class="skyscraper">
    
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Bottom Skyscraper -->
<ins class="adsbygoogle"
     style="display:inline-block;width:160px;height:600px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="3387984471"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>        </div>
    </div>
    <!--Footer-->
	<!--Footer-->
<div class="footer">
    <div class="appeal">
        <div class="wrapper">
            <p>Is this website helpful to you? Please give us a
            <a href="/like.php" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=250,width=600,top=150, left='+((screen.width/2)-300));return false;">like</a>,
            or share your <a href="#feedback" class="feedback">feedback</a><em> to help us improve</em>.
            Connect with us on <a href="https://www.facebook.com/tutorialrepublic" target="_blank">Facebook</a> and <a href="https://twitter.com/tutrepublic" target="_blank">Twitter</a> for the latest updates.</p>               
        </div>
    </div>
    <div class="footer-inner">
        <div class="wrapper clearfix">                
            <div class="link-box">
                <h4>About Us</h4>
                <div class="clearfix">
                    <a href="/about-us.php">Our Story</a>                    
                    <a href="/terms-of-use.php">Terms of Use</a>
                    <a href="/privacy-policy.php">Privacy Policy</a>                    
                </div>
            </div>
            <div class="link-box">
                <h4>Contact</h4>
                <div class="clearfix">
                    <a href="/contact-us.php">Contact Us</a>                    
                    <a href="#feedback" class="feedback">Report Error</a>
                    <a href="/advertise-with-us.php">Advertise</a>                    
                </div>
            </div>
            <div class="tool-box">
                <h4>Interactive Tools</h4>
                <div class="tools-list clearfix" id="tools">
                    <a href="/faq/what-is-the-maximum-length-of-title-and-meta-description-tag.php">Title &amp; Meta Length Calculator</a>                           
                    <a href="/html-formatter.php" target="_blank">HTML Formatter</a>                        
                    <a href="/twitter-bootstrap-button-generator.php" target="_blank">Bootstrap Button Generator</a>
                    <a href="/html-reference/html-color-picker.php">HTML Color Picker</a>
                    <a href="/codelab.php?topic=sql&amp;file=select-all" target="_blank">SQL Playground</a>
                    <a href="/codelab.php?topic=html&amp;file=hello-world" target="_blank">HTML Editor</a>                    
                </div>
            </div>
            <div class="footer-logo">
                <img src="/lib/images/logo.svg" alt="TutorialRepublic" />
            </div>
        </div>
    </div>           
        <div class="bottom-strip">
        <div class="wrapper">
            <div class="notice">Copyright &copy; 2019 Tutorial Republic. All Rights Reserved.</div>
            <div class="social-media">
                <em>Share This:</em>
                <a href="https://facebook.com/sharer.php?u=https://www.tutorialrepublic.com%2Ffaq.php" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" title="Facebook"><i class="icon-facebook"></i></a>
                <a href="#" id="tweet-btn" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" title="Twitter"><i class="icon-twitter"></i></a>
                <a href="#" id="email-btn" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" rel="noreferrer" title="Gmail"><i class="icon-mail"></i></a>
            </div>
        </div>            
    </div>
    <script>
        var title = document.title.replace('- Tutorial Republic', '');
        document.getElementById('tweet-btn').href = 'https://twitter.com/share?text=' + title + '- &url=https://www.tutorialrepublic.com%2Ffaq.php';
        document.getElementById('email-btn').href = 'https://mail.google.com/mail/?view=cm&fs=1&su=' + title + '&body=https://www.tutorialrepublic.com%2Ffaq.php';
    </script>
</div>
<!--End:Footer-->
    
<div class="backdrop mobile-only"></div>

<!-- TutorialRepublic base script -->
<script>
// Adding CSS files
[
	'/lib/styles/extended-3.7.css',
	'/lib/icomoon/style.css'
].forEach(function(href) {
	var link = document.createElement('link');
	link.rel = 'stylesheet';
	link.href = href;
	(document.getElementsByTagName('head')[0]).appendChild(link);
});

// Adding JS files
[
	'https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js',
	'/lib/js/prism.js',
	'/lib/js/default-2.9.min.js'
].forEach(function(src) {
	var script = document.createElement('script');
	script.async = false; // important
	script.src = src;
	(document.getElementsByTagName('body')[0]).appendChild(script);
});
</script>


    <!--End:Footer-->
</body>
<!-- InstanceEnd --></html>