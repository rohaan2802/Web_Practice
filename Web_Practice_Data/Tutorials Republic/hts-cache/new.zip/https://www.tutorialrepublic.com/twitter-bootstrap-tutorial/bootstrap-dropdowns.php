<!DOCTYPE html>
<html lang="en"><!-- InstanceBegin template="/Templates/bootstrap.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
	<!-- InstanceBeginEditable name="doctitle" -->
    <title>How to Create Dropdown Menu with Bootstrap 4 - Tutorial Republic</title>
    <meta name="description" content="Learn how to add dropdown menu to links, buttons, navs and navbar etc. quickly and easily with the Bootstrap dropdown plugin without writing any JavaScript code." />
    <!-- InstanceEndEditable -->
    	<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta property="fb:admins" content="100001054961582" />
<meta property="fb:app_id" content="1404574483159557" />
<meta property="og:image" content="/lib/images/signature.png" />
<link type="image/x-icon" href="/favicon.ico" rel="shortcut icon" />
<style>
html,body,h1,h2,h3,h4,h5,h6,p,blockquote,pre,img{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}
html,body{min-height:100%}
p{margin:0 0 12px}
ol,ul{margin:0 0 12px}
a,a:active,a:visited{outline:none;color:#1db79f;text-decoration:none}
a img{border:none;outline:none}
a code{color:inherit;background:none}
p code,table td:last-child code,.content ul li code,code.mark{padding:2px 4px;color:#333;background-color:#f1f1f1;border-radius:4px}
table{border-collapse:collapse;border-spacing:0}
table td{vertical-align:top}
body{min-width:1300px;color:#414141;background:#fafafa;font-family:"Segoe UI","Helvetica Neue",Arial,sans-serif;font-size:17px;line-height:1.7}
input,select,textarea,button,div,span,a{box-sizing:border-box}
h1,h2,h3,h4{color:#262626;font-weight:500;margin:20px 0 10px;line-height:1.5;font-weight:600}
h1{font-size:34px;margin-top:17px}
h2{font-size:28px}
h3{font-size:22px}
.space{margin-bottom:25px!important}
.break{margin-bottom:15px!important}
.text-center{text-align:center!important}
.scroll{height:195px;overflow-y:scroll}
.scroll.large{height:245px}
.scroll.xlarge{height:290px}
.scroll.xxlarge{height:340px}
sup{font-size:13px}
.leaderboard{padding-top:8px;position:relative}
.ad-container{height:90px;overflow:hidden}
.intro-image img{display:block;padding:10px 0 25px;max-width:100%}
.clearfix::after{content:".";display:block;height:0;clear:both;visibility:hidden}
code,.code,.syntax,.green-box,.sky-box,.gray-box,.pink-box,.red-box,.at-rule,.codebox pre,.console-output{font-size:16px;font-family:Consolas,Monaco,Courier,monospace}
.console-output{margin:15px 0}
hr{border:none;border-bottom:1px solid #e7e9ed;height:1px;margin:30px 0}
.summary,.topic{border:1px solid #eaeaea;border-width:1px 0;margin:20px 0;padding:10px 0;color:#8e9aa6;line-height:1.5}
h2.section-title span{display:inline-block;border-bottom:4px solid #c9d7e0;padding:0 50px 12px 0}
.wrapper{width:1300px;padding:0 15px;margin:0 auto}
.header{background:#23384e;padding:16px 0}
input.search{background:#fff;border:0 none;color:#807E7E;float:left;height:38px;line-height:26px;font-size:14px;margin:0 0 0 12px;outline:medium none;padding:6px 14px;width:500px;border-radius:2px;box-shadow:0 0 1px rgba(0,0,0,0.6);font-family:inherit}
.search-btn{color:rgba(0,0,0,.6);background:#ebebeb;border:none;outline:none;cursor:pointer;float:left;height:38px;line-height:46px;width:44px;display:block;margin-left:-2px;border-radius:0 2px 2px 0;box-shadow:0 0 1px rgba(0,0,0,0.7)}
.logo{width:304px}
.logo img{height:44px;margin:-3px 0;display:block}
.site-search{float:left;margin-left:100px}
.menu{background-color:#f5f5f5;box-shadow:0 1px 1px rgba(0,0,0,.15);position:relative;z-index:9}
.menu a{color:#666;display:inline-block;padding:0 10px;text-decoration:none;font-size:14px;font-weight:600;height:48px;line-height:48px}
.menu a:first-child{margin-left:-10px}
.menu a.tool-link{float:right;display:inline-block;border-radius:30px;line-height:28px;position:relative;height:auto;top:9px;padding:0 12px;color:#1ebba3;border:1px double #1ebba3}
.fl,.logo{float:left}
.leftcolumn{width:240px;float:left;font-size:16px;color:#4f4f4f}
.centercolumn{width:850px;float:left}
.content{background:#fff;padding:20px 40px;border:1px solid #dedede;border-top:none;border-radius:1px}
.sidebar{width:160px;float:left;padding-top:28px;margin-left:20px;position:relative}
.leftcolumn .segment{margin:16px 0 12px;position:relative;font-size:18px;font-weight:600;line-height:normal}
.leftcolumn a{color:#4f4f4f;font-size:16px;line-height:26px;display:block;border-bottom:1px solid transparent}
.leftcolumn ul{list-style:none;padding:0}
.segment,.chapters,.chapters a{float:left;clear:both}
h1 code,h2 code,h3 code{font:inherit}
.color-box{margin:15px 0;padding-left:20px}
.note-box,.warning-box,.tip-box{padding:8px 8px 3px 26px}
.info-tab{float:left;margin-left:-23px}
.content ul li{margin-top:7px}
.extra{padding-top:5px}
.green-box,.sky-box,.gray-box,.red-box,.pink-box{color:#000;margin-top:15px;padding:10px;background-color:#f6f8fa;border:1px solid #d7e2ec}
.example{background:#f4f5f6;padding:3px;margin:15px 0}
.codebox{background:#fff;border:1px solid #ddd}
.codebox-title{height:41px;padding-left:12px;border-bottom:1px solid #ddd;background:#f5f5f5}
.codebox-title h4{margin:0;font-size:18px;line-height:40px;float:left;display:inline;font-weight:500}
a.try-btn,a.download-btn{width:140px;height:40px;color:#333;font-size:15px;line-height:41px;font-weight:600;text-align:center;text-decoration:none;float:right;display:block;border-left:1px solid #ddd;background:rgba(27,31,35,0.08);box-sizing:border-box;font-family:Arial,sans-serif}
a.try-btn span{font-size:18px;line-height:normal}
.hide,.code-style,.box-size,.bottom-link,.footer,.code-style,.snippets,.report-error,.badge,.social,.ad-label,.mobile-only{display:none}
.skyscraper{width:160px;height:600px;overflow:hidden;margin-bottom:20px;background:#ebecf0}
.bottom-ad{margin-top:46px;padding:24px;position:relative;background:url(/lib/images/smooth-line.png) no-repeat center #f9f9f9}
.rectangle-left,.rectangle-right{min-width:336px;min-height:280px;overflow:hidden}
.fr,a.previous-page,a.next-page,.rectangle-right,.topic-nav{float:right}
a.previous-page,a.next-page{width:32px;height:32px;line-height:30px}
.shadow{background:#F7F8F9;padding:3px;margin:10px 0}
.syntax{color:#2f4959;padding:13px 18px;background:#F9F9FA;border:1px solid #ddd;font-size:15px}
code[class*="language-"],pre[class*="language-"]{color:#000;background:none;font-family:Consolas,Monaco,'Andale Mono','Ubuntu Mono',monospace;text-align:left;white-space:pre;word-break:normal;word-wrap:normal;line-height:1.5;tab-size:4;hyphens:none}
pre[class*="language-"]{position:relative;margin:.5em 0;overflow:visible;padding:0}
pre[class*="language-"]>code{position:relative;border-left:10px solid #358ccb;box-shadow:-1px 0 0 0 #358ccb,0 0 0 1px #dfdfdf;background-color:#fdfdfd;background-image:linear-gradient(transparent 50%,rgba(69,142,209,0.04) 50%);background-size:3em 3em;background-origin:content-box;background-attachment:local}
code[class*="language"]{max-height:inherit;height:inherit;padding:0 1em;display:block;overflow:auto}
:not(pre) > code[class*="language-"]{position:relative;padding:.2em;border-radius:.3em;color:#c92c2c;border:1px solid rgba(0,0,0,0.1);display:inline;white-space:normal}
pre[class*="language-"].line-numbers{padding-left:0}
pre[class*="language-"].line-numbers code{padding-left:3.8em}
pre[class*="language-"].line-numbers .line-numbers-rows{left:0}
pre[class*="language-"][data-line]{padding-top:0;padding-bottom:0;padding-left:0}
pre[data-line] code{position:relative;padding-left:4em}
pre .line-highlight{margin-top:0}
pre.line-numbers{position:relative;padding-left:3.8em;counter-reset:linenumber;white-space:pre-wrap!important}
pre.line-numbers > code{position:relative;white-space:inherit}
.line-numbers-rows,.codebox pre.inactive{display:none}
.codebox pre.syntax-highlighter{margin:0;padding:0;overflow:auto}
pre.line-numbers .line-numbers-rows{border-right:3px solid #6CE26C}
.codebox pre.syntax-highlighter > code{box-shadow:none!important;padding-left:3.8em;background-image:linear-gradient(transparent 50%,#F8F8F8 50%);font-family:Consolas,Monaco,'Andale Mono','Ubuntu Mono',monospace!important;font-size:16px;line-height:1.5}
.codebox pre.syntax-highlighter,.codebox pre.syntax-highlighter code{border:none;width:100%;box-sizing:border-box}
pre.line-numbers code,pre.line-numbers .line-numbers-rows{padding-top:2px;padding-bottom:2px}
.preview-box{padding:15px;text-align:center;cursor:pointer;overflow:hidden;background:#FFF;border:1px solid #e6e6e6}
.preview-box a,.preview-box img{display:block;margin:0 auto}
.download-box{text-align:center;padding:20px 0;margin:20px 0 10px}
.output-box{border-color:#d4d4d4;border-style:solid;border-width:1px 0;padding:5px 15px;overflow:hidden;background:#fff;margin:10px 0}
.demo-box{margin-top:15px}
.subhead{border-bottom:3px solid #DCE3EB;margin-bottom:15px;padding-bottom:10px}
table.data,table.description{width:100%;font-size:92%}
table.data th{color:#000;padding:8px 7px;text-align:left;font-size:15px;background:#F8F8F8}
table.data td{color:#484848;padding:5px 7px;background:#fff}
table.data th,table.data td{vertical-align:top;border:1px solid #DCE3EB}
table.data tr.section th,table.data td.section{font-size:15px;background:#f0f4f7}
table.no-wrap tr td:first-child{white-space:nowrap}
@media screen and (max-width: 1280px) {
body{min-width:1260px}
.wrapper{width:1260px}
.leftcolumn{width:230px}
.centercolumn{width:820px}
}
@media screen and (max-width: 800px) {
body{min-width:100%;max-width:100%;padding-top:46px}
.wrapper{width:100%;padding:0}
.header{height:46px;padding:5px 0;position:fixed;top:0;left:0;right:0;width:100%;z-index:99}
.logo{width:auto;display:block;padding:6px 0 0 60px;position:absolute;left:0;z-index:100}
.logo img{height:30px}
.menu{width:100%;padding-left:12px;padding-right:12px;overflow-x:auto;white-space:nowrap}
.centercolumn{width:100%;float:none}
.content{padding:10px;border-width:0 0 1px 0}
.content img{max-width:100%;height:auto}
.content pre{max-width:100%;overflow:hidden}
.skyscraper{display:inline-block}
.shadow,.example,.console-output{max-width:100%;overflow-x:auto}
.codebox-title{position:relative}
.codebox.multi-style-mode pre{padding-top:7px;margin-top:36px;border-top:1px solid #ddd}
.bottom-ad{height:auto;background:none;padding:30px 0 0;margin:40px 0 0;text-align:center;position:relative}
.rectangle-left,.rectangle-right{float:none;display:inline-block;margin:10px auto;background:#EDEEF2}
.leftcolumn,.footer,.social,.site-search,.code-style,.menu a.tool-link,.backdrop{display:none}
.summary,.topic{padding:5px 0;margin:10px 0}
.leftcolumn,.centercolumn,.sidebar{float:none}
.header,.menu,.centercolumn,.footer,.appeal-text{width:100%}
a.try-btn,a.download-btn{width:130px}
.native-unit{margin-bottom:30px}
.sidebar{margin: 25px auto 0}
.overview{padding-right:0}
.scroll-pane{overflow-x:auto}
table.data{min-width:480px}
table.data pre{display:inline;white-space:normal}
table tr th,table tr td{width:auto!important}
.preview-box{padding:6px}
.leaderboard{margin:20px 0}
h1{font-size:30px}
h2{font-size:24px}
h3{font-size:20px}
.codebox pre.syntax-highlighter{overflow-x:auto}
.codebox pre.syntax-highlighter > code{width:614px;height:auto;overflow-x:hidden}
}
@media screen and (min-width: 801px) {
.site-search,.leftcolumn,.social{display:block!important}
.backdrop{display:none!important}
.hide-scroll{overflow-x:hidden!important}
}</style>    
    <!-- InstanceBeginEditable name="head" -->
    <!-- InstanceEndEditable -->
    
    <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-40117907-1', 'auto');
  ga('send', 'pageview');
</script></head>
<body>
    <!--Header-->
    
<div class="header">
    <div class="wrapper clearfix">
        <button type="button" class="open-menu mobile-only"><i class="icon-menu"></i></button>
        <div class="logo">
            <a href="https://www.tutorialrepublic.com/"><img src="/lib/images/logo.svg" alt="TutorialRepublic" /></a>
        </div>
        <div class="site-search">
            <form action="https://www.google.com/search" method="get" target="_blank" class="clearfix">
                <input type="hidden" value="www.tutorialrepublic.com" name="sitesearch" />
                <input type="text" name="q" placeholder="Search topics, tutorials, questions and answers..." id="searchInput" class="search" />
                <button type="submit" class="search-btn"><span class="icon-search"></span></button>
            </form>
        </div>
        <div class="social">                
            <a href="https://www.facebook.com/tutorialrepublic" target="_blank" title="Join us on Facebook"><i class="icon-facebook"></i></a>
            <a href="https://twitter.com/tutrepublic" target="_blank" title="Follow us on Twitter"><i class="icon-twitter"></i></a>
            <a href="/contact-us.php" target="_blank" title="Send us an Email"><i class="icon-mail"></i></a>
        </div>
        <button type="button" class="open-search mobile-only">
            <i class="icon-search"></i>
        </button>
    </div>    
</div>
<div class="menu">
    <div class="wrapper">
        <a href="//www.tutorialrepublic.com" title="Home Page">HOME</a>
        <a href="/html-tutorial/" title="HTML Tutorial">HTML5</a>            
        <a href="/css-tutorial/" title="CSS Tutorial">CSS3</a>
        <a href="/javascript-tutorial/" title="JavaScript Tutorial">JAVASCRIPT</a>
        <a href="/jquery-tutorial/" title="jQuery Tutorial">JQUERY</a>
        <a href="/twitter-bootstrap-tutorial/" title="Bootstrap Tutorial">BOOTSTRAP4</a>
        <a href="/php-tutorial/" title="PHP Tutorial">PHP7</a> 
        <a href="/sql-tutorial/" title="SQL Tutorial">SQL</a>
        <a href="/references.php" title="Web References">REFERENCES</a>
        <a href="/practice-examples.php" title="Practice Examples and Demos">EXAMPLES</a>
        <a href="/faq.php" title="Frequently Asked Questions and Answers">FAQ</a>
        <a href="/snippets/gallery.php" title="Bootstrap Code Snippets" target="_blank">SNIPPETS</a>
        <a href="/codelab.php" class="tool-link" target="_blank">Online HTML Editor</a>
    </div>        
</div>    <!--End:Header-->
    <div class="wrapper clearfix">
        <div class="leftcolumn" id="myNav">
		
        <div class="segment"><span>BOOTSTRAP</span> BASIC</div>
<div class="chapters">
    <a href="/twitter-bootstrap-tutorial/">Bootstrap Introduction</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-get-started.php">Bootstrap Getting Started</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-grid-system.php">Bootstrap Grid System</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-fixed-layout.php">Bootstrap Fixed Layout</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-fluid-layout.php">Bootstrap Fluid Layout</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-responsive-layout.php">Bootstrap Responsive Layout</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-typography.php">Bootstrap Typography</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-tables.php">Bootstrap Tables</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-lists.php">Bootstrap Lists</a>
	<a href="/twitter-bootstrap-tutorial/bootstrap-list-groups.php">Bootstrap List Groups</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-forms.php">Bootstrap Forms</a>
	<a href="/twitter-bootstrap-tutorial/bootstrap-custom-forms.php">Bootstrap Custom Forms</a>
	<a href="/twitter-bootstrap-tutorial/bootstrap-input-groups.php">Bootstrap Input Groups</a>
	<a href="/twitter-bootstrap-tutorial/bootstrap-buttons.php">Bootstrap Buttons</a>
	<a href="/twitter-bootstrap-tutorial/bootstrap-button-groups.php">Bootstrap Button Groups</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-images.php">Bootstrap Images</a>
	<a href="/twitter-bootstrap-tutorial/bootstrap-cards.php">Bootstrap Cards</a>
	<a href="/twitter-bootstrap-tutorial/bootstrap-media-objects.php">Bootstrap Media Objects</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-icons.php">Bootstrap Icons</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-navs.php">Bootstrap Navs</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-navbar.php">Bootstrap Navbar</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-breadcrumbs.php">Bootstrap Breadcrumbs</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-pagination.php">Bootstrap Pagination</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-badges.php">Bootstrap Badges</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-progress-bars.php">Bootstrap Progress Bars</a>
	<a href="/twitter-bootstrap-tutorial/bootstrap-spinners.php">Bootstrap Spinners</a>
	<a href="/twitter-bootstrap-tutorial/bootstrap-jumbotron.php">Bootstrap Jumbotron</a>
	<a href="/twitter-bootstrap-tutorial/bootstrap-helper-classes.php">Bootstrap Helper Classes</a>
</div>
<div class="segment"><span>BOOTSTRAP</span> ADVANCED</div>
<div class="chapters">
	<a href="/twitter-bootstrap-tutorial/bootstrap-modals.php">Bootstrap Modals</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-dropdowns.php">Bootstrap Dropdowns</a>
	<a href="/twitter-bootstrap-tutorial/bootstrap-tabs.php">Bootstrap Tabs</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-tooltips.php">Bootstrap Tooltips</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-popovers.php">Bootstrap Popovers</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-alerts.php">Bootstrap Alerts</a>
	<a href="/twitter-bootstrap-tutorial/bootstrap-stateful-buttons.php">Bootstrap Stateful Buttons</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-accordion.php">Bootstrap Accordion</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-carousel.php">Bootstrap Carousel</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-typeahead.php">Bootstrap Typeahead</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-scrollspy.php">Bootstrap ScrollSpy</a>
	<a href="/twitter-bootstrap-tutorial/bootstrap-toasts.php">Bootstrap Toasts</a>
</div>
<div class="segment"><span>BOOTSTRAP</span> EXAMPLES</div>
<div class="chapters">
    <a href="/twitter-bootstrap-examples.php">Bootstrap Practice Examples</a>
	<a href="/faq.php#bootstrap-less">Bootstrap FAQ's Answers</a>
</div>
<div class="segment"><span>BOOTSTRAP</span> ARCHIVE</div>
<div class="chapters">
    <a href="/twitter-bootstrap-3-tutorial/">Bootstrap 3 Tutorial</a>
	<a href="/twitter-bootstrap-3-examples.php">Bootstrap 3 Practice Examples</a>
</div>        
                </div>
        <div class="centercolumn">
            <!--Text Content-->
            <div class="content">
                <div class="leaderboard">
                    
<div class="ad-label">Advertisements</div>
<div class="ad-container">
    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <!-- Responsive Leaderboard -->
    <ins class="adsbygoogle"
            style="display:inline-block;max-width:728px;width:100%;height:90px"
            data-ad-client="ca-pub-9107540490929984"
            data-ad-slot="4302666817"></ins>
    <script>
    (adsbygoogle = window.adsbygoogle || []).push({});
    </script>
</div>                </div>
                <!-- InstanceBeginEditable name="main_content" -->
                <a href="bootstrap-modals.php" class="previous-page" title="Go to Previous Page"></a>
            	<a href="bootstrap-tabs.php" class="next-page" title="Go to Next Page"></a>
                <h1>Bootstrap <span>Dropdowns</span></h1>
                <p class="summary">In this tutorial you will learn how to add dropdown menus to various components using the Bootstrap dropdown plugin.</p>
                <h2>Creating Dropdown Menus with Bootstrap</h2>
				<p>The dropdown menu is typically used inside the navigation header to display a list of related links when a user mouse hover or click on the trigger element.</p>
                <p class="space">You can use the Bootstrap dropdown plugin to add toggleable dropdown menus (i.e. open and close on click) to almost anything such as links, buttons or button groups, navbar, tabs and pills nav etc. without even writing a single line of JavaScript code.</p>
                <h2>Adding Dropdowns via Data Attributes</h2>
                <p>Bootstrap provides an easy and elegant mechanism for adding the dropdown menu to an element via data attributes. The following example will show you the minimum markup required for adding a dropdown menu to the hyperlink via data attributes.</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=adding-dropdowns-via-data-attributes" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-markup">&lt;div class="dropdown"&gt;
    &lt;a href="#" class="dropdown-toggle" data-toggle="dropdown"&gt;Dropdown&lt;/a&gt;
    &lt;div class="dropdown-menu"&gt;
        &lt;a href="#" class="dropdown-item"&gt;Action&lt;/a&gt;
        &lt;a href="#" class="dropdown-item"&gt;Another action&lt;/a&gt;
    &lt;/div&gt;
&lt;/div&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <p class="space">The above example demonstrates the most basic form of the Bootstrap dropdowns. Let's understand each part of the Bootstrap dropdown component one by one.</p>
                <h2>Explanation of Code</h2>
                <p>The Bootstrap dropdown has basically two components &mdash; the dropdown trigger element which can be a hyperlink or button, and the dropdown menu itself.</p>
                <ul>
                	<li>The <code>.dropdown</code> class specifies a dropdown menu.</li>
                    <li>The <code>.dropdown-toggle</code> class defines the trigger element, which is a hyperlink in our case, whereas the attribute <code>data-toggle="dropdown"</code> is required on the trigger element to toggle the dropdown menu.</li>
                    <li>The <a href="#"><code>&lt;div&gt;</code></a> element with the class <code>.dropdown-menu</code> is actually building the dropdown menu that typically contains the related links or actions.</li>
                </ul>
				<p>Similarly, you can add the dropdowns to the buttons and nav components. The following section will show you some common implementation of the Bootstrap dropdown.</p>
				<hr />
				<h2>Dropdowns within a Navbar</h2>
                <p>The following examples will show you how to add dropdowns to navbar.</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=dropdowns-within-navbar" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a><span class="box-size"><i title="Maximize"></i></span></div>
                        <pre class="syntax-highlighter line-numbers scroll xxlarge"><code class="language-markup">&lt;nav class="navbar navbar-expand-md navbar-light bg-light"&gt;
    &lt;a href="#" class="navbar-brand"&gt;Brand&lt;/a&gt;
    &lt;button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse"&gt;
        &lt;span class="navbar-toggler-icon"&gt;&lt;/span&gt;
    &lt;/button&gt;
    &lt;div id="navbarCollapse" class="collapse navbar-collapse"&gt;
        &lt;ul class="nav navbar-nav"&gt;
            &lt;li class="nav-item"&gt;
                &lt;a href="#" class="nav-link"&gt;Home&lt;/a&gt;
            &lt;/li&gt;
            &lt;li class="nav-item"&gt;
                &lt;a href="#" class="nav-link"&gt;Profile&lt;/a&gt;
            &lt;/li&gt;
            &lt;li class="nav-item dropdown"&gt;
                &lt;a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown"&gt;Messages&lt;/a&gt;
                &lt;div class="dropdown-menu"&gt;
                    &lt;a href="#" class="dropdown-item"&gt;Inbox&lt;/a&gt;
                    &lt;a href="#" class="dropdown-item"&gt;Drafts&lt;/a&gt;
                    &lt;a href="#" class="dropdown-item"&gt;Sent Items&lt;/a&gt;
                    &lt;div class="dropdown-divider"&gt;&lt;/div&gt;
                    &lt;a href="#"class="dropdown-item"&gt;Trash&lt;/a&gt;
                &lt;/div&gt;
            &lt;/li&gt;
        &lt;/ul&gt;
        &lt;ul class="nav navbar-nav ml-auto"&gt;
            &lt;li class="nav-item dropdown"&gt;
                &lt;a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown"&gt;Admin&lt;/a&gt;
                &lt;div class="dropdown-menu dropdown-menu-right"&gt;
                    &lt;a href="#" class="dropdown-item"&gt;Reports&lt;/a&gt;
                    &lt;a href="#" class="dropdown-item"&gt;Settings&lt;/a&gt;
                    &lt;div class="dropdown-divider"&gt;&lt;/div&gt;
                    &lt;a href="#"class="dropdown-item"&gt;Logout&lt;/a&gt;
                &lt;/div&gt;
            &lt;/li&gt;
        &lt;/ul&gt;
    &lt;/div&gt;
&lt;/nav&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <p>&mdash; The output of the above example will look something like this:</p>
                <div class="shadow space">
                    <div class="preview-box">
                        <a href="../codelab.php?topic=bootstrap&amp;file=dropdowns-within-navbar" target="_blank">
                            <img src="../lib/images/bootstrap-4/bootstrap-dropdowns-within-navbar.png" width="730" height="68" alt="Bootstrap Dropdowns within Navbar" />
                        </a>
                    </div>
                </div>
				<!--Tip Box-->
				<div class="color-box">
					<div class="shadow">
						<div class="info-tab tip-icon" title="Useful Tips"><i></i></div>
						<div class="tip-box">
							<p><strong>Tip:</strong> You can draw a divider line to separate the links inside a dropdown menu by adding the class <code>.dropdown-divider</code> on a blank <code>&lt;div&gt;</code> element.</p>
						</div>
					</div>
				</div>
				<!--End:Tip Box-->
                <hr />
                <h2>Dropdowns within Navs</h2>
                <p>The following example will show you how to add dropdowns to pills navs.</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=dropdowns-within-nav" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a><span class="box-size"><i title="Maximize"></i></span></div>
                        <pre class="syntax-highlighter line-numbers scroll xxlarge"><code class="language-markup">&lt;ul class="nav nav-pills"&gt;
    &lt;li class="nav-item"&gt;
        &lt;a href="#" class="nav-link active"&gt;Home&lt;/a&gt;
    &lt;/li&gt;
    &lt;li class="nav-item"&gt;
        &lt;a href="#" class="nav-link"&gt;Profile&lt;/a&gt;
    &lt;/li&gt;
    &lt;li class="nav-item dropdown"&gt;
        &lt;a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown"&gt;Messages&lt;/a&gt;
        &lt;div class="dropdown-menu"&gt;
            &lt;a href="#" class="dropdown-item"&gt;Inbox&lt;/a&gt;
            &lt;a href="#" class="dropdown-item"&gt;Drafts&lt;/a&gt;
            &lt;a href="#" class="dropdown-item"&gt;Sent Items&lt;/a&gt;
            &lt;div class="dropdown-divider"&gt;&lt;/div&gt;
            &lt;a href="#"class="dropdown-item"&gt;Trash&lt;/a&gt;
        &lt;/div&gt;
    &lt;/li&gt;
    &lt;li class="nav-item dropdown ml-auto"&gt;
        &lt;a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown"&gt;Admin&lt;/a&gt;
        &lt;div class="dropdown-menu dropdown-menu-right"&gt;
            &lt;a href="#" class="dropdown-item"&gt;Reports&lt;/a&gt;
            &lt;a href="#" class="dropdown-item"&gt;Settings&lt;/a&gt;
            &lt;div class="dropdown-divider"&gt;&lt;/div&gt;
            &lt;a href="#"class="dropdown-item"&gt;Logout&lt;/a&gt;
        &lt;/div&gt;
    &lt;/li&gt;
&lt;/ul&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <p>&mdash; The output of the above example will look something like this:</p>
                <div class="shadow">
                    <div class="preview-box">
                        <a href="../codelab.php?topic=bootstrap&amp;file=dropdowns-within-nav" target="_blank">
                            <img src="../lib/images/bootstrap-4/bootstrap-dropdowns-within-nav.png" width="730" height="60" alt="Bootstrap Dropdowns within Nav" />
                        </a>
                    </div>
                </div>
				<p>You can simply convert the above example to a tab dropdown by replacing the class <code>.nav-pills</code> with the <code>.nav-tabs</code>, without any further change in markup.</p>
                <hr />
                <h2 id="button-dropdowns">Dropdowns within Buttons</h2>
                <p>The following examples will show you how to add dropdowns to a primary button.</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=dropdowns-within-buttons" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-markup">&lt;div class="btn-group"&gt;
    &lt;button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown"&gt;Action&lt;/button&gt;
    &lt;div class="dropdown-menu"&gt;
        &lt;a href="#" class="dropdown-item"&gt;Action&lt;/a&gt;
        &lt;a href="#" class="dropdown-item"&gt;Another action&lt;/a&gt;
        &lt;div class="dropdown-divider"&gt;&lt;/div&gt;
        &lt;a href="#" class="dropdown-item"&gt;Separated link&lt;/a&gt;
    &lt;/div&gt;
&lt;/div&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <p>&mdash; Similarly you can add dropdowns to other variants of the buttons, as shown here:</p>
                <div class="shadow space">
                    <div class="preview-box">
                        <a href="../codelab.php?topic=bootstrap&amp;file=dropdowns-within-buttons" target="_blank">
                            <img src="../lib/images/bootstrap-4/bootstrap-dropdowns-within-buttons.png" width="730" height="58" alt="Bootstrap Dropdowns within Buttons" />
                        </a>
                    </div>
                </div>
                <hr />
                <h2>Bootstrap Split Button Dropdowns</h2>
                <p>The following examples will show you how to add dropdowns to split buttons.</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=split-button-dropdowns" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-markup">&lt;div class="btn-group"&gt;
    &lt;button type="button" class="btn btn-primary"&gt;Action&lt;/button&gt;
    &lt;button type="button" class="btn btn-primary dropdown-toggle dropdown-toggle-split" data-toggle="dropdown"&gt;
        &lt;span class="sr-only"&gt;Toggle Dropdown&lt;/span&gt;
    &lt;/button&gt;
    &lt;div class="dropdown-menu"&gt;
        &lt;a href="#" class="dropdown-item"&gt;Action&lt;/a&gt;
        &lt;a href="#" class="dropdown-item"&gt;Another action&lt;/a&gt;
        &lt;div class="dropdown-divider"&gt;&lt;/div&gt;
        &lt;a href="#" class="dropdown-item"&gt;Separated link&lt;/a&gt;
    &lt;/div&gt;
&lt;/div&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <p>&mdash; Similarly you can add dropdowns to other variants of the buttons, as shown here:</p>
                <div class="shadow break">
                    <div class="preview-box">
                        <a href="../codelab.php?topic=bootstrap&amp;file=split-button-dropdowns" target="_blank">
                            <img src="../lib/images/bootstrap-4/bootstrap-split-button-dropdowns.png" width="730" height="58" alt="Bootstrap Split Button Dropdowns" />
                        </a>
                    </div>
                </div>
				<!--Tip Box-->
                <div class="color-box">
                    <div class="shadow">
                        <div class="info-tab tip-icon" title="Useful Tips"><i></i></div>
                        <div class="tip-box">
                            <p><strong>Tip:</strong> You can use the Bootstrap's button relative sizing classes like <code>.btn-lg</code> and <code>.btn-sm</code> on the <code>.btn</code> element to further <a target="_blank" href="../codelab.php?topic=bootstrap&amp;file=sizing-button-dropdowns">resizing the buttons dropdowns</a>.</p>
                        </div>
                    </div>
                </div>
                <!--End:Tip Box-->
                <hr />
                <h2>Dropdowns Inside Button Groups</h2>
				<p>To create dropdown menus inside a button group just place a <code>.btn-group</code> along with the dropdown markup within another <code>.btn-group</code>.</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=dropdowns-within-button-groups" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-markup">&lt;div class="btn-group"&gt;
    &lt;button type="button" class="btn btn-primary"&gt;Button&lt;/button&gt;
    &lt;button type="button" class="btn btn-primary"&gt;Another Button&lt;/button&gt;
    &lt;div class="btn-group"&gt;
        &lt;button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown"&gt;Dropdown&lt;/button&gt;
        &lt;div class="dropdown-menu"&gt;
            &lt;a href="#" class="dropdown-item"&gt;Action&lt;/a&gt;
            &lt;a href="#" class="dropdown-item"&gt;Another action&lt;/a&gt;
            &lt;div class="dropdown-divider"&gt;&lt;/div&gt;
            &lt;a href="#" class="dropdown-item"&gt;Separated link&lt;/a&gt;
        &lt;/div&gt;
    &lt;/div&gt;
&lt;/div&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<p>&mdash; The output of the above example will look something like this:</p>
                <div class="shadow">
                    <div class="preview-box">
                        <a href="../codelab.php?topic=bootstrap&amp;file=dropdowns-within-button-groups" target="_blank">
                            <img src="../lib/images/bootstrap-4/bootstrap-dropdowns-within-button-groups.png" width="730" height="58" alt="Bootstrap Dropdowns within Button Groups" />
                        </a>
                    </div>
                </div>
				<p>Similarly, you can crate dropdown inside vertically stacked button groups, like this:</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=dropdowns-within-vertically-stacked-button-groups" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-markup">&lt;div class="btn-group-vertical"&gt;
    &lt;button type="button" class="btn btn-primary"&gt;Button&lt;/button&gt;
    &lt;button type="button" class="btn btn-primary"&gt;Another Button&lt;/button&gt;
    &lt;div class="btn-group"&gt;
        &lt;button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown"&gt;Dropdown&lt;/button&gt;
        &lt;div class="dropdown-menu"&gt;
            &lt;a href="#" class="dropdown-item"&gt;Action&lt;/a&gt;
            &lt;a href="#" class="dropdown-item"&gt;Another action&lt;/a&gt;
            &lt;div class="dropdown-divider"&gt;&lt;/div&gt;
            &lt;a href="#" class="dropdown-item"&gt;Separated link&lt;/a&gt;
        &lt;/div&gt;
    &lt;/div&gt;
&lt;/div&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<hr />
				<h2>Creating Dropup, Dropleft and Dropright Menus</h2>
				<p>You can even trigger the dropdown menus above, as well as, at the left and right of the elements by adding an extra class <code>.dropup</code>, <code>.dropleft</code> and <code>.dropright</code>, respectively to the parent element (i.e. the <code>.btn-group</code> element), as shown in the following example.</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=dropup-dropleft-and-dropright-menus" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a><span class="box-size"><i title="Maximize"></i></span></div>
                        <pre class="syntax-highlighter line-numbers scroll xxlarge"><code class="language-markup">&lt;!-- Dropup menu --&gt;
&lt;div class="btn-group dropup"&gt;
    &lt;button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown"&gt;Dropup&lt;/button&gt;
    &lt;div class="dropdown-menu"&gt;
        &lt;a href="#" class="dropdown-item"&gt;Action&lt;/a&gt;
        &lt;a href="#" class="dropdown-item"&gt;Another action&lt;/a&gt;
        &lt;div class="dropdown-divider"&gt;&lt;/div&gt;
        &lt;a href="#" class="dropdown-item"&gt;Separated link&lt;/a&gt;
    &lt;/div&gt;
&lt;/div&gt;

&lt;!-- Dropleft menu --&gt;
&lt;div class="btn-group dropleft"&gt;
    &lt;button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown"&gt;Dropleft&lt;/button&gt;
    &lt;div class="dropdown-menu"&gt;
        &lt;a href="#" class="dropdown-item"&gt;Action&lt;/a&gt;
        &lt;a href="#" class="dropdown-item"&gt;Another action&lt;/a&gt;
        &lt;div class="dropdown-divider"&gt;&lt;/div&gt;
        &lt;a href="#" class="dropdown-item"&gt;Separated link&lt;/a&gt;
    &lt;/div&gt;
&lt;/div&gt;

&lt;!-- Dropright menu --&gt;
&lt;div class="btn-group dropright"&gt;
    &lt;button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown"&gt;Dropright&lt;/button&gt;
    &lt;div class="dropdown-menu"&gt;
        &lt;a href="#" class="dropdown-item"&gt;Action&lt;/a&gt;
        &lt;a href="#" class="dropdown-item"&gt;Another action&lt;/a&gt;
        &lt;div class="dropdown-divider"&gt;&lt;/div&gt;
        &lt;a href="#" class="dropdown-item"&gt;Separated link&lt;/a&gt;
    &lt;/div&gt;
&lt;/div&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<p>&mdash; The output of the above example will look something like this:</p>
                <div class="shadow">
                    <div class="preview-box">
                        <a href="../codelab.php?topic=bootstrap&amp;file=dropup-dropleft-and-dropright-menus" target="_blank">
                            <img src="../lib/images/bootstrap-4/bootstrap-dropup-dropleft-and-dropright-menus.png" width="730" height="58" alt="Bootstrap Dropup Menus" />
                        </a>
                    </div>
                </div>
				<hr />
				<h2>Creating the Right Aligned Dropdown Menus</h2>
				<p>By default, the top-left corner of the dropdown menu is positioned at the bottom-left corner of its parent element i.e. 100% from the top and along the left side. To right align the dropdown menu just add an extra class <code>.dropdown-menu-right</code> to the <code>.dropdown-menu</code> base class.</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=right-aligned-dropdown-menus" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-markup">&lt;div class="btn-group"&gt;
    &lt;button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown"&gt;Right-aligned Dropdown Menu&lt;/button&gt;
    &lt;div class="dropdown-menu dropdown-menu-right"&gt;
        &lt;a href="#" class="dropdown-item"&gt;Action&lt;/a&gt;
        &lt;a href="#" class="dropdown-item"&gt;Another action&lt;/a&gt;
        &lt;div class="dropdown-divider"&gt;&lt;/div&gt;
        &lt;a href="#" class="dropdown-item"&gt;Separated link&lt;/a&gt;
    &lt;/div&gt;
&lt;/div&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <p>&mdash; The output of the above example will look something like this:</p>
                <div class="shadow">
                    <div class="preview-box">
                        <a href="../codelab.php?topic=bootstrap&amp;file=right-aligned-dropdown-menus" target="_blank">
                            <img src="../lib/images/bootstrap-4/bootstrap-right-aligned-dropdown-menus.png" width="730" height="58" alt="Bootstrap Right-aligned Dropdown Menus" />
                        </a>
                    </div>
                </div>
				<hr />
				<h2>Adding Headers to Dropdown Items</h2>
				<p>You can optionally add a menu header to label a section of menu items inside a dropdown menu by adding the class <code>.dropdown-header</code> to the <code>&lt;div&gt;</code> element, like this:</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=dropdown-header" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-markup">&lt;div class="btn-group"&gt;
    &lt;button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown"&gt;Products&lt;/button&gt;
    &lt;div class="dropdown-menu"&gt;
        &lt;div class="dropdown-header"&gt;ELECTRONICS&lt;/div&gt;
        &lt;a href="#" class="dropdown-item"&gt;Mobiles&lt;/a&gt;
        &lt;a href="#" class="dropdown-item"&gt;Tablets&lt;/a&gt;
        &lt;a href="#" class="dropdown-item"&gt;Laptops&lt;/a&gt;
        &lt;div class="dropdown-header"&gt;FASHION&lt;/div&gt;
        &lt;a href="#" class="dropdown-item"&gt;Clothing&lt;/a&gt;
        &lt;a href="#" class="dropdown-item"&gt;Sunglasses&lt;/a&gt;
    &lt;/div&gt;
&lt;/div&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<hr />
				<h2>Disable Items within a Dropdown</h2>
				<p>You can apply the class <code>.disabled</code> to the menu items in the dropdown to make them look like disabled. However, the link is still clickable, to disable this you can typically <a href="../faq/how-to-remove-clickable-behavior-from-a-disabled-link-using-jquery.php">remove the anchor's <code>href</code> attribute</a> either using the JavaScript or manually.</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=disabling-dropdown-items" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-markup">&lt;div class="btn-group"&gt;
    &lt;button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown"&gt;Reports&lt;/button&gt;
    &lt;div class="dropdown-menu"&gt;
        &lt;a href="#" class="dropdown-item"&gt;View&lt;/a&gt;
        &lt;a href="#" class="dropdown-item"&gt;Download&lt;/a&gt;
        &lt;a href="#" class="dropdown-item disabled" tabindex="-1"&gt;Edit / Delete&lt;/a&gt;
    &lt;/div&gt;
&lt;/div&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<hr />
                <h2>Adding Dropdowns via JavaScript</h2>
                <p>You may also add dropdowns manually using the JavaScript &mdash; just call the <code>dropdown()</code> Bootstrap method with the <code>id</code> or <code>class</code> <a href="../css-tutorial/css-selectors.php">selector</a> of the link or button element in your JavaScript code.</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=enable-dropdowns-via-javascript" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-markup">&lt;script&gt;
$(document).ready(function(){
    $(".dropdown-toggle").dropdown();
});  
&lt;/script&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<!--Note box-->
				<div class="color-box">
					<div class="shadow">
						<div class="info-tab note-icon" title="Important Notes"><i></i></div>
						<div class="note-box">
							<p><strong>Note:</strong> The <code>data-toggle="dropdown"</code> is still required for the dropdown's trigger element regardless of whether you call the dropdown via JavaScript or data-api.</p>
						</div>
					</div>
				</div>
				<!--End:Note box-->
                <hr />
                <h2>Options</h2>
                <p>There are certain options which can be passed to <code>dropdown()</code> Bootstrap method to customize the functionality of a dropdown. Options can be passed via data attributes or JavaScript.</p>
                <p>For setting the dropdown options via data attributes, just append the option name to <code>data-</code>, like <code>data-offset="10"</code>, <code>data-display="static"</code>, and so on.</p>
                <div class="shadow">
                    <table class="data">
                        <thead>
                            <tr>
                                <th><pre>Name        </pre></th>
                                <th><pre>Type            </pre></th>
                                <th>Default&nbsp;Value</th>
                                <th>Description</th>
                            </tr>                        	
                        </thead>
                        <tbody>
                            <tr>
                                <td>offset</td>
                                <td>number | string | function</td>
                                <td>0</td>
                                <td>Specify the offset of the dropdown relative to its target. <br>You can specify offset in various units, like <code>px</code>, <code>%</code>, <code>vw</code>, <code>vh</code>, etc. Unit-less values interpreted as pixels.</td>
                            </tr>
                            <tr>
                                <td>flip</td>
                                <td>boolean</td>
                                <td>true</td>
                                <td>Allow Dropdown to flip in case of an overlapping on the reference element.</td>
                            </tr>
                            <tr>
                                <td>boundary</td>
                                <td>string | element</td>
                                <td>'scrollParent'</td>
                                <td>Overflow constraint boundary of the dropdown menu. Accepts the values of <code>'viewport'</code>, <code>'window'</code>, <code>'scrollParent'</code>, or an HTMLElement reference (JavaScript only).</td>
                            </tr>
                            <tr>
                                <td>reference</td>
                                <td>string | element</td>
                                <td>'toggle'</td>
                                <td>Reference element of the dropdown menu. Accepts the values of <code>'toggle'</code>, <code>'parent'</code>, or an HTMLElement reference.</td>
                            </tr>
                            <tr>
                                <td>display</td>
                                <td>string</td>
                                <td>'dynamic'</td>
                                <td>Specify the dynamic positioning for dropdowns. You can disable this with the value <code>'static'</code></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <p>See the <a href="https://popper.js.org/popper-documentation.html">Popper.js's documentation</a> for more information on options mentioned above.</p>
                <!--Note box-->
				<div class="color-box">
                    <div class="shadow">
                        <div class="info-tab note-icon" title="Important Notes"><i></i></div>
                        <div class="note-box">
                            <p><strong>Note:</strong> When the boundary is set to any value other than <code>'scrollParent'</code>, the style <code>position: static</code> is applied to the <code>.dropdown</code> container.</p>
                        </div>
                    </div>
                </div>
                <!--End:Note box-->
                <hr />
                <h2>Methods</h2>
                <p class="space">This is the standard bootstrap's dropdown method:</p>
                <h2>$().dropdown('toggle')</h2>
                <p>This method toggles the dropdown menu of a given navbar or tabbed navigation.</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=dropdown-methods" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-markup">&lt;script&gt;
$(document).ready(function(){
    $("#myDropdown").dropdown('toggle');
});  
&lt;/script&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <h2>$().dropdown('show')</h2>
                <p>This method shows the dropdown menu of a given navbar or tabbed navigation.</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=dropdown-methods" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-markup">&lt;script&gt;
$(document).ready(function(){
    $("#myDropdown").dropdown('show');
});  
&lt;/script&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <h2>$().dropdown('hide')</h2>
                <p>This method hides the dropdown menu of a given navbar or tabbed navigation.</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=dropdown-methods" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-markup">&lt;script&gt;
$(document).ready(function(){
    $("#myDropdown").dropdown('hide');
});  
&lt;/script&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <h2>$().dropdown('update')</h2>
                <p>This method updates the position of an element's dropdown.</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=dropdown-methods" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-markup">&lt;script&gt;
$(document).ready(function(){
    $("#myDropdown").dropdown('update');
});  
&lt;/script&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<hr />
                <h2>Events</h2>
                <p>These are the standard Bootstrap events to enhance the dropdown functionality. All dropdown events are fired at the <code>.dropdown-menu</code>'s parent element.</p>
                <div class="shadow">
                    <table class="data">
                        <thead>
                            <tr>
                                <th>Event</th>
                                <th>Description</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>show.bs.dropdown</td>
                                <td>This event fires immediately when the show instance method is called.  You can use the <code>event.relatedTarget</code> to target the toggling anchor element.</td>
                            </tr>
                            <tr>
                                <td>shown.bs.dropdown</td>
                                <td>This event is fired when the dropdown has been made visible to the user. It will wait for CSS transitions, to complete. You can use the <code>event.relatedTarget</code> to target the toggling anchor element.</td>
                            </tr>
                            <tr>
                                <td>hide.bs.dropdown</td>
                                <td>This event is fired immediately when the hide instance method has been called. You can use the <code>event.relatedTarget</code> to target the toggling anchor element.</td>
                            </tr>
                            <tr>
                                <td>hidden.bs.dropdown</td>
                                <td>This event is fired when the dropdown has finished being hidden from the user. It will wait for CSS transitions, to complete. You can use the <code>event.relatedTarget</code> to target the toggling anchor element.</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <p>The following example displays the text content of dropdown link when the users click on it.</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=dropdown-events" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-markup">&lt;script&gt;
$(document).ready(function(){
    $(".dropdown").on("show.bs.dropdown", function(e){
        var linkText = $(e.relatedTarget).text(); // Get the link text
        alert("Click on OK button to view the dropdown menu for - " + linkText);
    });
});
&lt;/script&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <!--Bottom Navigation-->
                <div class="bottom-link clearfix">
                    <a href="bootstrap-modals.php" class="previous-page-bottom">Previous Page</a>
                    <a href="bootstrap-tabs.php" class="next-page-bottom">Next Page</a>
                </div>
                <!--End:Bottom Navigation--> 
                <!-- InstanceEndEditable -->
                <!--Bottom Ads-->
                <div class="bottom-ad clearfix">
                    <div class="ad-label">Advertisements</div>

<!--Rectangle Left-->
<div class="rectangle-left fl">
    
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Large Rectangle Left -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="8162953958"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
<!--End:Rectangle Left-->


<!--Rectangle Right-->
<div class="rectangle-right fr">

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Large Rectangle Right -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="3324015654"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
<!--End:Rectangle Right-->                </div>
                <!--End:Bottom Ads-->
            </div>
            <!--End:Text Content-->
            <!--Feedback Form-->
			<div class="snippets">
	<a href="/snippets/gallery.php" target="_blank">
    	<img src="/lib/images/bootstrap-code-snippets.png" alt="Bootstrap UI Design Templates" />
	</a>
</div>

<div class="report-error" id="feedback">
    <div class="contact-form clearfix">
        <div class="close"><span class="icon-close"></span></div>
        <form id="feedback-form">
            <h3>Your Feedback:</h3>
            <div class="clearfix">
                <div class="name fl"><label>Your Name (optional) <input type="text" name="user-name" id="user-name" /></label></div>
                <div class="email fr"><label>Your E-mail (optional) <input type="text" name="user-email" id="user-email" /></label></div>
            </div>
            <div><label>Page address <input type="text" name="page-url" id="page-url" class="disabled" disabled="disabled" /></label></div>
            <div><label>Description <textarea name="description" id="description" rows="6"></textarea></label></div>
            <p id="feedback-error">We would love to hear from you, please drop us a line.</p>
            <div><button type="button" class="action-btn" onclick="sendFeedback()"><span class="icon-send"></span> Send</button></div>
        </form>
        <div id="response"></div>
    </div>           
</div>            <!--End:Feedback Form-->
        </div>        
        <div class="sidebar">
            <div class="ad-label">Advertisements</div>

<div class="skyscraper primary">

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Premium Skyscraper -->
<ins class="adsbygoogle"
     style="display:inline-block;width:160px;height:600px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="4376141825"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>

<div class="skyscraper">
    
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Bottom Skyscraper -->
<ins class="adsbygoogle"
     style="display:inline-block;width:160px;height:600px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="3387984471"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>        </div>
    </div>
    <!--Footer-->
	<!--Footer-->
<div class="footer">
    <div class="appeal">
        <div class="wrapper">
            <p>Is this website helpful to you? Please give us a
            <a href="/like.php" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=250,width=600,top=150, left='+((screen.width/2)-300));return false;">like</a>,
            or share your <a href="#feedback" class="feedback">feedback</a><em> to help us improve</em>.
            Connect with us on <a href="https://www.facebook.com/tutorialrepublic" target="_blank">Facebook</a> and <a href="https://twitter.com/tutrepublic" target="_blank">Twitter</a> for the latest updates.</p>               
        </div>
    </div>
    <div class="footer-inner">
        <div class="wrapper clearfix">                
            <div class="link-box">
                <h4>About Us</h4>
                <div class="clearfix">
                    <a href="/about-us.php">Our Story</a>                    
                    <a href="/terms-of-use.php">Terms of Use</a>
                    <a href="/privacy-policy.php">Privacy Policy</a>                    
                </div>
            </div>
            <div class="link-box">
                <h4>Contact</h4>
                <div class="clearfix">
                    <a href="/contact-us.php">Contact Us</a>                    
                    <a href="#feedback" class="feedback">Report Error</a>
                    <a href="/advertise-with-us.php">Advertise</a>                    
                </div>
            </div>
            <div class="tool-box">
                <h4>Interactive Tools</h4>
                <div class="tools-list clearfix" id="tools">
                    <a href="/faq/what-is-the-maximum-length-of-title-and-meta-description-tag.php">Title &amp; Meta Length Calculator</a>                           
                    <a href="/html-formatter.php" target="_blank">HTML Formatter</a>                        
                    <a href="/twitter-bootstrap-button-generator.php" target="_blank">Bootstrap Button Generator</a>
                    <a href="/html-reference/html-color-picker.php">HTML Color Picker</a>
                    <a href="/codelab.php?topic=sql&amp;file=select-all" target="_blank">SQL Playground</a>
                    <a href="/codelab.php?topic=html&amp;file=hello-world" target="_blank">HTML Editor</a>                    
                </div>
            </div>
            <div class="footer-logo">
                <img src="/lib/images/logo.svg" alt="TutorialRepublic" />
            </div>
        </div>
    </div>           
        <div class="bottom-strip">
        <div class="wrapper">
            <div class="notice">Copyright &copy; 2019 Tutorial Republic. All Rights Reserved.</div>
            <div class="social-media">
                <em>Share This:</em>
                <a href="https://facebook.com/sharer.php?u=https://www.tutorialrepublic.com%2Ftwitter-bootstrap-tutorial%2Fbootstrap-dropdowns.php" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" title="Facebook"><i class="icon-facebook"></i></a>
                <a href="#" id="tweet-btn" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" title="Twitter"><i class="icon-twitter"></i></a>
                <a href="#" id="email-btn" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" rel="noreferrer" title="Gmail"><i class="icon-mail"></i></a>
            </div>
        </div>            
    </div>
    <script>
        var title = document.title.replace('- Tutorial Republic', '');
        document.getElementById('tweet-btn').href = 'https://twitter.com/share?text=' + title + '- &url=https://www.tutorialrepublic.com%2Ftwitter-bootstrap-tutorial%2Fbootstrap-dropdowns.php';
        document.getElementById('email-btn').href = 'https://mail.google.com/mail/?view=cm&fs=1&su=' + title + '&body=https://www.tutorialrepublic.com%2Ftwitter-bootstrap-tutorial%2Fbootstrap-dropdowns.php';
    </script>
</div>
<!--End:Footer-->
    
<div class="backdrop mobile-only"></div>

<!-- TutorialRepublic base script -->
<script>
// Adding CSS files
[
	'/lib/styles/extended.new-3.7.css',
	'/lib/icomoon/style.css'
].forEach(function(href) {
	var link = document.createElement('link');
	link.rel = 'stylesheet';
	link.href = href;
	(document.getElementsByTagName('head')[0]).appendChild(link);
});

// Adding JS files
[
	'https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js',
	'/lib/js/prism.js',
	'/lib/js/default.new-2.9.min.js'
].forEach(function(src) {
	var script = document.createElement('script');
	script.async = false; // important
	script.src = src;
	(document.getElementsByTagName('body')[0]).appendChild(script);
});
</script>


    <!--End:Footer-->
</body>
<!-- InstanceEnd --></html>