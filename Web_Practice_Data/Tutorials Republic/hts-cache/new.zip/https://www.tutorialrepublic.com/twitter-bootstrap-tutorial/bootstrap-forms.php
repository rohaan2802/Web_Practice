<!DOCTYPE html>
<html lang="en"><!-- InstanceBegin template="/Templates/bootstrap.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
	<!-- InstanceBeginEditable name="doctitle" -->
    <title>How to Create Form Layouts with Bootstrap 4 - Tutorial Republic</title>
    <meta name="description" content="Learn how to create different types of form layouts such as vertical form, horizontal form and inline from quickly and easily with the Bootstrap framework." />
    <!-- InstanceEndEditable -->
    	<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta property="fb:admins" content="100001054961582" />
<meta property="fb:app_id" content="1404574483159557" />
<meta property="og:image" content="/lib/images/signature.png" />
<link type="image/x-icon" href="/favicon.ico" rel="shortcut icon" />
<style>
html,body,h1,h2,h3,h4,h5,h6,p,blockquote,pre,img{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}
html,body{min-height:100%}
p{margin:0 0 12px}
ol,ul{margin:0 0 12px}
a,a:active,a:visited{outline:none;color:#1db79f;text-decoration:none}
a img{border:none;outline:none}
a code{color:inherit;background:none}
p code,table td:last-child code,.content ul li code,code.mark{padding:2px 4px;color:#333;background-color:#f1f1f1;border-radius:4px}
table{border-collapse:collapse;border-spacing:0}
table td{vertical-align:top}
body{min-width:1300px;color:#414141;background:#fafafa;font-family:"Segoe UI","Helvetica Neue",Arial,sans-serif;font-size:17px;line-height:1.7}
input,select,textarea,button,div,span,a{box-sizing:border-box}
h1,h2,h3,h4{color:#262626;font-weight:500;margin:20px 0 10px;line-height:1.5;font-weight:600}
h1{font-size:34px;margin-top:17px}
h2{font-size:28px}
h3{font-size:22px}
.space{margin-bottom:25px!important}
.break{margin-bottom:15px!important}
.text-center{text-align:center!important}
.scroll{height:195px;overflow-y:scroll}
.scroll.large{height:245px}
.scroll.xlarge{height:290px}
.scroll.xxlarge{height:340px}
sup{font-size:13px}
.leaderboard{padding-top:8px;position:relative}
.ad-container{height:90px;overflow:hidden}
.intro-image img{display:block;padding:10px 0 25px;max-width:100%}
.clearfix::after{content:".";display:block;height:0;clear:both;visibility:hidden}
code,.code,.syntax,.green-box,.sky-box,.gray-box,.pink-box,.red-box,.at-rule,.codebox pre,.console-output{font-size:16px;font-family:Consolas,Monaco,Courier,monospace}
.console-output{margin:15px 0}
hr{border:none;border-bottom:1px solid #e7e9ed;height:1px;margin:30px 0}
.summary,.topic{border:1px solid #eaeaea;border-width:1px 0;margin:20px 0;padding:10px 0;color:#8e9aa6;line-height:1.5}
h2.section-title span{display:inline-block;border-bottom:4px solid #c9d7e0;padding:0 50px 12px 0}
.wrapper{width:1300px;padding:0 15px;margin:0 auto}
.header{background:#23384e;padding:16px 0}
input.search{background:#fff;border:0 none;color:#807E7E;float:left;height:38px;line-height:26px;font-size:14px;margin:0 0 0 12px;outline:medium none;padding:6px 14px;width:500px;border-radius:2px;box-shadow:0 0 1px rgba(0,0,0,0.6);font-family:inherit}
.search-btn{color:rgba(0,0,0,.6);background:#ebebeb;border:none;outline:none;cursor:pointer;float:left;height:38px;line-height:46px;width:44px;display:block;margin-left:-2px;border-radius:0 2px 2px 0;box-shadow:0 0 1px rgba(0,0,0,0.7)}
.logo{width:304px}
.logo img{height:44px;margin:-3px 0;display:block}
.site-search{float:left;margin-left:100px}
.menu{background-color:#f5f5f5;box-shadow:0 1px 1px rgba(0,0,0,.15);position:relative;z-index:9}
.menu a{color:#666;display:inline-block;padding:0 10px;text-decoration:none;font-size:14px;font-weight:600;height:48px;line-height:48px}
.menu a:first-child{margin-left:-10px}
.menu a.tool-link{float:right;display:inline-block;border-radius:30px;line-height:28px;position:relative;height:auto;top:9px;padding:0 12px;color:#1ebba3;border:1px double #1ebba3}
.fl,.logo{float:left}
.leftcolumn{width:240px;float:left;font-size:16px;color:#4f4f4f}
.centercolumn{width:850px;float:left}
.content{background:#fff;padding:20px 40px;border:1px solid #dedede;border-top:none;border-radius:1px}
.sidebar{width:160px;float:left;padding-top:28px;margin-left:20px;position:relative}
.leftcolumn .segment{margin:16px 0 12px;position:relative;font-size:18px;font-weight:600;line-height:normal}
.leftcolumn a{color:#4f4f4f;font-size:16px;line-height:26px;display:block;border-bottom:1px solid transparent}
.leftcolumn ul{list-style:none;padding:0}
.segment,.chapters,.chapters a{float:left;clear:both}
h1 code,h2 code,h3 code{font:inherit}
.color-box{margin:15px 0;padding-left:20px}
.note-box,.warning-box,.tip-box{padding:8px 8px 3px 26px}
.info-tab{float:left;margin-left:-23px}
.content ul li{margin-top:7px}
.extra{padding-top:5px}
.green-box,.sky-box,.gray-box,.red-box,.pink-box{color:#000;margin-top:15px;padding:10px;background-color:#f6f8fa;border:1px solid #d7e2ec}
.example{background:#f4f5f6;padding:3px;margin:15px 0}
.codebox{background:#fff;border:1px solid #ddd}
.codebox-title{height:41px;padding-left:12px;border-bottom:1px solid #ddd;background:#f5f5f5}
.codebox-title h4{margin:0;font-size:18px;line-height:40px;float:left;display:inline;font-weight:500}
a.try-btn,a.download-btn{width:140px;height:40px;color:#333;font-size:15px;line-height:41px;font-weight:600;text-align:center;text-decoration:none;float:right;display:block;border-left:1px solid #ddd;background:rgba(27,31,35,0.08);box-sizing:border-box;font-family:Arial,sans-serif}
a.try-btn span{font-size:18px;line-height:normal}
.hide,.code-style,.box-size,.bottom-link,.footer,.code-style,.snippets,.report-error,.badge,.social,.ad-label,.mobile-only{display:none}
.skyscraper{width:160px;height:600px;overflow:hidden;margin-bottom:20px;background:#ebecf0}
.bottom-ad{margin-top:46px;padding:24px;position:relative;background:url(/lib/images/smooth-line.png) no-repeat center #f9f9f9}
.rectangle-left,.rectangle-right{min-width:336px;min-height:280px;overflow:hidden}
.fr,a.previous-page,a.next-page,.rectangle-right,.topic-nav{float:right}
a.previous-page,a.next-page{width:32px;height:32px;line-height:30px}
.shadow{background:#F7F8F9;padding:3px;margin:10px 0}
.syntax{color:#2f4959;padding:13px 18px;background:#F9F9FA;border:1px solid #ddd;font-size:15px}
code[class*="language-"],pre[class*="language-"]{color:#000;background:none;font-family:Consolas,Monaco,'Andale Mono','Ubuntu Mono',monospace;text-align:left;white-space:pre;word-break:normal;word-wrap:normal;line-height:1.5;tab-size:4;hyphens:none}
pre[class*="language-"]{position:relative;margin:.5em 0;overflow:visible;padding:0}
pre[class*="language-"]>code{position:relative;border-left:10px solid #358ccb;box-shadow:-1px 0 0 0 #358ccb,0 0 0 1px #dfdfdf;background-color:#fdfdfd;background-image:linear-gradient(transparent 50%,rgba(69,142,209,0.04) 50%);background-size:3em 3em;background-origin:content-box;background-attachment:local}
code[class*="language"]{max-height:inherit;height:inherit;padding:0 1em;display:block;overflow:auto}
:not(pre) > code[class*="language-"]{position:relative;padding:.2em;border-radius:.3em;color:#c92c2c;border:1px solid rgba(0,0,0,0.1);display:inline;white-space:normal}
pre[class*="language-"].line-numbers{padding-left:0}
pre[class*="language-"].line-numbers code{padding-left:3.8em}
pre[class*="language-"].line-numbers .line-numbers-rows{left:0}
pre[class*="language-"][data-line]{padding-top:0;padding-bottom:0;padding-left:0}
pre[data-line] code{position:relative;padding-left:4em}
pre .line-highlight{margin-top:0}
pre.line-numbers{position:relative;padding-left:3.8em;counter-reset:linenumber;white-space:pre-wrap!important}
pre.line-numbers > code{position:relative;white-space:inherit}
.line-numbers-rows,.codebox pre.inactive{display:none}
.codebox pre.syntax-highlighter{margin:0;padding:0;overflow:auto}
pre.line-numbers .line-numbers-rows{border-right:3px solid #6CE26C}
.codebox pre.syntax-highlighter > code{box-shadow:none!important;padding-left:3.8em;background-image:linear-gradient(transparent 50%,#F8F8F8 50%);font-family:Consolas,Monaco,'Andale Mono','Ubuntu Mono',monospace!important;font-size:16px;line-height:1.5}
.codebox pre.syntax-highlighter,.codebox pre.syntax-highlighter code{border:none;width:100%;box-sizing:border-box}
pre.line-numbers code,pre.line-numbers .line-numbers-rows{padding-top:2px;padding-bottom:2px}
.preview-box{padding:15px;text-align:center;cursor:pointer;overflow:hidden;background:#FFF;border:1px solid #e6e6e6}
.preview-box a,.preview-box img{display:block;margin:0 auto}
.download-box{text-align:center;padding:20px 0;margin:20px 0 10px}
.output-box{border-color:#d4d4d4;border-style:solid;border-width:1px 0;padding:5px 15px;overflow:hidden;background:#fff;margin:10px 0}
.demo-box{margin-top:15px}
.subhead{border-bottom:3px solid #DCE3EB;margin-bottom:15px;padding-bottom:10px}
table.data,table.description{width:100%;font-size:92%}
table.data th{color:#000;padding:8px 7px;text-align:left;font-size:15px;background:#F8F8F8}
table.data td{color:#484848;padding:5px 7px;background:#fff}
table.data th,table.data td{vertical-align:top;border:1px solid #DCE3EB}
table.data tr.section th,table.data td.section{font-size:15px;background:#f0f4f7}
table.no-wrap tr td:first-child{white-space:nowrap}
@media screen and (max-width: 1280px) {
body{min-width:1260px}
.wrapper{width:1260px}
.leftcolumn{width:230px}
.centercolumn{width:820px}
}
@media screen and (max-width: 800px) {
body{min-width:100%;max-width:100%;padding-top:46px}
.wrapper{width:100%;padding:0}
.header{height:46px;padding:5px 0;position:fixed;top:0;left:0;right:0;width:100%;z-index:99}
.logo{width:auto;display:block;padding:6px 0 0 60px;position:absolute;left:0;z-index:100}
.logo img{height:30px}
.menu{width:100%;padding-left:12px;padding-right:12px;overflow-x:auto;white-space:nowrap}
.centercolumn{width:100%;float:none}
.content{padding:10px;border-width:0 0 1px 0}
.content img{max-width:100%;height:auto}
.content pre{max-width:100%;overflow:hidden}
.skyscraper{display:inline-block}
.shadow,.example,.console-output{max-width:100%;overflow-x:auto}
.codebox-title{position:relative}
.codebox.multi-style-mode pre{padding-top:7px;margin-top:36px;border-top:1px solid #ddd}
.bottom-ad{height:auto;background:none;padding:30px 0 0;margin:40px 0 0;text-align:center;position:relative}
.rectangle-left,.rectangle-right{float:none;display:inline-block;margin:10px auto;background:#EDEEF2}
.leftcolumn,.footer,.social,.site-search,.code-style,.menu a.tool-link,.backdrop{display:none}
.summary,.topic{padding:5px 0;margin:10px 0}
.leftcolumn,.centercolumn,.sidebar{float:none}
.header,.menu,.centercolumn,.footer,.appeal-text{width:100%}
a.try-btn,a.download-btn{width:130px}
.native-unit{margin-bottom:30px}
.sidebar{margin: 25px auto 0}
.overview{padding-right:0}
.scroll-pane{overflow-x:auto}
table.data{min-width:480px}
table.data pre{display:inline;white-space:normal}
table tr th,table tr td{width:auto!important}
.preview-box{padding:6px}
.leaderboard{margin:20px 0}
h1{font-size:30px}
h2{font-size:24px}
h3{font-size:20px}
.codebox pre.syntax-highlighter{overflow-x:auto}
.codebox pre.syntax-highlighter > code{width:614px;height:auto;overflow-x:hidden}
}
@media screen and (min-width: 801px) {
.site-search,.leftcolumn,.social{display:block!important}
.backdrop{display:none!important}
.hide-scroll{overflow-x:hidden!important}
}</style>    
    <!-- InstanceBeginEditable name="head" -->
    <!-- InstanceEndEditable -->
    
    <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-40117907-1', 'auto');
  ga('send', 'pageview');
</script></head>
<body>
    <!--Header-->
    
<div class="header">
    <div class="wrapper clearfix">
        <button type="button" class="open-menu mobile-only"><i class="icon-menu"></i></button>
        <div class="logo">
            <a href="https://www.tutorialrepublic.com/"><img src="/lib/images/logo.svg" alt="TutorialRepublic" /></a>
        </div>
        <div class="site-search">
            <form action="https://www.google.com/search" method="get" target="_blank" class="clearfix">
                <input type="hidden" value="www.tutorialrepublic.com" name="sitesearch" />
                <input type="text" name="q" placeholder="Search topics, tutorials, questions and answers..." id="searchInput" class="search" />
                <button type="submit" class="search-btn"><span class="icon-search"></span></button>
            </form>
        </div>
        <div class="social">                
            <a href="https://www.facebook.com/tutorialrepublic" target="_blank" title="Join us on Facebook"><i class="icon-facebook"></i></a>
            <a href="https://twitter.com/tutrepublic" target="_blank" title="Follow us on Twitter"><i class="icon-twitter"></i></a>
            <a href="/contact-us.php" target="_blank" title="Send us an Email"><i class="icon-mail"></i></a>
        </div>
        <button type="button" class="open-search mobile-only">
            <i class="icon-search"></i>
        </button>
    </div>    
</div>
<div class="menu">
    <div class="wrapper">
        <a href="//www.tutorialrepublic.com" title="Home Page">HOME</a>
        <a href="/html-tutorial/" title="HTML Tutorial">HTML5</a>            
        <a href="/css-tutorial/" title="CSS Tutorial">CSS3</a>
        <a href="/javascript-tutorial/" title="JavaScript Tutorial">JAVASCRIPT</a>
        <a href="/jquery-tutorial/" title="jQuery Tutorial">JQUERY</a>
        <a href="/twitter-bootstrap-tutorial/" title="Bootstrap Tutorial">BOOTSTRAP4</a>
        <a href="/php-tutorial/" title="PHP Tutorial">PHP7</a> 
        <a href="/sql-tutorial/" title="SQL Tutorial">SQL</a>
        <a href="/references.php" title="Web References">REFERENCES</a>
        <a href="/practice-examples.php" title="Practice Examples and Demos">EXAMPLES</a>
        <a href="/faq.php" title="Frequently Asked Questions and Answers">FAQ</a>
        <a href="/snippets/gallery.php" title="Bootstrap Code Snippets" target="_blank">SNIPPETS</a>
        <a href="/codelab.php" class="tool-link" target="_blank">Online HTML Editor</a>
    </div>        
</div>    <!--End:Header-->
    <div class="wrapper clearfix">
        <div class="leftcolumn" id="myNav">
		
        <div class="segment"><span>BOOTSTRAP</span> BASIC</div>
<div class="chapters">
    <a href="/twitter-bootstrap-tutorial/">Bootstrap Introduction</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-get-started.php">Bootstrap Getting Started</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-grid-system.php">Bootstrap Grid System</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-fixed-layout.php">Bootstrap Fixed Layout</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-fluid-layout.php">Bootstrap Fluid Layout</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-responsive-layout.php">Bootstrap Responsive Layout</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-typography.php">Bootstrap Typography</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-tables.php">Bootstrap Tables</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-lists.php">Bootstrap Lists</a>
	<a href="/twitter-bootstrap-tutorial/bootstrap-list-groups.php">Bootstrap List Groups</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-forms.php">Bootstrap Forms</a>
	<a href="/twitter-bootstrap-tutorial/bootstrap-custom-forms.php">Bootstrap Custom Forms</a>
	<a href="/twitter-bootstrap-tutorial/bootstrap-input-groups.php">Bootstrap Input Groups</a>
	<a href="/twitter-bootstrap-tutorial/bootstrap-buttons.php">Bootstrap Buttons</a>
	<a href="/twitter-bootstrap-tutorial/bootstrap-button-groups.php">Bootstrap Button Groups</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-images.php">Bootstrap Images</a>
	<a href="/twitter-bootstrap-tutorial/bootstrap-cards.php">Bootstrap Cards</a>
	<a href="/twitter-bootstrap-tutorial/bootstrap-media-objects.php">Bootstrap Media Objects</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-icons.php">Bootstrap Icons</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-navs.php">Bootstrap Navs</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-navbar.php">Bootstrap Navbar</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-breadcrumbs.php">Bootstrap Breadcrumbs</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-pagination.php">Bootstrap Pagination</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-badges.php">Bootstrap Badges</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-progress-bars.php">Bootstrap Progress Bars</a>
	<a href="/twitter-bootstrap-tutorial/bootstrap-spinners.php">Bootstrap Spinners</a>
	<a href="/twitter-bootstrap-tutorial/bootstrap-jumbotron.php">Bootstrap Jumbotron</a>
	<a href="/twitter-bootstrap-tutorial/bootstrap-helper-classes.php">Bootstrap Helper Classes</a>
</div>
<div class="segment"><span>BOOTSTRAP</span> ADVANCED</div>
<div class="chapters">
	<a href="/twitter-bootstrap-tutorial/bootstrap-modals.php">Bootstrap Modals</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-dropdowns.php">Bootstrap Dropdowns</a>
	<a href="/twitter-bootstrap-tutorial/bootstrap-tabs.php">Bootstrap Tabs</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-tooltips.php">Bootstrap Tooltips</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-popovers.php">Bootstrap Popovers</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-alerts.php">Bootstrap Alerts</a>
	<a href="/twitter-bootstrap-tutorial/bootstrap-stateful-buttons.php">Bootstrap Stateful Buttons</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-accordion.php">Bootstrap Accordion</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-carousel.php">Bootstrap Carousel</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-typeahead.php">Bootstrap Typeahead</a>
    <a href="/twitter-bootstrap-tutorial/bootstrap-scrollspy.php">Bootstrap ScrollSpy</a>
	<a href="/twitter-bootstrap-tutorial/bootstrap-toasts.php">Bootstrap Toasts</a>
</div>
<div class="segment"><span>BOOTSTRAP</span> EXAMPLES</div>
<div class="chapters">
    <a href="/twitter-bootstrap-examples.php">Bootstrap Practice Examples</a>
	<a href="/faq.php#bootstrap-less">Bootstrap FAQ's Answers</a>
</div>
<div class="segment"><span>BOOTSTRAP</span> ARCHIVE</div>
<div class="chapters">
    <a href="/twitter-bootstrap-3-tutorial/">Bootstrap 3 Tutorial</a>
	<a href="/twitter-bootstrap-3-examples.php">Bootstrap 3 Practice Examples</a>
</div>        
                </div>
        <div class="centercolumn">
            <!--Text Content-->
            <div class="content">
                <div class="leaderboard">
                    
<div class="ad-label">Advertisements</div>
<div class="ad-container">
    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <!-- Responsive Leaderboard -->
    <ins class="adsbygoogle"
            style="display:inline-block;max-width:728px;width:100%;height:90px"
            data-ad-client="ca-pub-9107540490929984"
            data-ad-slot="4302666817"></ins>
    <script>
    (adsbygoogle = window.adsbygoogle || []).push({});
    </script>
</div>                </div>
                <!-- InstanceBeginEditable name="main_content" -->
                <a href="bootstrap-list-groups.php" class="previous-page" title="Go to Previous Page"></a>
                <a href="bootstrap-custom-forms.php" class="next-page" title="Go to Next Page"></a>
                <h1>Bootstrap <span>Forms</span></h1>
                <p class="summary">In this tutorial you will learn how to create elegant forms with Bootstrap.</p>
                <h2>Creating Forms with Bootstrap</h2>
                <p>HTML forms are the integral part of the web pages and applications, but creating the form layouts or styling the form controls manually one by one using CSS are often boring and tedious. Bootstrap greatly simplifies the process of styling and alignment of form controls like labels, input fields, selectboxes, textareas, buttons, etc. through predefined set of classes.</p>
                <p>Bootstrap provides three different types of form layouts:</p>
                <ul>
                    <li>Vertical Form (default form layout)</li>
                    <li>Horizontal Form</li>
                    <li>Inline Form</li>
                </ul>
				<p class="space">The following section will give you the detailed overview of all these form layouts as well as the various form related Bootstrap components one by one. Well let's get started.</p>
                <h2>Creating Vertical Form Layout</h2>
                <p>This is the default Bootstrap form layout in which styles are applied to form controls without adding any base class to the <a href="../html-tutorial/html-forms.php"><code>&lt;form&gt;</code></a> element or any large changes in the markup.</p>
                <p>The form controls in this layout are stacked with left-aligned labels on the top.</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=vertical-form-layout" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-markup">&lt;form&gt;
    &lt;div class="form-group"&gt;
        &lt;label for="inputEmail"&gt;Email&lt;/label&gt;
        &lt;input type="email" class="form-control" id="inputEmail" placeholder="Email"&gt;
    &lt;/div&gt;
    &lt;div class="form-group"&gt;
        &lt;label for="inputPassword"&gt;Password&lt;/label&gt;
        &lt;input type="password" class="form-control" id="inputPassword" placeholder="Password"&gt;
    &lt;/div&gt;
    &lt;div class="form-group"&gt;
        &lt;label class="form-check-label"&gt;&lt;input type="checkbox"&gt; Remember me&lt;/label&gt;
    &lt;/div&gt;
    &lt;button type="submit" class="btn btn-primary"&gt;Sign in&lt;/button&gt;
&lt;/form&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <p>&mdash; The output of the above example will look something like this:</p>
                <div class="shadow">
                    <div class="preview-box">
                        <a href="../codelab.php?topic=bootstrap&amp;file=vertical-form-layout" target="_blank">
                            <img src="../lib/images/bootstrap-4/bootstrap-vertical-from-layout.png" width="730" height="270" alt="Bootstrap Vertical Form Layout" />
                        </a>
                    </div>
                </div>
                <!--Note box-->
                <div class="color-box">
                    <div class="shadow">
                        <div class="info-tab note-icon" title="Important Notes"><i></i></div>
                        <div class="note-box">
                            <p><strong>Note:</strong> All textual form controls, like <code><a href="../html-reference/html-input-tag.php">&lt;input&gt;</a></code>, <code><a href="../html-reference/html-textarea-tag.php">&lt;textarea&gt;</a></code>, and <code><a href="../html-reference/html-select-tag.php">&lt;select&gt;</a></code> require the  class <code>.form-control</code> for general styling. The <code>.form-control</code> class also makes them 100% wide. To change their width or use them inline, you can utilize the predefined grid classes.</p>
                        </div>
                    </div>
                </div>
                <!--End:Note box-->
                <hr />
                <h2>Creating Horizontal Form Layout</h2>
                <p>You can also create horizontal form layouts where labels and form controls are aligned side-by-side using the Bootstrap grid classes. To create a horizontal form layout add the class <code>.row</code> on form groups and use the <code>.col-*-*</code> grid classes to specify the width of your labels and controls.</p>
                <p>Also, be sure to apply the class <code>.col-form-label</code> on the <a href="/html-reference/html-label-tag.php"><code>&lt;label&gt;</code></a> elements, so that they're vertically centered with their associated form controls. Let's check out an example:</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=horizontal-form-layout" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-markup">&lt;form&gt;
    &lt;div class="form-group row"&gt;
        &lt;label for="inputEmail" class="col-sm-2 col-form-label"&gt;Email&lt;/label&gt;
        &lt;div class="col-sm-10"&gt;
            &lt;input type="email" class="form-control" id="inputEmail" placeholder="Email"&gt;
        &lt;/div&gt;
    &lt;/div&gt;
    &lt;div class="form-group row"&gt;
        &lt;label for="inputPassword" class="col-sm-2 col-form-label"&gt;Password&lt;/label&gt;
        &lt;div class="col-sm-10"&gt;
            &lt;input type="password" class="form-control" id="inputPassword" placeholder="Password"&gt;
        &lt;/div&gt;
    &lt;/div&gt;
    &lt;div class="form-group row"&gt;
        &lt;div class="col-sm-10 offset-sm-2"&gt;
            &lt;label class="form-check-label"&gt;&lt;input type="checkbox"&gt; Remember me&lt;/label&gt;
        &lt;/div&gt;
    &lt;/div&gt;
    &lt;div class="form-group row"&gt;
        &lt;div class="col-sm-10 offset-sm-2"&gt;
            &lt;button type="submit" class="btn btn-primary"&gt;Sign in&lt;/button&gt;
        &lt;/div&gt;
    &lt;/div&gt;
&lt;/form&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <p>&mdash; The output of the above example will look something like this:</p>
                <div class="shadow">
                    <div class="preview-box">
                        <a href="../codelab.php?topic=bootstrap&amp;file=horizontal-form-layout" target="_blank">
                            <img src="../lib/images/bootstrap-4/bootstrap-horizontal-form-layout.png" width="730" height="206" alt="Bootstrap Horizontal Form Layout" />
                        </a>
                    </div>
                </div>
                <hr />
                <h2>Creating Inline Form Layout</h2>
                <p>Sometimes you may want to display a series of labels, form controls, and buttons on a single horizontal row to compact the layout. You can do this easily by adding the class <code>.form-inline</code> to the <a href="../html-tutorial/html-forms.php"><code>&lt;form&gt;</code></a> element. However, form controls only appear inline in viewports that are at least 576px wide.</p>
                <p>Let's take a look at following example to see how it actually works:</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=inline-form-layout" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-markup">&lt;form class="form-inline"&gt;
    &lt;div class="form-group mr-2"&gt;
        &lt;label class="sr-only" for="inputEmail"&gt;Email&lt;/label&gt;
        &lt;input type="email" class="form-control" id="inputEmail" placeholder="Email"&gt;
    &lt;/div&gt;
    &lt;div class="form-group mr-2"&gt;
        &lt;label class="sr-only" for="inputPassword"&gt;Password&lt;/label&gt;
        &lt;input type="password" class="form-control" id="inputPassword" placeholder="Password"&gt;
    &lt;/div&gt;
    &lt;div class="form-group mr-2"&gt;        
        &lt;label&gt;&lt;input type="checkbox" class="mr-1"&gt; Remember me&lt;/label&gt;
    &lt;/div&gt;
    &lt;button type="submit" class="btn btn-primary"&gt;Sign in&lt;/button&gt;
&lt;/form&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <p>&mdash; The output of the above example will look something like this:</p>
                <div class="shadow">
                    <div class="preview-box">
                        <a href="../codelab.php?topic=bootstrap&amp;file=inline-form-layout" target="_blank">
                            <img src="../lib/images/bootstrap-4/bootstrap-inline-form-layout.png" width="730" height="58" alt="Bootstrap Inline Form Layout" />
                        </a>
                    </div>
                </div>                
                <!--Note box-->
                <div class="color-box break">
                    <div class="shadow">
                        <div class="info-tab note-icon" title="Important Notes"><i></i></div>
                        <div class="note-box">
                            <p><strong>Note:</strong> It is recommended to include a label for every form inputs otherwise screen readers will have trouble with your forms. However, in case of inline form layouts you can hide the labels using the <code>.sr-only</code> class, so that only screen readers can read it.</p>
                        </div>
                    </div>
                </div>
                <!--End:Note box-->
                <p>Check out the snippets section for examples of some <a href="/snippets/gallery.php?tag=form" target="_blank">beautifully designed Bootstrap forms</a>.</p>
                <hr />
				<h2>Creating Static Form Control</h2>
                <p>There might be a situation when you just want to display a plain text value next to a form label instead of a working form control. You can do this easily by replacing the class <code>.form-control</code> with the <code>.form-control-plaintext</code> and applying the attribute <code>readonly</code>.</p>
                <p>The <code>.form-control-plaintext</code> class removes the default styling from the form field, but preserves the correct margin and padding. Let's take a look at an example:</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=static-form-control" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-markup">&lt;form&gt;
    &lt;div class="form-group row"&gt;
        &lt;label for="inputEmail" class="col-sm-2 col-form-label"&gt;Email&lt;/label&gt;
        &lt;div class="col-sm-10"&gt;
            &lt;input type="text" readonly class="form-control-plaintext" id="inputEmail" value="peterparker@example.com"&gt;
        &lt;/div&gt;
    &lt;/div&gt;
    &lt;div class="form-group row"&gt;
        &lt;label for="inputPassword" class="col-sm-2 col-form-label"&gt;Password&lt;/label&gt;
        &lt;div class="col-sm-10"&gt;
            &lt;input type="password" class="form-control" id="inputPassword" placeholder="Password"&gt;
        &lt;/div&gt;
    &lt;/div&gt;
    &lt;div class="form-group row"&gt;
        &lt;div class="col-sm-10 offset-sm-2"&gt;
            &lt;div class="checkbox"&gt;
                &lt;label&gt;&lt;input type="checkbox"&gt; Remember me&lt;/label&gt;
            &lt;/div&gt;
        &lt;/div&gt;
    &lt;/div&gt;
    &lt;div class="form-group row"&gt;
        &lt;div class="col-sm-10 offset-sm-2"&gt;
            &lt;button type="submit" class="btn btn-primary"&gt;Sign in&lt;/button&gt;
        &lt;/div&gt;
    &lt;/div&gt;
&lt;/form&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <p>&mdash; The output of the above example will look something like this:</p>
                <div class="shadow">
                    <div class="preview-box">
                        <a href="../codelab.php?topic=bootstrap&amp;file=static-form-control" target="_blank">
                            <img src="../lib/images/bootstrap-4/bootstrap-static-form-control.png" width="730" height="214" alt="Bootstrap Static Form Control" />
                        </a>
                    </div>
                </div>
                <hr />
				<h2 id="checkbox-and-radio">Placement of Checkboxes and Radios</h2>
				<p>Checkboxes and radio buttons can be placed either <em>stacked</em> or <em>inline</em>.</p>
				<h3>Stacked Checkboxes and Radios</h3>
				<p>To place the checkboxes or radio buttons vertically stacked i.e. line by line, just wrap all controls in a form group and apply the class <code>.d-block</code> on each <a href="/html-reference/html-label-tag.php"><code>&lt;label&gt;</code></a>. Additionally, use the margin utility classes for proper spacing, as shown in the following example:</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=stacked-checkbox-and-radio-buttons" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-markup">&lt;!-- Vertically stacked checkboxes --&gt;    
&lt;div class="form-group"&gt;
    &lt;label class="d-block"&gt;
        &lt;input type="checkbox" class="mr-1" name="sports"&gt; Cricket
    &lt;/label&gt;
    &lt;label class="d-block"&gt;
        &lt;input type="checkbox" class="mr-1" name="sports"&gt; Football
    &lt;/label&gt;
    &lt;label class="d-block"&gt;
        &lt;input type="checkbox" class="mr-1" name="sports"&gt; Tennis
    &lt;/label&gt;
&lt;/div&gt;
&lt;!-- Vertically stacked radios --&gt;
&lt;div class="form-group"&gt;
    &lt;label class="d-block"&gt;
        &lt;input type="radio" class="mr-1" name="gender"&gt; Male
    &lt;/label&gt;
    &lt;label class="d-block"&gt;
        &lt;input type="radio" class="mr-1" name="gender"&gt; Female
    &lt;/label&gt;
&lt;/div&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<h3>Inline Checkboxes and Radios</h3>
				<p>However, to place them inline i.e. side-by-side just place all form controls in a form group and use margin utility classes to ensure proper spacing. No need to use the <code>.d-block</code> class on the <code>&lt;label&gt;</code> element in this case. Let's check out the following example:</p>
				<!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=inline-checkbox-and-radio-buttons" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-markup">&lt;!-- Inline checkboxes --&gt;
&lt;div class="form-group"&gt;
    &lt;label class="mr-3"&gt;
        &lt;input type="checkbox" class="mr-1" name="sports"&gt; Cricket
    &lt;/label&gt;
    &lt;label class="mr-3"&gt;
        &lt;input type="checkbox" class="mr-1" name="sports"&gt; Football
    &lt;/label&gt;
    &lt;label class="mr-3"&gt;
        &lt;input type="checkbox" class="mr-1" name="sports"&gt; Tennis
    &lt;/label&gt;
&lt;/div&gt;
&lt;!-- Inline radios --&gt;
&lt;div class="form-group"&gt;
    &lt;label class="mr-3"&gt;
        &lt;input type="radio" class="mr-1" name="gender"&gt; Male
    &lt;/label&gt;
    &lt;label class="mr-3"&gt;
        &lt;input type="radio" class="mr-1" name="gender"&gt; Female
    &lt;/label&gt;
&lt;/div&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <hr />              
                <h2>Creating Disabled Form Controls</h2>
                <p>To disable individual form controls such as <code>&lt;input&gt;</code>, <code>&lt;textarea&gt;</code>, <code>&lt;select&gt;</code> just add the attributes <code>disabled</code> to them and Bootstrap will do the rest. Here's an example:</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=disabled-form-controls" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-markup">&lt;input type="text" class="form-control mb-2" placeholder="Disabled input" disabled&gt;
&lt;textarea class="form-control mb-2" placeholder="Disabled textarea" disabled&gt;&lt;/textarea&gt;
&lt;select id="disabledSelect" class="form-control" disabled&gt;
    &lt;option&gt;Disabled select&lt;/option&gt;
&lt;/select&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <p>&mdash; The output of the above example will look something like this:</p>
                <div class="shadow">
                    <div class="preview-box">
                        <a href="../codelab.php?topic=bootstrap&amp;file=disabled-form-controls" target="_blank">
                            <img src="../lib/images/bootstrap-4/bootstrap-disabled-form-controls.png" width="730" height="174" alt="Bootstrap Disabled Form Controls" />
                        </a>
                    </div>
                </div>
                <p>However, if you want to disable all controls within a <a href="/html-reference/html-form-tag.php"><code>&lt;form&gt;</code></a> at once place them inside a <a href="/html-reference/html-fieldset-tag.php"><code>&lt;fieldset&gt;</code></a> element and apply the attribute on it, as shown in the following example:</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=disabled-forms" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a><span class="box-size"><i title="Maximize"></i></span></div>
                        <pre class="syntax-highlighter line-numbers scroll xxlarge"><code class="language-markup">&lt;form&gt;
    &lt;fieldset disabled&gt;
        &lt;div class="form-group row"&gt;
            &lt;label for="inputEmail" class="col-sm-2 col-form-label"&gt;Email&lt;/label&gt;
            &lt;div class="col-sm-10"&gt;
                &lt;input type="email" class="form-control" id="inputEmail" placeholder="Email"&gt;
            &lt;/div&gt;
        &lt;/div&gt;
        &lt;div class="form-group row"&gt;
            &lt;label for="inputPassword" class="col-sm-2 col-form-label"&gt;Password&lt;/label&gt;
            &lt;div class="col-sm-10"&gt;
                &lt;input type="password" class="form-control" id="inputPassword" placeholder="Password"&gt;
            &lt;/div&gt;
        &lt;/div&gt;
        &lt;div class="form-group row"&gt;
            &lt;div class="col-sm-10 offset-sm-2"&gt;
                &lt;label class="form-check-label"&gt;&lt;input type="checkbox"&gt; Remember me&lt;/label&gt;
            &lt;/div&gt;
        &lt;/div&gt;
        &lt;div class="form-group row"&gt;
            &lt;div class="col-sm-10 offset-sm-2"&gt;
                &lt;button type="submit" class="btn btn-primary"&gt;Sign in&lt;/button&gt;
            &lt;/div&gt;
        &lt;/div&gt;
    &lt;/fieldset&gt;
&lt;/form&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <p>&mdash; The output of the above example will look something like this:</p>
                <div class="shadow">
                    <div class="preview-box">
                        <a href="../codelab.php?topic=bootstrap&amp;file=horizontal-form-layout" target="_blank">
                            <img src="../lib/images/bootstrap-4/bootstrap-disabled-forms.png" width="730" height="206" alt="Bootstrap Disabled Forms" />
                        </a>
                    </div>
                </div>
				<hr />
				<h2>Creating Readonly Inputs</h2>
                <p>You can also add the <code>readonly</code> boolean attribute on an input or textarea to prevent the modification of its value. Read-only inputs appear in lighter background (just like disabled inputs), but it retain the standard text cursor. Check out the following example to see how it works:</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=read-only-input-and-textarea" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-markup">&lt;input type="text" class="form-control mb-2" value="This input value cannot be changed." readonly&gt;
&lt;textarea rows="3" class="form-control" readonly&gt;This textarea value cannot be changed.&lt;/textarea&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <p>&mdash; The output of the above example will look something like this:</p>
                <div class="shadow">
                    <div class="preview-box">
                        <a href="../codelab.php?topic=bootstrap&amp;file=read-only-input-and-textarea" target="_blank">
                            <img src="../lib/images/bootstrap-4/bootstrap-read-only-input-and-textarea.png" width="730" height="152" alt="Bootstrap Read-only Input and Textarea" />
                        </a>
                    </div>
                </div>
                <hr />  
                <h2>Column Sizing of Inputs, Textareas and Select Boxes</h2>
                <p>You can also match the sizes of your form controls to the Bootstrap grid column sizes. Just wrap your form controls (i.e. <a href="../html-reference/html-input-tag.php"><code>&lt;input&gt;</code></a>, <a href="../html-reference/html-textarea-tag.php"><code>&lt;textarea&gt;</code></a>, and <a href="../html-reference/html-select-tag.php"><code>&lt;select&gt;</code></a>) in grid columns, or any custom element and apply the <a href="bootstrap-grid-system.php">grid classes</a> on it, as shown in the following example:</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=grid-sizing-of-form-controls" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-markup">&lt;div class="form-row"&gt;
    &lt;div class="form-group col-sm-6"&gt;
        &lt;label for="inputCity"&gt;City&lt;/label&gt;
        &lt;input type="text" class="form-control" id="inputCity"&gt;
    &lt;/div&gt;
    &lt;div class="form-group col-sm-4"&gt;
        &lt;label for="inputState"&gt;State&lt;/label&gt;
        &lt;select id="inputState" class="form-control"&gt;
            &lt;option&gt;Select&lt;/option&gt;
        &lt;/select&gt;
    &lt;/div&gt;
    &lt;div class="form-group col-sm-2"&gt;
        &lt;label for="inputZip"&gt;Zip&lt;/label&gt;
        &lt;input type="text" class="form-control" id="inputZip"&gt;
    &lt;/div&gt;
&lt;/div&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <!--Tip Box-->
				<div class="color-box">
					<div class="shadow">
						<div class="info-tab tip-icon" title="Useful Tips"><i></i></div>
						<div class="tip-box">
							<p><strong>Tip:</strong> You can alternatively use the class <code>.form-row</code> in place of <code>.row</code> while creating form layouts. The <code>.form-row</code> class is a variation of standard Bootstrap grid <code>.row</code> which overrides the default column gutters for tighter and more compact layouts.</p>
						</div>
					</div>
				</div>
				<!--End:Tip Box-->
                <hr />
                <h2>Height Sizing of Inputs and Select Boxes</h2>
                <p>You can easily change the height of your text input and select boxes to match the <a href="bootstrap-buttons.php">button sizes</a>. Use the form control height sizing classes like <code>.form-control-lg</code>, <code>.form-control-sm</code> on the <a href="../html-reference/html-input-tag.php"><code>&lt;input&gt;</code></a> and <a href="../html-reference/html-select-tag.php"><code>&lt;select&gt;</code></a> boxes to create it's larger or smaller sizes.</p>
                <p>Also, be sure to apply the class <code>.col-form-label-sm</code> or <code>.col-form-label-lg</code> on the <a href="/html-reference/html-label-tag.php"><code>&lt;label&gt;</code></a> or <a href="/html-reference/html-legend-tag.php"><code>&lt;legend&gt;</code></a> elements to correctly resize the label accordion to the form controls.</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=height-sizing-of-form-controls" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a><span class="box-size"><i title="Maximize"></i></span></div>
                        <pre class="syntax-highlighter line-numbers scroll xxlarge"><code class="language-markup">&lt;form&gt;
    &lt;div class="form-group row"&gt;
        &lt;label class="col-sm-2 col-form-label col-form-label-lg"&gt;Email&lt;/label&gt;
        &lt;div class="col-sm-10"&gt;
            &lt;input type="email" class="form-control form-control-lg" placeholder="Large input"&gt;
        &lt;/div&gt;
    &lt;/div&gt;
    &lt;div class="form-group row"&gt;
        &lt;label class="col-sm-2 col-form-label"&gt;Email&lt;/label&gt;
        &lt;div class="col-sm-10"&gt;
            &lt;input type="email" class="form-control" placeholder="Default input"&gt;
        &lt;/div&gt;
    &lt;/div&gt;
    &lt;div class="form-group row"&gt;
        &lt;label class="col-sm-2 col-form-label"&gt;Email&lt;/label&gt;
        &lt;div class="col-sm-10"&gt;
            &lt;input type="email" class="form-control form-control-sm" placeholder="Small input"&gt;
        &lt;/div&gt;
    &lt;/div&gt;
    &lt;hr&gt;
    &lt;div class="form-group row"&gt;
        &lt;label class="col-sm-2 col-form-label col-form-label-lg"&gt;State&lt;/label&gt;
        &lt;div class="col-sm-10"&gt;
            &lt;select class="form-control form-control-lg"&gt;
                &lt;option&gt;Large select&lt;/option&gt;
            &lt;/select&gt;
        &lt;/div&gt;
    &lt;/div&gt;    
    &lt;div class="form-group row"&gt;
        &lt;label class="col-sm-2 col-form-label"&gt;State&lt;/label&gt;
        &lt;div class="col-sm-10"&gt;
            &lt;select class="form-control"&gt;
                &lt;option&gt;Default select&lt;/option&gt;
            &lt;/select&gt;
        &lt;/div&gt;
    &lt;/div&gt;    
    &lt;div class="form-group row"&gt;
        &lt;label class="col-sm-2 col-form-label col-form-label-sm"&gt;State&lt;/label&gt;
        &lt;div class="col-sm-10"&gt;
            &lt;select class="form-control form-control-sm"&gt;
                &lt;option&gt;Small select&lt;/option&gt;
            &lt;/select&gt;
        &lt;/div&gt;
    &lt;/div&gt;
&lt;/form&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
				<hr />
                <h2>Placing Help Text around Form Controls</h2>
                <p>Placing help text for the form controls in an efficient way to guide users to enter the correct data in a form. You can place block level help text for a form control using the class <code>.form-text</code>. The block help text is typically displayed at the bottom of the control. Here's an example:</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=block-help-text" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-markup">&lt;div class="form-group"&gt;
    &lt;label&gt;Password&lt;/label&gt;
    &lt;input type="password" class="form-control"&gt;
    &lt;small class="form-text text-muted"&gt;
        Your password must be 8-20 characters long, contain letters, numbers and special characters, but must not contain spaces.
    &lt;/small&gt;
&lt;/div&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <p>&mdash; The output of the above example will look something like this:</p>
                <div class="shadow">
                    <div class="preview-box">
                        <a href="../codelab.php?topic=bootstrap&amp;file=block-help-text" target="_blank">
                            <img src="../lib/images/bootstrap-4/bootstrap-block-help-text.png" width="730" height="116" alt="Bootstrap Block Help Text" />
                        </a>
                    </div>
                </div>
                <p>Similarly, you can also place inline help text using the <code>&lt;small&gt;</code> element. No need to use <code>.form-text</code> in this case. The following example shows how to implement this:</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=inline-help-text" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-markup">&lt;form class="form-inline"&gt;
    &lt;div class="form-group"&gt;
        &lt;label&gt;Password&lt;/label&gt;
        &lt;input type="password" class="form-control mx-sm-3"&gt;
        &lt;small class="text-muted"&gt;Must be 8-20 characters long.&lt;/small&gt;
    &lt;/div&gt;
&lt;/form&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <p>&mdash; The output of the above example will look something like this:</p>
                <div class="shadow">
                    <div class="preview-box">
                        <a href="../codelab.php?topic=bootstrap&amp;file=inline-help-text" target="_blank">
                            <img src="../lib/images/bootstrap-4/bootstrap-inline-help-text.png" width="730" height="61" alt="Bootstrap Inline Help Text" />
                        </a>
                    </div>
                </div>
                <hr />
                <h2>Bootstrap Form Validation</h2>
                <p>Bootstrap 4 provides an easy and quick way to validate web forms on client-side. It uses browser's native form validation API to validate the form. Form validation styles are applied via CSS <code>:invalid</code> and <code>:valid</code> pseudo-classes. It applies to <code>&lt;input&gt;</code>, <code>&lt;select&gt;</code>, and <code>&lt;textarea&gt;</code> elements.</p>
                <p>Let's check out the following example to see how it actually works:</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=form-validation" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-markup">&lt;form class="needs-validation" novalidate&gt;
    &lt;div class="form-group"&gt;
        &lt;label for="inputEmail"&gt;Email&lt;/label&gt;
        &lt;input type="email" class="form-control" id="inputEmail" placeholder="Email" required&gt;
        &lt;div class="invalid-feedback"&gt;Please enter a valid email address.&lt;/div&gt;
    &lt;/div&gt;
    &lt;div class="form-group"&gt;
        &lt;label for="inputPassword"&gt;Password&lt;/label&gt;
        &lt;input type="password" class="form-control" id="inputPassword" placeholder="Password" required&gt;
        &lt;div class="invalid-feedback"&gt;Please enter your password to continue.&lt;/div&gt;
    &lt;/div&gt;
    &lt;div class="form-group"&gt;
        &lt;label class="form-check-label"&gt;&lt;input type="checkbox"&gt; Remember me&lt;/label&gt;
    &lt;/div&gt;
    &lt;button type="submit" class="btn btn-primary"&gt;Sign in&lt;/button&gt;
&lt;/form&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->                
                <!--Note box-->
                <div class="color-box">
                    <div class="shadow">
                        <div class="info-tab note-icon" title="Important Notes"><i></i></div>
                        <div class="note-box">
                            <p><strong>Note:</strong> For custom Bootstrap form validation messages, you'll need to disables the browser default feedback tooltips by adding the <code>novalidate</code> boolean attribute to the <code>&lt;form&gt;</code> element. However, it still provides access to the form validation APIs in JavaScript.</p>
                        </div>
                    </div>
                </div>
                <!--End:Note box-->                
                <p>Here's the custom JavaScript code that displays error messages and disables form submission if there are invalid fields. See the <a href="/javascript-tutorial/javascript-closures.php">JavaScript closures</a> chapter to learn about self-executing function.</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=form-validation" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-javascript">&lt;script&gt;
    // Self-executing function
    (function() {
        'use strict';
        window.addEventListener('load', function() {
            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            var forms = document.getElementsByClassName('needs-validation');
            // Loop over them and prevent submission
            var validation = Array.prototype.filter.call(forms, function(form) {
                form.addEventListener('submit', function(event) {
                    if (form.checkValidity() === false) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });
        }, false);
    })();
&lt;/script&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <p>&mdash; The output of the above example will look something like this:</p>
                <div class="shadow break">
                    <div class="preview-box">
                        <a href="../codelab.php?topic=bootstrap&amp;file=form-validation" target="_blank">
                            <img src="../lib/images/bootstrap-4/bootstrap-form-validation.png" width="730" height="296" alt="Bootstrap Form Validation" />
                        </a>
                    </div>
                </div>
                <!--Tip Box-->
                <div class="color-box">
                    <div class="shadow">
                        <div class="info-tab tip-icon" title="Useful Tips"><i></i></div>
                        <div class="tip-box">
                            <p><strong>Tip:</strong> To reset the appearance of the form programmatically, remove the class <code>.was-validated</code> class from the <code>&lt;form&gt;</code> element after submission. This class is applied automatically on the form by the Bootstrap when you click the submit button.</p>
                        </div>
                    </div>
                </div>
                <!--End:Tip Box-->
                <p>If you require server-side validation, you can indicate invalid and valid form fields with the <code>.is-invalid</code> and <code>.is-valid</code>. The <code>.invalid-feedback</code> and <code>.valid-feedback</code> are also supported with these classes. Try out the following example to see how it works:</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=server-side-form-validation" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-markup">&lt;form&gt;
    &lt;div class="form-group"&gt;
        &lt;label for="inputEmail"&gt;Email&lt;/label&gt;
        &lt;input type="email" class="form-control is-valid" id="inputEmail" placeholder="Email" value="peterparker@example.com" required&gt;
        &lt;div class="valid-feedback"&gt;Good! Your email address looks valid.&lt;/div&gt;
    &lt;/div&gt;
    &lt;div class="form-group"&gt;
        &lt;label for="inputPassword"&gt;Password&lt;/label&gt;
        &lt;input type="password" class="form-control is-invalid" id="inputPassword" placeholder="Password" required&gt;
        &lt;div class="invalid-feedback"&gt;Opps! You have entered an invalid password.&lt;/div&gt;
    &lt;/div&gt;
    &lt;div class="form-group"&gt;
        &lt;label class="form-check-label"&gt;&lt;input type="checkbox"&gt; Remember me&lt;/label&gt;
    &lt;/div&gt;
    &lt;button type="submit" class="btn btn-primary"&gt;Sign in&lt;/button&gt;
&lt;/form&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <p>&mdash; The output of the above example will look something like this:</p>
                <div class="shadow break">
                    <div class="preview-box">
                        <a href="../codelab.php?topic=bootstrap&amp;file=form-validation" target="_blank">
                            <img src="../lib/images/bootstrap-4/bootstrap-server-side-form-validation.png" width="730" height="319" alt="Bootstrap Server Side Form Validation" />
                        </a>
                    </div>
                </div>
                <p>You can alternatively swap the <code>.{valid|invalid}-feedback</code> classes for <code>.{valid|invalid}-tooltip</code> classes to display the validation feedback text in a tooltip style.</p>
                <p>Also, be sure to apply the style <code>position: relative</code> or class <code>.position-relative</code> on the parent element for proper feedback tooltip positioning. Here's an example:</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=display-validation-feedback-in-tooltip-style" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a></div>
                        <pre class="syntax-highlighter line-numbers"><code class="language-markup">&lt;form&gt;
    &lt;div class="form-group position-relative"&gt;
        &lt;label for="inputEmail"&gt;Email&lt;/label&gt;
        &lt;input type="email" class="form-control is-valid" id="inputEmail" placeholder="Email" value="peterparker@example.com" required&gt;
        &lt;div class="valid-tooltip"&gt;Good! Your email address looks valid.&lt;/div&gt;
    &lt;/div&gt;
    &lt;div class="form-group position-relative"&gt;
        &lt;label for="inputPassword"&gt;Password&lt;/label&gt;
        &lt;input type="password" class="form-control is-invalid" id="inputPassword" placeholder="Password" required&gt;
        &lt;div class="invalid-tooltip"&gt;Opps! You have entered an invalid password.&lt;/div&gt;
    &lt;/div&gt;
    &lt;div class="form-group"&gt;
        &lt;label class="form-check-label"&gt;&lt;input type="checkbox"&gt; Remember me&lt;/label&gt;
    &lt;/div&gt;
    &lt;button type="submit" class="btn btn-primary"&gt;Sign in&lt;/button&gt;
&lt;/form&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->
                <p>&mdash; The output of the above example will look something like this:</p>
                <div class="shadow break">
                    <div class="preview-box">
                        <a href="../codelab.php?topic=bootstrap&amp;file=display-validation-feedback-in-tooltip-style" target="_blank">
                            <img src="../lib/images/bootstrap-4/bootstrap-form-validation-feedback-in-styled-tooltip.png" width="730" height="273" alt="Bootstrap Form Validation Feedback in Styled Tooltip" />
                        </a>
                    </div>
                </div>
                <!--Note box-->
                <div class="color-box">
                    <div class="shadow">
                        <div class="info-tab note-icon" title="Important Notes"><i></i></div>
                        <div class="note-box">
                            <p><strong>Note:</strong> Background icons for <code>&lt;select&gt;</code> elements only work properly with <code>.custom-select</code>, not with <code>.form-control</code>. We will learn about <a href="bootstrap-custom-forms.php">Bootstrap custom forms</a> in next chapter.</p>
                        </div>
                    </div>
                </div>
                <!--End:Note box-->
                <hr />
                <h2>Supported Form Controls in Bootstrap</h2>
                <p>Bootstrap includes support for all standard HTML form controls as well as <a href="../html-tutorial/html5-new-input-types.php">new HTML5 input types</a> such as datetime, number, email, url, search, range, color, url, and so on. The following example will show you the usages of standard form controls with Bootstrap.</p>
                <!--Code box-->
                <div class="example">
                    <div class="codebox">
                        <div class="codebox-title"><h4>Example</h4><a href="../codelab.php?topic=bootstrap&amp;file=supported-from-controls" target="_blank" class="try-btn" title="Try this code using online Editor">Try this code <span>&raquo;</span></a><span class="box-size"><i title="Maximize"></i></span></div>
                        <pre class="syntax-highlighter line-numbers scroll xxlarge"><code class="language-markup">&lt;form&gt;
&lt;div class="form-group row"&gt;
    &lt;label class="col-sm-3 col-form-label" for="firstName"&gt;First Name:&lt;/label&gt;
    &lt;div class="col-sm-9"&gt;
        &lt;input type="text" class="form-control" id="firstName" placeholder="First Name" required&gt;
    &lt;/div&gt;
&lt;/div&gt;
&lt;div class="form-group row"&gt;
    &lt;label class="col-sm-3 col-form-label" for="lastName"&gt;Last Name:&lt;/label&gt;
    &lt;div class="col-sm-9"&gt;
        &lt;input type="text" class="form-control" id="lastName" placeholder="Last Name" required&gt;
    &lt;/div&gt;
&lt;/div&gt;
&lt;div class="form-group row"&gt;
    &lt;label class="col-sm-3 col-form-label" for="inputEmail"&gt;Email Address:&lt;/label&gt;
    &lt;div class="col-sm-9"&gt;
        &lt;input type="email" class="form-control" id="inputEmail" placeholder="Email Address" required&gt;
    &lt;/div&gt;
&lt;/div&gt;
&lt;div class="form-group row"&gt;
    &lt;label class="col-sm-3 col-form-label" for="phoneNumber"&gt;Mobile Number:&lt;/label&gt;
    &lt;div class="col-sm-9"&gt;
        &lt;input type="number" class="form-control" id="phoneNumber" placeholder="Phone Number" required&gt;
    &lt;/div&gt;
&lt;/div&gt;
&lt;div class="form-group row"&gt;
    &lt;label class="col-sm-3 col-form-label"&gt;Date of Birth:&lt;/label&gt;
    &lt;div class="col-sm-3"&gt;
        &lt;select class="custom-select"&gt;
            &lt;option&gt;Date&lt;/option&gt;
        &lt;/select&gt;
    &lt;/div&gt;
    &lt;div class="col-sm-3"&gt;
        &lt;select class="custom-select"&gt;
            &lt;option&gt;Month&lt;/option&gt;
        &lt;/select&gt;
    &lt;/div&gt;
    &lt;div class="col-sm-3"&gt;
        &lt;select class="custom-select"&gt;
            &lt;option&gt;Year&lt;/option&gt;
        &lt;/select&gt;
    &lt;/div&gt;
&lt;/div&gt;
&lt;div class="form-group row"&gt;
    &lt;label class="col-sm-3 col-form-label" for="postalAddress"&gt;Postal Address:&lt;/label&gt;
    &lt;div class="col-sm-9"&gt;
        &lt;textarea rows="3" class="form-control" id="postalAddress" placeholder="Postal Address" required&gt;&lt;/textarea&gt;
    &lt;/div&gt;
&lt;/div&gt;
&lt;div class="form-group row"&gt;
    &lt;label class="col-sm-3 col-form-label" for="ZipCode"&gt;Zip Code:&lt;/label&gt;
    &lt;div class="col-sm-9"&gt;
        &lt;input type="text" class="form-control" id="ZipCode" placeholder="Zip Code" required&gt;
    &lt;/div&gt;
&lt;/div&gt;
&lt;div class="form-group row"&gt;
    &lt;label class="col-sm-3 col-form-label"&gt;Gender:&lt;/label&gt;
    &lt;div class="col-sm-9 mt-2"&gt;
        &lt;label class="mb-0 mr-3"&gt;
            &lt;input type="radio" class="mr-1" name="gender"&gt; Male
        &lt;/label&gt;
        &lt;label class="mb-0 mr-3"&gt;
            &lt;input type="radio" class="mr-1" name="gender"&gt; Female
        &lt;/label&gt;
    &lt;/div&gt;
&lt;/div&gt;
&lt;div class="form-group row"&gt;
    &lt;div class="col-sm-9 offset-sm-3"&gt;
        &lt;label class="checkbox-inline"&gt;
            &lt;input type="checkbox" class="mr-1" value="agree"&gt; I agree to the &lt;a href="#"&gt;Terms and Conditions&lt;/a&gt;.
        &lt;/label&gt;
    &lt;/div&gt;
&lt;/div&gt;
&lt;div class="form-group row"&gt;
    &lt;div class="col-sm-9 offset-sm-3"&gt;
        &lt;input type="submit" class="btn btn-primary" value="Submit"&gt;
        &lt;input type="reset" class="btn btn-secondary" value="Reset"&gt;
    &lt;/div&gt;
&lt;/div&gt;
&lt;/form&gt;</code></pre>
                    </div>
                </div>
                <!--End:Code box-->				
                <!--Bottom Navigation-->
                <div class="bottom-link clearfix">
                    <a href="bootstrap-list-groups.php" class="previous-page-bottom">Previous Page</a>
                    <a href="bootstrap-custom-forms.php" class="next-page-bottom">Next Page</a>
                </div>
                <!--End:Bottom Navigation-->
                <!-- InstanceEndEditable -->
                <!--Bottom Ads-->
                <div class="bottom-ad clearfix">
                    <div class="ad-label">Advertisements</div>

<!--Rectangle Left-->
<div class="rectangle-left fl">
    
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Large Rectangle Left -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="8162953958"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
<!--End:Rectangle Left-->


<!--Rectangle Right-->
<div class="rectangle-right fr">

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Large Rectangle Right -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="3324015654"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
<!--End:Rectangle Right-->                </div>
                <!--End:Bottom Ads-->
            </div>
            <!--End:Text Content-->
            <!--Feedback Form-->
			<div class="snippets">
	<a href="/snippets/gallery.php" target="_blank">
    	<img src="/lib/images/bootstrap-code-snippets.png" alt="Bootstrap UI Design Templates" />
	</a>
</div>

<div class="report-error" id="feedback">
    <div class="contact-form clearfix">
        <div class="close"><span class="icon-close"></span></div>
        <form id="feedback-form">
            <h3>Your Feedback:</h3>
            <div class="clearfix">
                <div class="name fl"><label>Your Name (optional) <input type="text" name="user-name" id="user-name" /></label></div>
                <div class="email fr"><label>Your E-mail (optional) <input type="text" name="user-email" id="user-email" /></label></div>
            </div>
            <div><label>Page address <input type="text" name="page-url" id="page-url" class="disabled" disabled="disabled" /></label></div>
            <div><label>Description <textarea name="description" id="description" rows="6"></textarea></label></div>
            <p id="feedback-error">We would love to hear from you, please drop us a line.</p>
            <div><button type="button" class="action-btn" onclick="sendFeedback()"><span class="icon-send"></span> Send</button></div>
        </form>
        <div id="response"></div>
    </div>           
</div>            <!--End:Feedback Form-->
        </div>        
        <div class="sidebar">
            <div class="ad-label">Advertisements</div>

<div class="skyscraper primary">

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Premium Skyscraper -->
<ins class="adsbygoogle"
     style="display:inline-block;width:160px;height:600px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="4376141825"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>

<div class="skyscraper">
    
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Bottom Skyscraper -->
<ins class="adsbygoogle"
     style="display:inline-block;width:160px;height:600px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="3387984471"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>        </div>
    </div>
    <!--Footer-->
	<!--Footer-->
<div class="footer">
    <div class="appeal">
        <div class="wrapper">
            <p>Is this website helpful to you? Please give us a
            <a href="/like.php" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=250,width=600,top=150, left='+((screen.width/2)-300));return false;">like</a>,
            or share your <a href="#feedback" class="feedback">feedback</a><em> to help us improve</em>.
            Connect with us on <a href="https://www.facebook.com/tutorialrepublic" target="_blank">Facebook</a> and <a href="https://twitter.com/tutrepublic" target="_blank">Twitter</a> for the latest updates.</p>               
        </div>
    </div>
    <div class="footer-inner">
        <div class="wrapper clearfix">                
            <div class="link-box">
                <h4>About Us</h4>
                <div class="clearfix">
                    <a href="/about-us.php">Our Story</a>                    
                    <a href="/terms-of-use.php">Terms of Use</a>
                    <a href="/privacy-policy.php">Privacy Policy</a>                    
                </div>
            </div>
            <div class="link-box">
                <h4>Contact</h4>
                <div class="clearfix">
                    <a href="/contact-us.php">Contact Us</a>                    
                    <a href="#feedback" class="feedback">Report Error</a>
                    <a href="/advertise-with-us.php">Advertise</a>                    
                </div>
            </div>
            <div class="tool-box">
                <h4>Interactive Tools</h4>
                <div class="tools-list clearfix" id="tools">
                    <a href="/faq/what-is-the-maximum-length-of-title-and-meta-description-tag.php">Title &amp; Meta Length Calculator</a>                           
                    <a href="/html-formatter.php" target="_blank">HTML Formatter</a>                        
                    <a href="/twitter-bootstrap-button-generator.php" target="_blank">Bootstrap Button Generator</a>
                    <a href="/html-reference/html-color-picker.php">HTML Color Picker</a>
                    <a href="/codelab.php?topic=sql&amp;file=select-all" target="_blank">SQL Playground</a>
                    <a href="/codelab.php?topic=html&amp;file=hello-world" target="_blank">HTML Editor</a>                    
                </div>
            </div>
            <div class="footer-logo">
                <img src="/lib/images/logo.svg" alt="TutorialRepublic" />
            </div>
        </div>
    </div>           
        <div class="bottom-strip">
        <div class="wrapper">
            <div class="notice">Copyright &copy; 2019 Tutorial Republic. All Rights Reserved.</div>
            <div class="social-media">
                <em>Share This:</em>
                <a href="https://facebook.com/sharer.php?u=https://www.tutorialrepublic.com%2Ftwitter-bootstrap-tutorial%2Fbootstrap-forms.php" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" title="Facebook"><i class="icon-facebook"></i></a>
                <a href="#" id="tweet-btn" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" title="Twitter"><i class="icon-twitter"></i></a>
                <a href="#" id="email-btn" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" rel="noreferrer" title="Gmail"><i class="icon-mail"></i></a>
            </div>
        </div>            
    </div>
    <script>
        var title = document.title.replace('- Tutorial Republic', '');
        document.getElementById('tweet-btn').href = 'https://twitter.com/share?text=' + title + '- &url=https://www.tutorialrepublic.com%2Ftwitter-bootstrap-tutorial%2Fbootstrap-forms.php';
        document.getElementById('email-btn').href = 'https://mail.google.com/mail/?view=cm&fs=1&su=' + title + '&body=https://www.tutorialrepublic.com%2Ftwitter-bootstrap-tutorial%2Fbootstrap-forms.php';
    </script>
</div>
<!--End:Footer-->
    
<div class="backdrop mobile-only"></div>

<!-- TutorialRepublic base script -->
<script>
// Adding CSS files
[
	'/lib/styles/extended.new-3.7.css',
	'/lib/icomoon/style.css'
].forEach(function(href) {
	var link = document.createElement('link');
	link.rel = 'stylesheet';
	link.href = href;
	(document.getElementsByTagName('head')[0]).appendChild(link);
});

// Adding JS files
[
	'https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js',
	'/lib/js/prism.js',
	'/lib/js/default.new-2.9.min.js'
].forEach(function(src) {
	var script = document.createElement('script');
	script.async = false; // important
	script.src = src;
	(document.getElementsByTagName('body')[0]).appendChild(script);
});
</script>


    <!--End:Footer-->
</body>
<!-- InstanceEnd --></html>