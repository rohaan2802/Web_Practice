
<!DOCTYPE html>
<html lang="en">
<head>
<title>Free Bootstrap Code Snippets & UI Templates - Tutorial Republic</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta property="fb:admins" content="100001054961582" />
<meta property="fb:app_id" content="1404574483159557" />
<link type="image/x-icon" href="/favicon.ico" rel="shortcut icon" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
<link rel="stylesheet" href="/lib/styles/snippets-1.7.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="/lib/js/snippets-1.0.js"></script><!--Google Analytics-->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-40117907-1', 'auto');
  ga('send', 'pageview');
</script><!--End:Google Analytics-->
</head>
<body>
<nav class="navbar navbar-default navbar-static-top">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="navbar-header">
                <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a href="//www.tutorialrepublic.com" class="navbar-brand">Tutorial Republic</a>
            </div>
            <!-- Collection of nav links and other content for toggling -->
            <div id="navbarCollapse" class="collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li><a href="//www.tutorialrepublic.com/snippets/gallery.php" title="Snippets Home">HOME</a></li>
                    <li><a href="/html-tutorial/" title="HTML Tutorial">HTML</a></li>
                    <li><a href="/css-tutorial/" title="CSS Tutorial">CSS</a></li>
                    <li><a href="/jquery-tutorial/" title="JQUERY Tutorial">JQUERY</a></li>
                    <li><a href="/twitter-bootstrap-tutorial/" title="BOOTSTRAP Tutorial">BOOTSTRAP</a></li>
                    <li><a href="/php-tutorial/" title="PHP Tutorial">PHP</a></li>
                    <li><a href="/sql-tutorial/" title="SQL Tutorial">SQL</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="/about-us.php">About</a></li>
                    <li><a href="/contact-us.php">Contact</a></li>
                </ul>
            </div>
            </div>
        </div>            
    </div>
</nav>
<div class="header">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Bootstrap Snippets</h1>
                <p class="lead">Free ready to use UI design elements / templates, code snippets and playground for the Bootstrap framework.</p>
            </div>            
        </div>
    </div>
</div>
<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="lead-main">
					<div class="ad-label">Advertisements</div>
                    <div class="ad-box">
                        <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Responsive Leaderboard -->
<ins class="adsbygoogle"
     style="display:block;width:100%;height:90px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="4302666817"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>                    </div>
                </div>                
            </div>
        </div>

		<div class="row">
            <div class="col-md-12">
                <div class="snippet-tags">
                    <span class="glyphicon glyphicon-tags"></span> Tags:    
                    <a href="gallery.php">all</a>
                    <a href="gallery.php?tag=alert">alert</a>
                    <a href="gallery.php?tag=accordion">accordion</a>
                    <a href="gallery.php?tag=carousel">carousel</a>
                    <a href="gallery.php?tag=dropdown">dropdown</a>
                    <a href="gallery.php?tag=form">form</a>
                    <a href="gallery.php?tag=login">login</a>
                    <a href="gallery.php?tag=media-object">media object</a>
                    <a href="gallery.php?tag=modal">modal</a>
                    <a href="gallery.php?tag=navbar">navbar</a>
                    <a href="gallery.php?tag=pagination">pagination</a>
                    <a href="gallery.php?tag=sign-up">sign up</a>
                    <a href="gallery.php?tag=table">table</a>
                    <a href="gallery.php?tag=thumbnail">thumbnail</a>
                </div>
            </div>
        </div>        

                <div class="row">
                        <div class="col-md-3 col-sm-4">
                <a href="preview.php?topic=bootstrap&amp;file=crud-data-table-for-database-with-modal-form" id="42" target="_blank">
                    <div class="thumbnail">                    
                        <div class="img-box">
                            <img src="designs/crud-data-table-for-database-with-modal-form.png" class="img-responsive"  alt="Crud Data Table For Database with Modal Form">                        </div>                        
                        <div class="caption">
                            <h3>Crud Data Table For Database with Modal Form</h3>
                            <div class="overview clearfix">
                                <div class="pull-left">
                                    <span class="version" title="Supported Versions" data-toggle="tooltip">
                                        <span class="glyphicon glyphicon-bookmark"></span> BS3, BS4                                    </span>
                                </div>
                                <div class="pull-right">
                                    <span class="views" title="Views" data-toggle="tooltip">
                                        <span class="glyphicon glyphicon-eye-open"></span> 157183                                    </span>                                    
                                </div>
                            </div>
                        </div>                  
                    </div>
                </a>
            </div>
                        <div class="col-md-3 col-sm-4">
                <a href="preview.php?topic=bootstrap&amp;file=simple-login-form" id="6" target="_blank">
                    <div class="thumbnail">                    
                        <div class="img-box">
                            <img src="designs/simple-login-form.png" class="img-responsive"  alt="Simple Login Form">                        </div>                        
                        <div class="caption">
                            <h3>Simple Login Form</h3>
                            <div class="overview clearfix">
                                <div class="pull-left">
                                    <span class="version" title="Supported Versions" data-toggle="tooltip">
                                        <span class="glyphicon glyphicon-bookmark"></span> BS3, BS4                                    </span>
                                </div>
                                <div class="pull-right">
                                    <span class="views" title="Views" data-toggle="tooltip">
                                        <span class="glyphicon glyphicon-eye-open"></span> 136506                                    </span>                                    
                                </div>
                            </div>
                        </div>                  
                    </div>
                </a>
            </div>
                        <div class="col-md-3 col-sm-4">
                <a href="preview.php?topic=bootstrap&amp;file=table-with-add-and-delete-row-feature" id="41" target="_blank">
                    <div class="thumbnail">                    
                        <div class="img-box">
                            <img src="designs/table-with-add-and-delete-row-feature.png" class="img-responsive"  alt="Table with Add and Delete Row Feature">                        </div>                        
                        <div class="caption">
                            <h3>Table with Add and Delete Row Feature</h3>
                            <div class="overview clearfix">
                                <div class="pull-left">
                                    <span class="version" title="Supported Versions" data-toggle="tooltip">
                                        <span class="glyphicon glyphicon-bookmark"></span> BS3, BS4                                    </span>
                                </div>
                                <div class="pull-right">
                                    <span class="views" title="Views" data-toggle="tooltip">
                                        <span class="glyphicon glyphicon-eye-open"></span> 93475                                    </span>                                    
                                </div>
                            </div>
                        </div>                  
                    </div>
                </a>
            </div>
                        <div class="col-md-3 col-sm-4">
                <a href="preview.php?topic=bootstrap&amp;file=elegant-modal-login-form-with-avatar-icon" id="28" target="_blank">
                    <div class="thumbnail">                    
                        <div class="img-box">
                            <img src="designs/elegant-modal-login-form-with-avatar-icon.png" class="img-responsive"  alt="Elegant Modal Login Form with Avatar Icon">                        </div>                        
                        <div class="caption">
                            <h3>Elegant Modal Login Form with Avatar Icon</h3>
                            <div class="overview clearfix">
                                <div class="pull-left">
                                    <span class="version" title="Supported Versions" data-toggle="tooltip">
                                        <span class="glyphicon glyphicon-bookmark"></span> BS3, BS4                                    </span>
                                </div>
                                <div class="pull-right">
                                    <span class="views" title="Views" data-toggle="tooltip">
                                        <span class="glyphicon glyphicon-eye-open"></span> 62747                                    </span>                                    
                                </div>
                            </div>
                        </div>                  
                    </div>
                </a>
            </div>
                        <div class="col-md-3 col-sm-4">
                <a href="preview.php?topic=bootstrap&amp;file=simple-registration-form" id="22" target="_blank">
                    <div class="thumbnail">                    
                        <div class="img-box">
                            <img src="designs/simple-registration-form.png" class="img-responsive"  alt="Simple Registration Form">                        </div>                        
                        <div class="caption">
                            <h3>Simple Registration Form</h3>
                            <div class="overview clearfix">
                                <div class="pull-left">
                                    <span class="version" title="Supported Versions" data-toggle="tooltip">
                                        <span class="glyphicon glyphicon-bookmark"></span> BS3, BS4                                    </span>
                                </div>
                                <div class="pull-right">
                                    <span class="views" title="Views" data-toggle="tooltip">
                                        <span class="glyphicon glyphicon-eye-open"></span> 57993                                    </span>                                    
                                </div>
                            </div>
                        </div>                  
                    </div>
                </a>
            </div>
                        <div class="col-md-3 col-sm-4">
                <a href="preview.php?topic=bootstrap&amp;file=delete-confirmation-modal" id="56" target="_blank">
                    <div class="thumbnail">                    
                        <div class="img-box">
                            <img src="designs/delete-confirmation-modal.png" class="img-responsive"  alt="Delete Confirmation Modal">                        </div>                        
                        <div class="caption">
                            <h3>Delete Confirmation Modal</h3>
                            <div class="overview clearfix">
                                <div class="pull-left">
                                    <span class="version" title="Supported Versions" data-toggle="tooltip">
                                        <span class="glyphicon glyphicon-bookmark"></span> BS3, BS4                                    </span>
                                </div>
                                <div class="pull-right">
                                    <span class="views" title="Views" data-toggle="tooltip">
                                        <span class="glyphicon glyphicon-eye-open"></span> 48214                                    </span>                                    
                                </div>
                            </div>
                        </div>                  
                    </div>
                </a>
            </div>
                        <div class="col-md-3 col-sm-4">
                <a href="preview.php?topic=bootstrap&amp;file=user-management-data-table" id="37" target="_blank">
                    <div class="thumbnail">                    
                        <div class="img-box">
                            <img src="designs/user-management-data-table.png" class="img-responsive"  alt="User Management Data Table">                        </div>                        
                        <div class="caption">
                            <h3>User Management Data Table</h3>
                            <div class="overview clearfix">
                                <div class="pull-left">
                                    <span class="version" title="Supported Versions" data-toggle="tooltip">
                                        <span class="glyphicon glyphicon-bookmark"></span> BS3, BS4                                    </span>
                                </div>
                                <div class="pull-right">
                                    <span class="views" title="Views" data-toggle="tooltip">
                                        <span class="glyphicon glyphicon-eye-open"></span> 39138                                    </span>                                    
                                </div>
                            </div>
                        </div>                  
                    </div>
                </a>
            </div>
                        <div class="col-md-3 col-sm-4">
                <a href="preview.php?topic=bootstrap&amp;file=elegant-modal-login-form-with-icons" id="27" target="_blank">
                    <div class="thumbnail">                    
                        <div class="img-box">
                            <img src="designs/elegant-modal-login-form-with-icons.png" class="img-responsive"  alt="Elegant Modal Login Form with Icons">                        </div>                        
                        <div class="caption">
                            <h3>Elegant Modal Login Form with Icons</h3>
                            <div class="overview clearfix">
                                <div class="pull-left">
                                    <span class="version" title="Supported Versions" data-toggle="tooltip">
                                        <span class="glyphicon glyphicon-bookmark"></span> BS3, BS4                                    </span>
                                </div>
                                <div class="pull-right">
                                    <span class="views" title="Views" data-toggle="tooltip">
                                        <span class="glyphicon glyphicon-eye-open"></span> 36862                                    </span>                                    
                                </div>
                            </div>
                        </div>                  
                    </div>
                </a>
            </div>
                        <div class="col-md-3 col-sm-4">
                <a href="preview.php?topic=bootstrap&amp;file=testimonial-carousel" id="73" target="_blank">
                    <div class="thumbnail">                    
                        <div class="img-box">
                            <img src="designs/testimonial-carousel.png" class="img-responsive" style="max-width: 115%;float:right;margin: 15px -20px 0 0;" alt="Testimonial Carousel">                        </div>                        
                        <div class="caption">
                            <h3>Testimonial Carousel</h3>
                            <div class="overview clearfix">
                                <div class="pull-left">
                                    <span class="version" title="Supported Versions" data-toggle="tooltip">
                                        <span class="glyphicon glyphicon-bookmark"></span> BS3, BS4                                    </span>
                                </div>
                                <div class="pull-right">
                                    <span class="views" title="Views" data-toggle="tooltip">
                                        <span class="glyphicon glyphicon-eye-open"></span> 36407                                    </span>                                    
                                </div>
                            </div>
                        </div>                  
                    </div>
                </a>
            </div>
                        <div class="col-md-3 col-sm-4">
                <a href="preview.php?topic=bootstrap&amp;file=product-list-carousel-for-ecommerce-website" id="71" target="_blank">
                    <div class="thumbnail">                    
                        <div class="img-box">
                            <img src="designs/product-list-carousel-for-ecommerce-website.png" class="img-responsive" style="max-width: 175%;float:right;margin: 0 -10px 0 0;" alt="Product List Carousel for Ecommerce Website">                        </div>                        
                        <div class="caption">
                            <h3>Product List Carousel for Ecommerce Website</h3>
                            <div class="overview clearfix">
                                <div class="pull-left">
                                    <span class="version" title="Supported Versions" data-toggle="tooltip">
                                        <span class="glyphicon glyphicon-bookmark"></span> BS3, BS4                                    </span>
                                </div>
                                <div class="pull-right">
                                    <span class="views" title="Views" data-toggle="tooltip">
                                        <span class="glyphicon glyphicon-eye-open"></span> 31000                                    </span>                                    
                                </div>
                            </div>
                        </div>                  
                    </div>
                </a>
            </div>
                        <div class="col-md-3 col-sm-4">
                <a href="preview.php?topic=bootstrap&amp;file=simple-success-confirmation-popup" id="53" target="_blank">
                    <div class="thumbnail">                    
                        <div class="img-box">
                            <img src="designs/simple-success-confirmation-popup.png" class="img-responsive"  alt="Simple Success Confirmation Popup">                        </div>                        
                        <div class="caption">
                            <h3>Simple Success Confirmation Popup</h3>
                            <div class="overview clearfix">
                                <div class="pull-left">
                                    <span class="version" title="Supported Versions" data-toggle="tooltip">
                                        <span class="glyphicon glyphicon-bookmark"></span> BS3, BS4                                    </span>
                                </div>
                                <div class="pull-right">
                                    <span class="views" title="Views" data-toggle="tooltip">
                                        <span class="glyphicon glyphicon-eye-open"></span> 30673                                    </span>                                    
                                </div>
                            </div>
                        </div>                  
                    </div>
                </a>
            </div>
                        <div class="col-md-3 col-sm-4">
                <a href="preview.php?topic=bootstrap&amp;file=navbar-dropdown-login-and-signup-form-with-social-buttons" id="66" target="_blank">
                    <div class="thumbnail">                    
                        <div class="img-box">
                            <img src="designs/navbar-dropdown-login-and-signup-form-with-social-buttons.png" class="img-responsive" style="min-height: 100%;max-width: 360%;float: right;" alt="Navbar Dropdown Login and Signup Form with Social Buttons">                        </div>                        
                        <div class="caption">
                            <h3>Navbar Dropdown Login and Signup Form with Social Buttons</h3>
                            <div class="overview clearfix">
                                <div class="pull-left">
                                    <span class="version" title="Supported Versions" data-toggle="tooltip">
                                        <span class="glyphicon glyphicon-bookmark"></span> BS3, BS4                                    </span>
                                </div>
                                <div class="pull-right">
                                    <span class="views" title="Views" data-toggle="tooltip">
                                        <span class="glyphicon glyphicon-eye-open"></span> 29300                                    </span>                                    
                                </div>
                            </div>
                        </div>                  
                    </div>
                </a>
            </div>
                    </div>
        <div class="row">
            <div class="col-md-12">
                <div class="lead-main">
					<div class="ad-label mt-10">Advertisements</div>
                    <div class="ad-box mb-20">
                        <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Optional Leaderboard -->
<ins class="adsbygoogle"
     style="display:block;width:100%;height:90px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="7276260616"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>                    </div>
                </div>                
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="text-center">
                    <ul class="pagination">
                        <li class="disabled"><a>&laquo;</a></li><li class="active"><a href="gallery.php?page=1">1</a></li><li><a href="gallery.php?page=2">2</a></li><li><a href="gallery.php?page=3">3</a></li><li><a href="gallery.php?page=4">4</a></li><li><a href="gallery.php?page=5">5</a></li><li><a href="gallery.php?page=6">6</a></li><li><a href="gallery.php?page=7">7</a></li><li><a href="gallery.php?page=8">8</a></li><li><a href="gallery.php?page=2">&raquo;</a></li>                    </ul>
                </div>                
            </div>
        </div>
                    </div>
</div>
<!--Footer-->
<div class="footer bg-gray">
    <div class="footer-inner">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">Copyright &copy;2019 Tutorial Republic</div>
                <div class="col-sm-6">
                    <ul class="list-inline pull-right">
                        <li><a href="/terms-of-use.php">Terms of Use</a></li>
                        <li><a href="/privacy-policy.php">Privacy Policy</a></li>
                        <li><a href="/contact-us.php">Report Error</a></li>
                    </ul>
                </div>
            </div>
        </div>  
    </div>    
</div>
<!--End:Footer-->
<!-- Social widget (footer section) -->
<div class="social-widget">
	<a id="facebook-share-btn" href="https://facebook.com/sharer.php?u=https://www.tutorialrepublic.com%2Fsnippets%2Fgallery.php" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" title="Share on Facebook"></a>
	<a id="twitter-share-btn" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" title="Share on Twitter"></a>
	<a id="google-share-btn" href="https://plus.google.com/share?url=https://www.tutorialrepublic.com%2Fsnippets%2Fgallery.php" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=438,width=600,top=150, left='+((screen.width/2)-300));return false;" title="Share on Google+"></a>
	<a id="facebook-like-btn" title="Like Us on Facebook"><span id="like-container"></span></a>
</div>
<script>
	var title = document.title.replace('Tutorial Republic', '');
	document.getElementById('twitter-share-btn').href = 'https://twitter.com/share?text=' + title + '&amp;url=https://www.tutorialrepublic.com%2Fsnippets%2Fgallery.php';
</script></body>
</html>
