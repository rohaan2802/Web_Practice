<!DOCTYPE html>
<html lang="en"><!-- InstanceBegin template="/Templates/css.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
	<!-- InstanceBeginEditable name="doctitle" -->
    <title>CSS Color Names - List of Color Keywords, Hex and RGB Values</title>
    <meta name="description" content="Get the complete list of basic and extended color keywords as well as their hex and RGB color values. You can further fine tune the color using shades option." />
    <!-- InstanceEndEditable -->
    	<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta property="fb:admins" content="100001054961582" />
<meta property="fb:app_id" content="1404574483159557" />
<meta property="og:image" content="/lib/images/signature.png" />
<link type="image/x-icon" href="/favicon.ico" rel="shortcut icon" />
<style>
html,body,h1,h2,h3,h4,h5,h6,p,blockquote,pre,img{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}
html,body{min-height:100%}
p{margin:0 0 12px}
ol,ul{margin:0 0 12px}
a,a:active,a:visited{outline:none;color:#1db79f;text-decoration:none}
a code{color:inherit}
a img{border:none;outline:none}
code{color:#000}
table{border-collapse:collapse;border-spacing:0}
table td{vertical-align:top}
body{min-width:1300px;color:#414141;background:#fafafa;font-family:"Segoe UI","Helvetica Neue",Arial,sans-serif;font-size:17px;line-height:1.7}
input,select,textarea,button,div,span,a{box-sizing:border-box}
h1,h2,h3,h4{color:#262626;font-weight:500;margin:20px 0 10px;line-height:1.5;font-weight:600}
h1{font-size:34px;margin-top:17px}
h2{font-size:28px}
h3{font-size:22px}
.space{margin-bottom:25px!important}
.break{margin-bottom:15px!important}
.text-center{text-align:center!important}
.scroll{height:195px;overflow-y:scroll}
.scroll.large{height:245px}
.scroll.xlarge{height:290px}
.scroll.xxlarge{height:340px}
sup{font-size:13px}
pre{background:none;border-radius:0}
.leaderboard{padding-top:8px;position:relative}
.ad-container{height:90px;overflow:hidden}
.intro-image img{display:block;padding:10px 0 25px;max-width:100%}
.clearfix::after{content:".";display:block;height:0;clear:both;visibility:hidden}
code,.code,.syntax,.green-box,.sky-box,.gray-box,.pink-box,.red-box,.at-rule,.codebox ul,.console-output{font-size:16px;font-family:Consolas,Monaco,Courier,monospace}
p code,table.data td:last-child code,.content ul li code,code.mark{padding:2px 4px;color:#333;background-color:#f1f1f1;border-radius:4px}
p code a,table.data td:last-child code a, .content ul li code a{padding:2px 0;background:#fff;margin:0 -4px;font-size:16px}
.console-output{margin:15px 0}
hr{border:none;border-bottom:1px solid #e7e9ed;height:1px;margin:30px 0}
.summary,.topic{border:1px solid #eaeaea;border-width:1px 0;margin:20px 0;padding:10px 0;color:#8e9aa6;line-height:1.5}
h2.section-title span{display:inline-block;border-bottom:4px solid #c9d7e0;padding:0 50px 12px 0}
.wrapper{width:1300px;padding:0 15px;margin:0 auto}
.header{background:#23384e;padding:16px 0}
input.search{background:#fff;border:0 none;color:#807E7E;float:left;height:38px;line-height:26px;font-size:14px;margin:0 0 0 12px;outline:medium none;padding:6px 14px;width:500px;border-radius:2px;box-shadow:0 0 1px rgba(0,0,0,0.6);font-family:inherit}
.search-btn{color:rgba(0,0,0,.6);background:#ebebeb;border:none;outline:none;cursor:pointer;float:left;height:38px;line-height:46px;width:44px;display:block;margin-left:-2px;border-radius:0 2px 2px 0;box-shadow:0 0 1px rgba(0,0,0,0.7)}
.logo{width:304px}
.logo img{height:44px;margin:-3px 0;display:block}
.site-search{float:left;margin-left:100px}
.menu{background-color:#f5f5f5;box-shadow:0 1px 1px rgba(0,0,0,.15);position:relative;z-index:9}
.menu a{color:#666;display:inline-block;padding:0 10px;text-decoration:none;font-size:14px;font-weight:600;height:48px;line-height:48px}
.menu a:first-child{margin-left:-10px}
.menu a.tool-link{float:right;display:inline-block;border-radius:30px;line-height:28px;position:relative;height:auto;top:9px;padding:0 12px;color:#1ebba3;border:1px double #1ebba3}
.fl,.logo{float:left}
.leftcolumn{width:240px;float:left;font-size:16px;color:#4f4f4f}
.centercolumn{width:850px;float:left}
.content{background:#fff;padding:20px 40px;border:1px solid #dedede;border-top:none;border-radius:1px}
.sidebar{float:left;padding-top:28px;width:160px;margin-left:20px;position:relative}
.leftcolumn .segment{margin:16px 0 12px;position:relative;font-size:18px;font-weight:600;display:inline-block;line-height:normal}
.leftcolumn a{color:#4f4f4f;font-size:16px;line-height:26px;display:block;border-bottom:1px solid transparent}
.leftcolumn ul{list-style:none;padding:0}
.segment,.chapters,.chapters a,.toggle-tree-menu{float:left;clear:both}
ul.tree-menu li.tree{margin-left:-12px;float:left;width:100%}
ul.tree-menu li a,ul.tree-menu li code{color:#4f4f4f;font-size:15.4px}
ul.chapters.tree-menu li a{font-size:16px}
h1 code,h2 code,h3 code{font:inherit}
.color-box{margin:15px 0;padding-left:20px}
.note-box,.warning-box,.tip-box{padding:8px 8px 3px 26px}
.info-tab{float:left;margin-left:-23px}
.content ul li{margin-top:7px}
.extra{padding-top:5px}
.green-box,.sky-box,.gray-box,.red-box,.pink-box{color:#000;margin-top:15px;padding:10px;background-color:#f6f8fa;border:1px solid #d7e2ec}
.example{background:#f4f5f6;padding:3px;margin:15px 0}
.codebox{background:#fff;border:1px solid #ddd}
.codebox-title{height:41px;padding-left:12px;border-bottom:1px solid #ddd;background:#f5f5f5}
.codebox-title h4{margin:0;font-size:18px;line-height:38px;float:left;display:inline;font-weight:500}
a.try-btn,a.download-btn{width:140px;height:40px;color:#333;font-size:15px;line-height:41px;font-weight:600;text-align:center;text-decoration:none;float:right;display:block;border-left:1px solid #ddd;background:rgba(27,31,35,0.08);box-sizing:border-box;font-family:Arial,sans-serif}
a.try-btn span{font-size:18px;line-height:normal}
.hide,.code-style,.box-size,.bottom-link,.footer,.code-style,.snippets,.report-error,.badge,.social,.ad-label,.mobile-only{display:none}
.skyscraper{width:160px;height:600px;overflow:hidden;margin-bottom:20px;background:#ebecf0}
.bottom-ad{margin-top:46px;padding:24px;position:relative;background:url(/lib/images/smooth-line.png) no-repeat center #f9f9f9}
.rectangle-left,.rectangle-right{min-width:336px;min-height:280px;overflow:hidden}
.fr,a.previous-page,a.next-page,.topic-nav{float:right}
a.previous-page,a.next-page{width:32px;height:32px;line-height:30px}
.shadow{background:#F7F8F9;padding:3px;margin:10px 0}
.syntax{color:#2f4959;padding:13px 18px;background:#F9F9FA;border:1px solid #ddd;font-size:15px}
.codebox ul{font-size:14px;padding:7px;list-style:decimal inside none}
.codebox ul.lead-zero,.codebox ul.lead-double-zero{list-style-type:decimal-leading-zero}
.codebox ul li{padding:0 9px;color:#AFAFAF;background-image:none;margin:0}
.codebox ul pre,.codebox ul li,.codebox ul li code{line-height:1.6;vertical-align:top}
.codebox ul pre,.codebox ul code{width:90%;font-size:16px;color:#222;display:inline-block;padding-left:10px;border-left:3px solid #6CE26C;white-space:pre-wrap;word-break:normal}
.codebox ul.lead-double-zero li{text-align:right}
.codebox ul.lead-double-zero li pre{text-align:left}
.codebox ul.sql.single-line pre{line-height:26px}
.content .codebox ul li code{color:#222;padding:0 0 0 10px}
.preview-box{padding:15px;text-align:center;cursor:pointer;overflow:hidden;background:#FFF;border:1px solid #e6e6e6}
.preview-box a,.preview-box img{display:block;margin:0 auto}
.topic a:first-of-type{margin-left:2px}
.topic-nav{padding-right:5px;color:#d0d0d0}
.topic-nav a{padding:0 15px;margin:0 0 0 5px;position:relative;display:inline-block}
.topic-nav a::after{font-size:24px;position:absolute;line-height:normal;top:-6px}
.topic-nav a:first-child{margin:0 5px 0 0}
.topic-nav a:first-child::after{content:'\00AB';left:-5px}
.topic-nav a:last-child::after{content:'\00BB';right:-5px}
.download-box{text-align:center;padding:20px 0;margin:20px 0 10px}
.output-box{border-color:#d4d4d4;border-style:solid;border-width:1px 0;padding:5px 15px;overflow:hidden;background:#fff;margin:10px 0}
.demo-box{margin-top:15px}
.subhead{border-bottom:3px solid #DCE3EB;margin-bottom:15px;padding-bottom:10px}
table.data,table.description{width:100%;font-size:92%}
table.data th{color:#000;padding:8px 7px;text-align:left;font-size:15px;background:#F8F8F8}
table.data td{color:#484848;padding:5px 7px;background:#fff}
table.data th,table.data td{vertical-align:top;border:1px solid #DCE3EB}
table.data tr.section th,table.data td.section{font-size:15px;background:#f0f4f7}
table.description th{width:150px;padding:7px;vertical-align: middle}
table.no-wrap tr td:first-child{white-space:nowrap}
.overview{padding-right:202px}
.overview .intro-image{float:right;margin-right:-202px;text-align:right}
.overview .intro-image + p{padding-top:0}
.support{background:#F8F8F8;border:1px solid #ccc;color:#2F4959;padding:15px}
.support table td:first-child{width:200px;padding:0 25px 0 10px;border-right:1px dashed #D0D0D0}
.support h2{color:#2F4959;font-size:16px;padding:0 0 0 30px;margin-top:0}
.support ul{margin-left:10px}
.support ul li{margin-top:4px}
h1 sup{background:#ec0000;border-radius:3px;padding:5px 10px;font-size:15px;color:#fff;position:relative;top:5px}
@media screen and (max-width: 1280px) {
body{min-width:1260px}
.wrapper{width:1260px}
.leftcolumn{width:230px}
.centercolumn{width:820px}
}
@media screen and (max-width: 800px) {
body{min-width:100%;max-width:100%;padding-top:46px}
.wrapper{width:100%;padding:0}
.header{height:46px;padding:5px 0;position:fixed;top:0;left:0;right:0;width:100%;z-index:99}
.logo{width:auto;display:block;padding:6px 0 0 60px;position:absolute;left:0;z-index:100}
.logo img{height:30px}
.menu{width:100%;padding-left:12px;padding-right:12px;overflow-x:auto;white-space:nowrap}
.centercolumn{width:100%;float:none}
.content{padding:10px;border-width:0 0 1px 0}
.sidebar{margin: 25px auto 0}
.skyscraper{display:inline-block}
.shadow,.example{max-width:100%;overflow-x:auto}
.codebox-title{position:relative}
.codebox.multi-style-mode ul{padding-top:7px;margin-top:36px;border-top:1px solid #ddd}
.codebox ul,.codebox ul.scroll{overflow-x:auto}
.rectangle-left,.rectangle-right{float:none;display:inline-block;margin:10px auto;background:#EDEEF2}
.leftcolumn,.footer,.header .social,.header .site-search,.overview .intro-image,.toggle-tree-menu,.code-style,.support table td:first-child,ul.tree-menu code.shorthand,.menu a.tool-link,.backdrop{display:none}
.summary,.topic{padding:5px 0;margin:10px 0}
.leftcolumn,.centercolumn,.sidebar{float:none}
.header,.menu,.container,.footer,.appeal-text{width:100%;box-sizing:border-box}
.centercolumn{width:100%}
.content img{max-width:100%;height:auto}
.codebox ul li{width:614px}
.codebox ul.scroll li{width:597px}
.codebox ul,.codebox ul.scroll{overflow-x:auto}
a.try-btn,a.download-btn{width:130px}
.bottom-ad{height:auto;background:none;padding:30px 0 0;margin:40px 0 0;text-align:center;position:relative}
.native-unit{margin-bottom:30px}
.overview{padding-right:0}
.scroll-pane{overflow-x:auto}
table.data{min-width:480px}
table.data pre{display:inline;white-space:normal}
table tr th,table tr td{width:auto!important}
.support h2,.support ul{padding-left:0}
p.topic{vertical-align:top}
p.topic > a{word-wrap:break-word;display:inline-block}
.example-list ul li,ul.faq-list li{padding-bottom:3px}
.preview-box{padding:6px}
.topic-nav{float:none;display:block;padding:6px 0 0 5px}
.codebox.multi-style-mode ul{padding-top:7px;margin-top:34px;border-top:1px solid #ccc}
.content pre{max-width:100%;overflow:hidden}
.shadow,.content pre.console-output{max-width:100%;overflow-x:auto}
ul.tree-menu li.tree{margin-left:0}
.support ul{margin-left:20px}
.leaderboard{margin:20px 0}
h1{font-size:28px}
h2{font-size:24px}
h3{font-size:20px}
}
@media screen and (min-width: 801px) {
.site-search,.leftcolumn,.social{display:block!important}
.backdrop{display:none!important}
}</style>    
    <!-- InstanceBeginEditable name="head" -->
<style type="text/css">
table.color-names td{vertical-align:middle}
table.color-names td:first-child{text-align:right;width:150px}
table.color-names td div{width:100%;height:25px}
</style>
    <!-- InstanceEndEditable -->
    
    <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-40117907-1', 'auto');
  ga('send', 'pageview');
</script></head>
<body>
    <!--Header-->
    
<div class="header">
    <div class="wrapper clearfix">
        <button type="button" class="open-menu mobile-only"><i class="icon-menu"></i></button>
        <div class="logo">
            <a href="https://www.tutorialrepublic.com/"><img src="/lib/images/logo.svg" alt="TutorialRepublic" /></a>
        </div>
        <div class="site-search">
            <form action="https://www.google.com/search" method="get" target="_blank" class="clearfix">
                <input type="hidden" value="www.tutorialrepublic.com" name="sitesearch" />
                <input type="text" name="q" placeholder="Search topics, tutorials, questions and answers..." id="searchInput" class="search" />
                <button type="submit" class="search-btn"><span class="icon-search"></span></button>
            </form>
        </div>
        <div class="social">                
            <a href="https://www.facebook.com/tutorialrepublic" target="_blank" title="Join us on Facebook"><i class="icon-facebook"></i></a>
            <a href="https://twitter.com/tutrepublic" target="_blank" title="Follow us on Twitter"><i class="icon-twitter"></i></a>
            <a href="/contact-us.php" target="_blank" title="Send us an Email"><i class="icon-mail"></i></a>
        </div>
        <button type="button" class="open-search mobile-only">
            <i class="icon-search"></i>
        </button>
    </div>    
</div>
<div class="menu">
    <div class="wrapper">
        <a href="//www.tutorialrepublic.com" title="Home Page">HOME</a>
        <a href="/html-tutorial/" title="HTML Tutorial">HTML5</a>            
        <a href="/css-tutorial/" title="CSS Tutorial">CSS3</a>
        <a href="/javascript-tutorial/" title="JavaScript Tutorial">JAVASCRIPT</a>
        <a href="/jquery-tutorial/" title="jQuery Tutorial">JQUERY</a>
        <a href="/twitter-bootstrap-tutorial/" title="Bootstrap Tutorial">BOOTSTRAP4</a>
        <a href="/php-tutorial/" title="PHP Tutorial">PHP7</a> 
        <a href="/sql-tutorial/" title="SQL Tutorial">SQL</a>
        <a href="/references.php" title="Web References">REFERENCES</a>
        <a href="/practice-examples.php" title="Practice Examples and Demos">EXAMPLES</a>
        <a href="/faq.php" title="Frequently Asked Questions and Answers">FAQ</a>
        <a href="/snippets/gallery.php" title="Bootstrap Code Snippets" target="_blank">SNIPPETS</a>
        <a href="/codelab.php" class="tool-link" target="_blank">Online HTML Editor</a>
    </div>        
</div>    <!--End:Header-->
    <div class="wrapper clearfix">
        <div class="leftcolumn" id="myNav">
		
        <div class="segment"><span>CSS</span> BASIC</div>
<div class="chapters">
    <a href="/css-tutorial/">CSS Introduction</a>
	<a href="/css-tutorial/css-get-started.php">CSS Getting Started</a>
    <a href="/css-tutorial/css-syntax.php">CSS Syntax</a>
    <a href="/css-tutorial/css-selectors.php">CSS Selectors</a>
    <a href="/css-tutorial/css-color.php">CSS Color</a> 
    <a href="/css-tutorial/css-background.php">CSS Background</a>
    <a href="/css-tutorial/css-fonts.php">CSS Fonts</a>
    <a href="/css-tutorial/css-text.php">CSS Text</a>
    <a href="/css-tutorial/css-links.php">CSS Links</a>
    <a href="/css-tutorial/css-lists.php">CSS Lists</a>
    <a href="/css-tutorial/css-tables.php">CSS Tables</a>
</div>
<div class="segment"><span>CSS</span> BOX MODEL</div>
<div class="chapters">
    <a href="/css-tutorial/css-box-model.php">CSS Box Model</a>
    <a href="/css-tutorial/css-margin.php">CSS Margin</a>
    <a href="/css-tutorial/css-padding.php">CSS Padding</a>
    <a href="/css-tutorial/css-border.php">CSS Border</a>
</div>
<div class="segment"><span>CSS</span> ADVANCED</div>
<div class="chapters">
    <a href="/css-tutorial/css-outline.php">CSS Outline</a>
    <a href="/css-tutorial/css-cursors.php">CSS Cursors</a>
    <a href="/css-tutorial/css-overflow.php">CSS Overflow</a>
    <a href="/css-tutorial/css-dimension.php">CSS Dimension</a>
    <a href="/css-tutorial/css-units.php">CSS Units</a>
    <a href="/css-tutorial/css-visual-formatting.php">CSS Visual Formatting</a>
    <a href="/css-tutorial/css-display.php">CSS Display</a>
    <a href="/css-tutorial/css-visibility.php">CSS Visibility</a>
    <a href="/css-tutorial/css-position.php">CSS Position</a>
    <a href="/css-tutorial/css-layers.php">CSS Layers</a>
    <a href="/css-tutorial/css-float.php">CSS Float</a>
    <a href="/css-tutorial/css-alignment.php">CSS Alignment</a>
    <a href="/css-tutorial/css-pseudo-classes.php">CSS Pseudo-classes</a>
    <a href="/css-tutorial/css-pseudo-elements.php">CSS Pseudo-elements</a>
    <a href="/css-tutorial/css-media-types.php">CSS Media Types</a>
    <a href="/css-tutorial/css-sprites.php">CSS Sprites</a>
    <a href="/css-tutorial/css-opacity.php">CSS Opacity</a>
    <a href="/css-tutorial/css-attribute-selectors.php">CSS Attribute Selectors</a>
    <a href="/css-tutorial/css-validation.php">CSS Validation</a>
</div>
<div class="segment"><span>CSS3</span> FEATURES</div>
<div class="chapters">
    <a href="/css-tutorial/css3-border.php">CSS3 Border</a>
	<a href="/css-tutorial/css3-color.php">CSS3 Color</a>
    <a href="/css-tutorial/css3-background.php">CSS3 Background</a>
    <a href="/css-tutorial/css3-gradients.php">CSS3 Gradients</a>
	<a href="/css-tutorial/css3-text-overflow.php">CSS3 Text Overflow</a>
    <a href="/css-tutorial/css3-drop-shadows.php">CSS3 Drop Shadows</a>
    <a href="/css-tutorial/css3-2d-transforms.php">CSS3 2D Transforms</a>
    <a href="/css-tutorial/css3-3d-transforms.php">CSS3 3D Transforms</a>
    <a href="/css-tutorial/css3-transitions.php">CSS3 Transitions</a>
    <a href="/css-tutorial/css3-animations.php">CSS3 Animations</a>
    <a href="/css-tutorial/css3-multi-column-layouts.php">CSS3 Multi-Column Layouts</a>
	<a href="/css-tutorial/css3-box-sizing.php">CSS3 Box Sizing</a>
	<a href="/css-tutorial/css3-flexible-box-layouts.php">CSS3 Flexbox</a>
	<a href="/css-tutorial/css3-filters.php">CSS3 Filters</a>
	<a href="/css-tutorial/css3-media-queries.php">CSS3 Media Queries</a>
	<a href="/css-tutorial/css3-miscellaneous.php">CSS3 Miscellaneous</a>
</div>
<div class="segment"><span>CSS3</span> EXAMPLES</div>
<div class="chapters">
    <a href="/css-examples.php">CSS3 Practice Examples</a>
	<a href="/faq.php#html-css">CSS3 FAQ's Answers</a>
</div>
<div class="segment"><span>CSS3</span> REFERENCE</div>
<div class="chapters">
    <a href="/css-reference/css-at-rules.php">CSS3 At-rules</a>
    <a href="/css-reference/css3-properties.php">CSS3 Properties</a>
	<a href="/css-reference/css-animatable-properties.php">CSS3 Animatable Properties</a>
    <a href="/css-reference/css-color-values.php">CSS3 Color Values</a>
    <a href="/css-reference/css-color-names.php">CSS3 Color Names</a>
    <a href="/css-reference/css-web-safe-fonts.php">CSS3 Web Safe Fonts</a>
    <a href="/css-reference/css-aural-properties.php">CSS3 Aural Properties</a>
    <a href="/references.php" class="more">More References</a>
</div>        
                </div>
        <div class="centercolumn">
            <!--Text Content-->
            <div class="content">
                <div class="leaderboard">
                    
<div class="ad-label">Advertisements</div>
<div class="ad-container">
    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <!-- Responsive Leaderboard -->
    <ins class="adsbygoogle"
            style="display:inline-block;max-width:728px;width:100%;height:90px"
            data-ad-client="ca-pub-9107540490929984"
            data-ad-slot="4302666817"></ins>
    <script>
    (adsbygoogle = window.adsbygoogle || []).push({});
    </script>
</div>                </div>
                <!-- InstanceBeginEditable name="main_content" -->
            <a href="css-color-values.php" class="previous-page" title="Go to Previous Page"></a>
            <a href="css-web-safe-fonts.php" class="next-page" title="Go to Next Page"></a>
            <h1>CSS <span>Color</span> Names</h1>
            <p class="summary">The color names are case-insensitive.</p>
            <h2>Basic color keywords</h2>
            <p>The following table lists the basic color keywords defined in CSS 2.1 specification.</p>
            <div class="shadow">
                <table class="data color-names">
                    <tr>
                        <th>Color</th>
                        <th>Color Name</th>
                        <th>Hex Value</th>
                        <th>RGB Value</th>
                        <th>Shades</th>
                    </tr>
                    <tr>
                        <td><div style="background: #00FFFF;"></div></td>
                        <td>aqua</td>
                        <td>#00FFFF</td>
                        <td>rgb(0, 255, 255)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=00FFFF">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #000000;"></div></td>
                        <td>black</td>
                        <td>#000000</td>
                        <td>rgb(0, 0, 0)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=000000">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #0000FF;"></div></td>
                        <td>blue</td>
                        <td>#0000FF</td>
                        <td>rgb(0, 0, 255)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=0000FF">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FF00FF;"></div></td>
                        <td>fuchsia</td>
                        <td>#FF00FF</td>
                        <td>rgb(255, 0, 255)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FF00FF">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #808080"></div></td>
                        <td>gray</td>
                        <td>#808080</td>
                        <td>rgb(128, 128, 128)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=808080">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #008000"></div></td>
                        <td>green</td>
                        <td>#008000</td>
                        <td>rgb(0, 128, 0)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=008000">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #00FF00"></div></td>
                        <td>lime</td>
                        <td>#00FF00</td>
                        <td>rgb(0, 255, 0)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=00FF00">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #800000"></div></td>
                        <td>maroon</td>
                        <td>#800000</td>
                        <td>rgb(128, 0, 0)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=800000">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #000080"></div></td>
                        <td>navy</td>
                        <td>#000080</td>
                        <td>rgb(0, 0, 128)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=000080">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #808000"></div></td>
                        <td>olive</td>
                        <td>#808000</td>
                        <td>rgb(128, 128, 0)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=808000">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FFA500"></div></td>
                        <td>orange</td>
                        <td>#FFA500</td>
                        <td>rgb(255, 165, 0)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FFA500">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #800080"></div></td>
                        <td>purple</td>
                        <td>#800080</td>
                        <td>rgb(128, 0, 128)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=800080">Shades</a></td>
                    </tr>

                    <tr>
                        <td><div style="background: #FF0000"></div></td>
                        <td>red</td>
                        <td>#FF0000</td>
                        <td>rgb(255, 0, 0)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FF0000">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #C0C0C0"></div></td>
                        <td>silver</td>
                        <td>#C0C0C0</td>
                        <td>rgb(192, 192, 192)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=C0C0C0">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #008080"></div></td>
                        <td>teal</td>
                        <td>#008080</td>
                        <td>rgb(0, 128, 128)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=008080">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FFFFFF"></div></td>
                        <td>white</td>
                        <td>#FFFFFF</td>
                        <td>rgb(255, 255, 255)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FFFFFF">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FFFF00"></div></td>
                        <td>yellow</td>
                        <td>#FFFF00</td>
                        <td>rgb(255, 255, 0)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FFFF00">Shades</a></td>
                    </tr>
                </table>
            </div>
            <hr />
            <h2>Extended color keywords</h2>
            <p>The following table lists the extended color keywords defined in CSS 3 specification.</p>
            <div class="shadow">
                <table class="data color-names">
                    <tr>
                        <th>Color</th>
                        <th>Color Name</th>
                        <th>Hex Value</th>
                        <th>RGB Value</th>
                        <th>Shades</th>
                    </tr>
                    <tr>
                        <td><div style="background: #F0F8FF;"></div></td>
                        <td>aliceblue</td>
                        <td>#F0F8FF</td>
                        <td>rgb(240, 248, 255)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=F0F8FF">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FAEBD7;"></div></td>
                        <td>antiquewhite</td>
                        <td>#FAEBD7</td>
                        <td>rgb(250, 235, 215)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FAEBD7">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #00FFFF;"></div></td>
                        <td>aqua</td>
                        <td>#00FFFF</td>
                        <td>rgb(0, 255, 255)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=00FFFF">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #7FFFD4;"></div></td>
                        <td>aquamarine</td>
                        <td>#7FFFD4</td>
                        <td>rgb(127, 255, 212)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=7FFFD4">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #F0FFFF;"></div></td>
                        <td>azure</td>
                        <td>#F0FFFF</td>
                        <td>rgb(1240, 255, 255)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=F0FFFF">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #F5F5DC;"></div></td>
                        <td>beige</td>
                        <td>#F5F5DC</td>
                        <td>rgb(245, 245, 220)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=F5F5DC">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FFE4C4;"></div></td>
                        <td>bisque</td>
                        <td>#FFE4C4</td>
                        <td>rgb(255, 228, 196)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FFE4C4">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #000000;"></div></td>
                        <td>black</td>
                        <td>#000000</td>
                        <td>rgb(0, 0, 0)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=000000">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FFEBCD;"></div></td>
                        <td>blanchedalmond</td>
                        <td>#FFEBCD</td>
                        <td>rgb(255, 235, 205)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FFEBCD">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #0000FF;"></div></td>
                        <td>blue</td>
                        <td>#0000FF</td>
                        <td>rgb(0, 0, 255)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=0000FF">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #8A2BE2;"></div></td>
                        <td>blueviolet</td>
                        <td>#8A2BE2</td>
                        <td>rgb(138, 43, 226)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=8A2BE2">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #A52A2A;"></div></td>
                        <td>brown</td>
                        <td>#A52A2A</td>
                        <td>rgb(165, 42, 42)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=A52A2A">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #DEB887;"></div></td>
                        <td>burlywood</td>
                        <td>#DEB887</td>
                        <td>rgb(222, 184, 135)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=DEB887">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #5F9EA0;"></div></td>
                        <td>cadetblue</td>
                        <td>#5F9EA0</td>
                        <td>rgb(95, 158, 160)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=5F9EA0">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #7FFF00;"></div></td>
                        <td>chartreuse</td>
                        <td>#7FFF00</td>
                        <td>rgb(95, 158, 160)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=7FFF00">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #D2691E;"></div></td>
                        <td>chocolate</td>
                        <td>#D2691E</td>
                        <td>rgb(210, 105, 30)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=D2691E">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FF7F50;"></div></td>
                        <td>coral</td>
                        <td>#FF7F50</td>
                        <td>rgb(255, 127, 80)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FF7F50">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #6495ED;"></div></td>
                        <td>cornflowerblue</td>
                        <td>#6495ED</td>
                        <td>rgb(100, 149, 237)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=6495ED">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FFF8DC;"></div></td>
                        <td>cornsilk</td>
                        <td>#FFF8DC</td>
                        <td>rgb(255, 248, 220)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FFF8DC">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #DC143C;"></div></td>
                        <td>crimson</td>
                        <td>#DC143C</td>
                        <td>rgb(220, 20, 60)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=DC143C">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #00FFFF;"></div></td>
                        <td>cyan</td>
                        <td>#00FFFF</td>
                        <td>rgb(0, 255, 255)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=00FFFF">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #00008B;"></div></td>
                        <td>darkblue</td>
                        <td>#00008B</td>
                        <td>rgb(0, 0, 139)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=00008B">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #008B8B;"></div></td>
                        <td>darkcyan</td>
                        <td>#008B8B</td>
                        <td>rgb(0, 139, 139)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=008B8B">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #B8860B;"></div></td>
                        <td>darkgoldenrod</td>
                        <td>#B8860B</td>
                        <td>rgb(184, 134, 11)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=B8860B">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #A9A9A9;"></div></td>
                        <td>darkgray</td>
                        <td>#A9A9A9</td>
                        <td>rgb(169, 169, 169)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=A9A9A9">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #006400;"></div></td>
                        <td>darkgreen</td>
                        <td>#006400</td>
                        <td>rgb(0, 100, 0)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=006400">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #BDB76B;"></div></td>
                        <td>darkkhaki</td>
                        <td>#BDB76B</td>
                        <td>rgb(189, 183, 107)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=BDB76B">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #8B008B;"></div></td>
                        <td>darkmagenta</td>
                        <td>#8B008B</td>
                        <td>rgb(139, 0, 139)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=8B008B">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #556B2F;"></div></td>
                        <td>darkolivegreen</td>
                        <td>#556B2F</td>
                        <td>rgb(85, 107, 47)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=556B2F">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FF8C00;"></div></td>
                        <td>darkorange</td>
                        <td>#FF8C00</td>
                        <td>rgb(255, 140, 0)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FF8C00">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #9932CC;"></div></td>
                        <td>darkorchid</td>
                        <td>#9932CC</td>
                        <td>rgb(153, 50, 204)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=9932CC">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #8B0000;"></div></td>
                        <td>darkred</td>
                        <td>#8B0000</td>
                        <td>rgb(139, 0, 0)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=8B0000">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #E9967A;"></div></td>
                        <td>darksalmon</td>
                        <td>#E9967A</td>
                        <td>rgb(233, 150, 122)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=E9967A">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #8FBC8F;"></div></td>
                        <td>darkseagreen</td>
                        <td>#8FBC8F</td>
                        <td>rgb(143, 188, 143)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=8FBC8F">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #483D8B;"></div></td>
                        <td>darkslateblue</td>
                        <td>#483D8B</td>
                        <td>rgb(72, 61, 139)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=483D8B">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #2F4F4F;"></div></td>
                        <td>darkslategray</td>
                        <td>#2F4F4F</td>
                        <td>rgb(47, 79, 79)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=2F4F4F">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #00CED1;"></div></td>
                        <td>darkturquoise</td>
                        <td>#00CED1</td>
                        <td>rgb(0, 206, 209)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=00CED1">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #9400D3;"></div></td>
                        <td>darkviolet</td>
                        <td>#9400D3</td>
                        <td>rgb(148, 0, 211)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=9400D3">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FF1493;"></div></td>
                        <td>deeppink</td>
                        <td>#FF1493</td>
                        <td>rgb(255, 20, 147)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FF1493">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #00BFFF;"></div></td>
                        <td>deepskyblue</td>
                        <td>#00BFFF</td>
                        <td>rgb(0, 191, 255)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=00BFFF">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #696969;"></div></td>
                        <td>dimgray</td>
                        <td>#696969</td>
                        <td>rgb(0, 191, 255)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=696969">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #1E90FF;"></div></td>
                        <td>dodgerblue</td>
                        <td>#1E90FF</td>
                        <td>rgb(30, 144, 255)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=1E90FF">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #B22222;"></div></td>
                        <td>firebrick</td>
                        <td>#B22222</td>
                        <td>rgb(178, 34, 34)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=B22222">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FFFAF0;"></div></td>
                        <td>floralwhite</td>
                        <td>#FFFAF0</td>
                        <td>rgb(255, 250, 240)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FFFAF0">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #228B22;"></div></td>
                        <td>forestgreen</td>
                        <td>#228B22</td>
                        <td>rgb(34, 139, 34)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=228B22">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FF00FF;"></div></td>
                        <td>fuchsia</td>
                        <td>#FF00FF</td>
                        <td>rgb(255, 0, 255)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FF00FF">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #DCDCDC;"></div></td>
                        <td>gainsboro</td>
                        <td>#DCDCDC</td>
                        <td>rgb(220, 220, 220)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=DCDCDC">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #F8F8FF;"></div></td>
                        <td>ghostwhite</td>
                        <td>#F8F8FF</td>
                        <td>rgb(248, 248, 255)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=F8F8FF">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FFD700;"></div></td>
                        <td>gold</td>
                        <td>#FFD700</td>
                        <td>rgb(255, 215, 0)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FFD700">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #DAA520;"></div></td>
                        <td>goldenrod</td>
                        <td>#DAA520</td>
                        <td>rgb(218, 165, 32)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=DAA520">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #7F7F7F;"></div></td>
                        <td>gray</td>
                        <td>#7F7F7F</td>
                        <td>rgb(127, 127, 127)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=7F7F7F">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #008000;"></div></td>
                        <td>green</td>
                        <td>#008000</td>
                        <td>rgb(0, 128, 0)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=008000">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #ADFF2F;"></div></td>
                        <td>greenyellow</td>
                        <td>#ADFF2F</td>
                        <td>rgb(173, 255, 47)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=ADFF2F">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #F0FFF0;"></div></td>
                        <td>honeydew</td>
                        <td>#F0FFF0</td>
                        <td>rgb(240, 255, 240)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=F0FFF0">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FF69B4;"></div></td>
                        <td>hotpink</td>
                        <td>#FF69B4</td>
                        <td>rgb(255, 105, 180)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FF69B4">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #CD5C5C;"></div></td>
                        <td>indianred</td>
                        <td>#CD5C5C</td>
                        <td>rgb(205, 92, 92)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=CD5C5C">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #4B0082;"></div></td>
                        <td>indigo</td>
                        <td>#4B0082</td>
                        <td>rgb(75, 0, 130)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=4B0082">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FFFFF0;"></div></td>
                        <td>ivory</td>
                        <td>#FFFFF0</td>
                        <td>rgb(255, 255, 240)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FFFFF0">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #F0E68C;"></div></td>
                        <td>khaki</td>
                        <td>#F0E68C</td>
                        <td>rgb(240, 230, 140)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=F0E68C">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #E6E6FA;"></div></td>
                        <td>lavender</td>
                        <td>#E6E6FA</td>
                        <td>rgb(230, 230, 250)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=E6E6FA">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FFF0F5;"></div></td>
                        <td>lavenderblush</td>
                        <td>#FFF0F5</td>
                        <td>rgb(255, 240, 245)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FFF0F5">Shades</a></td>
                    </tr>
                    <tr>

                        <td><div style="background: #7CFC00;"></div></td>
                        <td>lawngreen</td>
                        <td>#7CFC00</td>
                        <td>rgb(124, 252, 0)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=7CFC00">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FFFACD;"></div></td>
                        <td>lemonchiffon</td>
                        <td>#FFFACD</td>
                        <td>rgb(255, 250, 205)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FFFACD">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #ADD8E6;"></div></td>
                        <td>lightblue</td>
                        <td>#ADD8E6</td>
                        <td>rgb(173, 216, 230)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=ADD8E6">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #F08080;"></div></td>
                        <td>lightcoral</td>
                        <td>#F08080</td>
                        <td>rgb(240, 128, 128)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=F08080">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #E0FFFF;"></div></td>
                        <td>lightcyan</td>
                        <td>#E0FFFF</td>
                        <td>rgb(224, 255, 255)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=E0FFFF">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FAFAD2;"></div></td>
                        <td>lightgoldenrodyellow</td>
                        <td>#FAFAD2</td>
                        <td>rgb(250, 250, 210)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FAFAD2">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #90EE90;"></div></td>
                        <td>lightgreen</td>
                        <td>#90EE90</td>
                        <td>rgb(144, 238, 144)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=90EE90">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #D3D3D3;"></div></td>
                        <td>lightgrey</td>
                        <td>#D3D3D3</td>

                        <td>rgb(211, 211, 211)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=D3D3D3">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FFB6C1;"></div></td>
                        <td>lightpink</td>
                        <td>#FFB6C1</td>
                        <td>rgb(255, 182, 193)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FFB6C1">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FFA07A;"></div></td>
                        <td>lightsalmon</td>
                        <td>#FFA07A</td>
                        <td>rgb(255, 160, 122)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FFA07A">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #20B2AA;"></div></td>
                        <td>lightseagreen</td>
                        <td>#20B2AA</td>
                        <td>rgb(32, 178, 170)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=20B2AA">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #87CEFA;"></div></td>
                        <td>lightskyblue</td>
                        <td>#87CEFA</td>
                        <td>rgb(135, 206, 250)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=87CEFA">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #778899;"></div></td>
                        <td>lightslategray</td>
                        <td>#778899</td>
                        <td>rgb(119, 136, 153)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=778899">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #B0C4DE;"></div></td>
                        <td>lightsteelblue</td>
                        <td>#B0C4DE</td>
                        <td>rgb(176, 196, 222)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=B0C4DE">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FFFFE0;"></div></td>
                        <td>lightyellow</td>
                        <td>#FFFFE0</td>
                        <td>rgb(255, 255, 224)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FFFFE0">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #00FF00;"></div></td>
                        <td>lime</td>
                        <td>#00FF00</td>
                        <td>rgb(0, 255, 0)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=00FF00">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #32CD32;"></div></td>
                        <td>limegreen</td>
                        <td>#32CD32</td>
                        <td>rgb(50, 205, 50)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=32CD32">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FAF0E6;"></div></td>
                        <td>linen</td>
                        <td>#FAF0E6</td>
                        <td>rgb(250, 240, 230)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FAF0E6">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FF00FF;"></div></td>
                        <td>magenta</td>
                        <td>#FF00FF</td>
                        <td>rgb(255, 0, 255)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FF00FF">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #800000;"></div></td>
                        <td>maroon</td>
                        <td>#800000</td>
                        <td>rgb(128, 0, 0)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=800000">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #66CDAA;"></div></td>
                        <td>mediumaquamarine</td>
                        <td>#66CDAA</td>
                        <td>rgb(102, 205, 170)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=66CDAA">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #0000CD;"></div></td>
                        <td>mediumblue</td>
                        <td>#0000CD</td>
                        <td>rgb(0, 0, 205)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=0000CD">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #BA55D3;"></div></td>
                        <td>mediumorchid</td>
                        <td>#BA55D3</td>
                        <td>rgb(186, 85, 211)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=BA55D3">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #9370DB;"></div></td>

                        <td>mediumpurple</td>
                        <td>#9370DB</td>
                        <td>rgb(147, 112, 219)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=9370DB">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #3CB371;"></div></td>
                        <td>mediumseagreen</td>
                        <td>#3CB371</td>
                        <td>rgb(60, 179, 113)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=3CB371">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #7B68EE;"></div></td>
                        <td>mediumslateblue</td>
                        <td>#7B68EE</td>
                        <td>rgb(123, 104, 238)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=7B68EE">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #00FA9A;"></div></td>
                        <td>mediumspringgreen</td>
                        <td>#00FA9A</td>
                        <td>rgb(0, 250, 154)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=00FA9A">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #48D1CC;"></div></td>
                        <td>mediumturquoise</td>
                        <td>#48D1CC</td>
                        <td>rgb(72, 209, 204)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=48D1CC">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #C71585;"></div></td>
                        <td>mediumvioletred</td>
                        <td>#C71585</td>
                        <td>rgb(199, 21, 133)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=C71585">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #191970;"></div></td>
                        <td>midnightblue</td>
                        <td>#191970</td>
                        <td>rgb(25, 25, 112)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=191970">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #F5FFFA;"></div></td>
                        <td>mintcream</td>
                        <td>#F5FFFA</td>
                        <td>rgb(245, 255, 250)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=F5FFFA">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FFE4E1;"></div></td>
                        <td>mistyrose</td>
                        <td>#FFE4E1</td>
                        <td>rgb(255, 228, 225)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FFE4E1">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FFE4B5;"></div></td>
                        <td>moccasin</td>
                        <td>#FFE4B5</td>
                        <td>rgb(255, 228, 181)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FFE4B5">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FFDEAD;"></div></td>
                        <td>navajowhite</td>
                        <td>#FFDEAD</td>
                        <td>rgb(255, 222, 173)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FFDEAD">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #000080;"></div></td>
                        <td>navy</td>
                        <td>#000080</td>
                        <td>rgb(0, 0, 128)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=000080">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #9FAFDF;"></div></td>
                        <td>navyblue</td>
                        <td>#9FAFDF</td>
                        <td>rgb(159, 175, 223)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=9FAFDF">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FDF5E6;"></div></td>
                        <td>oldlace</td>
                        <td>#FDF5E6</td>
                        <td>rgb(253, 245, 230)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FDF5E6">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #808000;"></div></td>
                        <td>olive</td>
                        <td>#808000</td>
                        <td>rgb(128, 128, 0)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=808000">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #6B8E23;"></div></td>
                        <td>olivedrab</td>
                        <td>#6B8E23</td>
                        <td>rgb(107, 142, 35)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=6B8E23">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FFA500;"></div></td>
                        <td>orange</td>
                        <td>#FFA500</td>
                        <td>rgb(255, 165, 0)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FFA500">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FF4500;"></div></td>
                        <td>orangered</td>
                        <td>#FF4500</td>
                        <td>rgb(255, 69, 0)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FF4500">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #DA70D6;"></div></td>
                        <td>orchid</td>
                        <td>#DA70D6</td>
                        <td>rgb(218, 112, 214)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=DA70D6">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #EEE8AA;"></div></td>
                        <td>palegoldenrod</td>
                        <td>#EEE8AA</td>
                        <td>rgb(238, 232, 170)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=EEE8AA">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #98FB98;"></div></td>
                        <td>palegreen</td>
                        <td>#98FB98</td>
                        <td>rgb(152, 251, 152)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=98FB98">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #AFEEEE;"></div></td>
                        <td>paleturquoise</td>
                        <td>#AFEEEE</td>
                        <td>rgb(175, 238, 238)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=AFEEEE">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #DB7093;"></div></td>
                        <td>palevioletred</td>
                        <td>#DB7093</td>
                        <td>rgb(219, 112, 147)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=DB7093">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FFEFD5;"></div></td>
                        <td>papayawhip</td>
                        <td>#FFEFD5</td>
                        <td>rgb(255, 239, 213)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FFEFD5">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FFDAB9;"></div></td>
                        <td>peachpuff</td>
                        <td>#FFDAB9</td>
                        <td>rgb(255, 218, 185)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FFDAB9">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #CD853F;"></div></td>
                        <td>peru</td>
                        <td>#CD853F</td>
                        <td>rgb(205, 133, 63)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=CD853F">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FFC0CB;"></div></td>
                        <td>pink</td>
                        <td>#FFC0CB</td>
                        <td>rgb(255, 192, 203)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FFC0CB">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #DDA0DD;"></div></td>
                        <td>plum</td>
                        <td>#DDA0DD</td>
                        <td>rgb(221, 160, 221)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=DDA0DD">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #B0E0E6;"></div></td>
                        <td>powderblue</td>
                        <td>#B0E0E6</td>
                        <td>rgb(176, 224, 230)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=B0E0E6">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #800080;"></div></td>
                        <td>purple</td>
                        <td>#800080</td>
                        <td>rgb(128, 0, 128)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=800080">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FF0000;"></div></td>
                        <td>red</td>
                        <td>#FF0000</td>
                        <td>rgb(255, 0, 0)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FF0000">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #BC8F8F;"></div></td>
                        <td>rosybrown</td>
                        <td>#BC8F8F</td>
                        <td>rgb(188, 143, 143)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=BC8F8F">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #4169E1;"></div></td>
                        <td>royalblue</td>
                        <td>#4169E1</td>
                        <td>rgb(65, 105, 225)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=4169E1">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #8B4513;"></div></td>
                        <td>saddlebrown</td>
                        <td>#8B4513</td>
                        <td>rgb(139, 69, 19)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=8B4513">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FA8072;"></div></td>
                        <td>salmon</td>
                        <td>#FA8072</td>
                        <td>rgb(250, 128, 114)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FA8072">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #F4A460;"></div></td>
                        <td>sandybrown</td>
                        <td>#FA8072</td>
                        <td>rgb(244, 164, 96)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=F4A460">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #2E8B57;"></div></td>
                        <td>seagreen</td>
                        <td>#2E8B57</td>
                        <td>rgb(46, 139, 87)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=2E8B57">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FFF5EE;"></div></td>
                        <td>seashell</td>
                        <td>#FFF5EE</td>
                        <td>rgb(255, 245, 238)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FFF5EE">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #A0522D;"></div></td>
                        <td>sienna</td>
                        <td>#A0522D</td>
                        <td>rgb(160, 82, 45)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=A0522D">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #C0C0C0;"></div></td>
                        <td>silver</td>
                        <td>#C0C0C0</td>
                        <td>rgb(192, 192, 192)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=C0C0C0">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #87CEEB;"></div></td>
                        <td>skyblue</td>
                        <td>#87CEEB</td>
                        <td>rgb(135, 206, 235)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=87CEEB">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #6A5ACD;"></div></td>
                        <td>slateblue</td>
                        <td>#6A5ACD</td>
                        <td>rgb(106, 90, 205)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=6A5ACD">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #708090;"></div></td>
                        <td>slategray</td>
                        <td>#708090</td>
                        <td>rgb(112, 128, 144)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=708090">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FFFAFA;"></div></td>
                        <td>snow</td>
                        <td>#FFFAFA</td>
                        <td>rgb(255, 250, 250)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FFFAFA">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #00FF7F;"></div></td>
                        <td>springgreen</td>
                        <td>#00FF7F</td>
                        <td>rgb(0, 255, 127)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=00FF7F">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #4682B4;"></div></td>
                        <td>steelblue</td>
                        <td>#4682B4</td>
                        <td>rgb(70, 130, 180)</td>

                        <td><a href="../html-reference/html-color-picker.php?color=4682B4">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #D2B48C;"></div></td>
                        <td>tan</td>
                        <td>#D2B48C</td>
                        <td>rgb(210, 180, 140)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=D2B48C">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #008080;"></div></td>
                        <td>teal</td>
                        <td>#008080</td>
                        <td>rgb(0, 128, 128)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=008080">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #D8BFD8;"></div></td>
                        <td>thistle</td>
                        <td>#D8BFD8</td>
                        <td>rgb(216, 191, 216)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=D8BFD8">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FF6347;"></div></td>
                        <td>tomato</td>
                        <td>#FF6347</td>
                        <td>rgb(255, 99, 71)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FF6347">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #40E0D0;"></div></td>
                        <td>turquoise</td>
                        <td>#40E0D0</td>
                        <td>rgb(64, 224, 208)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=40E0D0">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #EE82EE;"></div></td>
                        <td>violet</td>
                        <td>#EE82EE</td>
                        <td>rgb(238, 130, 238)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=EE82EE">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #F5DEB3;"></div></td>
                        <td>wheat</td>
                        <td>#F5DEB3</td>
                        <td>rgb(245, 222, 179)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=F5DEB3">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FFFFFF;"></div></td>
                        <td>white</td>
                        <td>#FFFFFF</td>
                        <td>rgb(255, 255, 255)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FFFFFF">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #F5F5F5;"></div></td>
                        <td>whitesmoke</td>
                        <td>#F5F5F5</td>
                        <td>rgb(245, 245, 245)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=F5F5F5">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #FFFF00;"></div></td>
                        <td>yellow</td>
                        <td>#FFFF00</td>
                        <td>rgb(255, 255, 0)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=FFFF00">Shades</a></td>
                    </tr>
                    <tr>
                        <td><div style="background: #9ACD32;"></div></td>
                        <td>yellowgreen</td>
                        <td>#9ACD32</td>
                        <td>rgb(139, 205, 50)</td>
                        <td><a href="../html-reference/html-color-picker.php?color=9ACD32">Shades</a></td>
                    </tr>
                </table>
            </div>
            <!--Bottom Navigation-->
            <div class="bottom-link clearfix">
                <a href="css-color-values.php" class="previous-page-bottom">Previous Page</a>
                <a href="css-web-safe-fonts.php" class="next-page-bottom">Next Page</a>
            </div>
            <!--End:Bottom Navigation--> 
          	<!-- InstanceEndEditable -->
                <!--Bottom Ads-->
                <div class="bottom-ad clearfix">
                    <div class="ad-label">Advertisements</div>

<!--Rectangle Left-->
<div class="rectangle-left fl">
    
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Large Rectangle Left -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="8162953958"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
<!--End:Rectangle Left-->


<!--Rectangle Right-->
<div class="rectangle-right fr">

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Large Rectangle Right -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="3324015654"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
<!--End:Rectangle Right-->                </div>
                <!--End:Bottom Ads-->
            </div>
            <!--End:Text Content-->
            <!--Feedback Form-->
			<div class="snippets">
	<a href="/snippets/gallery.php" target="_blank">
    	<img src="/lib/images/bootstrap-code-snippets.png" alt="Bootstrap UI Design Templates" />
	</a>
</div>

<div class="report-error" id="feedback">
    <div class="contact-form clearfix">
        <div class="close"><span class="icon-close"></span></div>
        <form id="feedback-form">
            <h3>Your Feedback:</h3>
            <div class="clearfix">
                <div class="name fl"><label>Your Name (optional) <input type="text" name="user-name" id="user-name" /></label></div>
                <div class="email fr"><label>Your E-mail (optional) <input type="text" name="user-email" id="user-email" /></label></div>
            </div>
            <div><label>Page address <input type="text" name="page-url" id="page-url" class="disabled" disabled="disabled" /></label></div>
            <div><label>Description <textarea name="description" id="description" rows="6"></textarea></label></div>
            <p id="feedback-error">We would love to hear from you, please drop us a line.</p>
            <div><button type="button" class="action-btn" onclick="sendFeedback()"><span class="icon-send"></span> Send</button></div>
        </form>
        <div id="response"></div>
    </div>           
</div>            <!--End:Feedback Form-->
        </div>        
        <div class="sidebar">
            <div class="ad-label">Advertisements</div>

<div class="skyscraper primary">

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Premium Skyscraper -->
<ins class="adsbygoogle"
     style="display:inline-block;width:160px;height:600px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="4376141825"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>

<div class="skyscraper">
    
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Bottom Skyscraper -->
<ins class="adsbygoogle"
     style="display:inline-block;width:160px;height:600px"
     data-ad-client="ca-pub-9107540490929984"
     data-ad-slot="3387984471"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>        </div>
    </div>
    <!--Footer-->
	<!--Footer-->
<div class="footer">
    <div class="appeal">
        <div class="wrapper">
            <p>Is this website helpful to you? Please give us a
            <a href="/like.php" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=250,width=600,top=150, left='+((screen.width/2)-300));return false;">like</a>,
            or share your <a href="#feedback" class="feedback">feedback</a><em> to help us improve</em>.
            Connect with us on <a href="https://www.facebook.com/tutorialrepublic" target="_blank">Facebook</a> and <a href="https://twitter.com/tutrepublic" target="_blank">Twitter</a> for the latest updates.</p>               
        </div>
    </div>
    <div class="footer-inner">
        <div class="wrapper clearfix">                
            <div class="link-box">
                <h4>About Us</h4>
                <div class="clearfix">
                    <a href="/about-us.php">Our Story</a>                    
                    <a href="/terms-of-use.php">Terms of Use</a>
                    <a href="/privacy-policy.php">Privacy Policy</a>                    
                </div>
            </div>
            <div class="link-box">
                <h4>Contact</h4>
                <div class="clearfix">
                    <a href="/contact-us.php">Contact Us</a>                    
                    <a href="#feedback" class="feedback">Report Error</a>
                    <a href="/advertise-with-us.php">Advertise</a>                    
                </div>
            </div>
            <div class="tool-box">
                <h4>Interactive Tools</h4>
                <div class="tools-list clearfix" id="tools">
                    <a href="/faq/what-is-the-maximum-length-of-title-and-meta-description-tag.php">Title &amp; Meta Length Calculator</a>                           
                    <a href="/html-formatter.php" target="_blank">HTML Formatter</a>                        
                    <a href="/twitter-bootstrap-button-generator.php" target="_blank">Bootstrap Button Generator</a>
                    <a href="/html-reference/html-color-picker.php">HTML Color Picker</a>
                    <a href="/codelab.php?topic=sql&amp;file=select-all" target="_blank">SQL Playground</a>
                    <a href="/codelab.php?topic=html&amp;file=hello-world" target="_blank">HTML Editor</a>                    
                </div>
            </div>
            <div class="footer-logo">
                <img src="/lib/images/logo.svg" alt="TutorialRepublic" />
            </div>
        </div>
    </div>           
        <div class="bottom-strip">
        <div class="wrapper">
            <div class="notice">Copyright &copy; 2019 Tutorial Republic. All Rights Reserved.</div>
            <div class="social-media">
                <em>Share This:</em>
                <a href="https://facebook.com/sharer.php?u=https://www.tutorialrepublic.com%2Fcss-reference%2Fcss-color-names.php" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" title="Facebook"><i class="icon-facebook"></i></a>
                <a href="#" id="tweet-btn" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" title="Twitter"><i class="icon-twitter"></i></a>
                <a href="#" id="email-btn" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600,top=150, left='+((screen.width/2)-300));return false;" rel="noreferrer" title="Gmail"><i class="icon-mail"></i></a>
            </div>
        </div>            
    </div>
    <script>
        var title = document.title.replace('- Tutorial Republic', '');
        document.getElementById('tweet-btn').href = 'https://twitter.com/share?text=' + title + '- &url=https://www.tutorialrepublic.com%2Fcss-reference%2Fcss-color-names.php';
        document.getElementById('email-btn').href = 'https://mail.google.com/mail/?view=cm&fs=1&su=' + title + '&body=https://www.tutorialrepublic.com%2Fcss-reference%2Fcss-color-names.php';
    </script>
</div>
<!--End:Footer-->
    
<div class="backdrop mobile-only"></div>

<!-- TutorialRepublic base script -->
<script>
// Adding CSS files
[
	'/lib/styles/extended-3.7.css',
	'/lib/icomoon/style.css'
].forEach(function(href) {
	var link = document.createElement('link');
	link.rel = 'stylesheet';
	link.href = href;
	(document.getElementsByTagName('head')[0]).appendChild(link);
});

// Adding JS files
[
	'https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js',
	'/lib/js/prism.js',
	'/lib/js/default-2.9.min.js'
].forEach(function(src) {
	var script = document.createElement('script');
	script.async = false; // important
	script.src = src;
	(document.getElementsByTagName('body')[0]).appendChild(script);
});
</script>


    <!--End:Footer-->
</body>
<!-- InstanceEnd --></html>